#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import json,re,shutil,sys,subprocess

repo=Path.cwd(); patch=Path(__file__).resolve().parent
manifest=json.loads((patch/'payload/manifest.json').read_text(encoding='utf-8'))
if not (repo/'package.json').exists() or not (repo/'_procedures').exists():
    raise SystemExit('ERROR: run from ShiftStart repository root')
for slug in manifest['taxonomy']:
    if not (repo/'_procedures'/f'{slug}.md').exists(): raise SystemExit(f'ERROR: missing {slug}')
if not (repo/'_symptoms/windows-blue-screen.md').exists(): raise SystemExit('ERROR: missing windows-blue-screen')

before=(len(list((repo/'_procedures').glob('*.md'))),len(list((repo/'_symptoms').glob('*.md'))))
if before!=(421,446): raise SystemExit(f'ERROR: unexpected content counts {before}')
backup=repo/'.shiftstart-backups'/('sprint1-governance-'+datetime.now().strftime('%Y%m%d-%H%M%S'))
targets=[repo/'package.json',repo/'_symptoms/windows-blue-screen.md']+[repo/'_procedures'/f'{x}.md' for x in manifest['taxonomy']]
for src in targets:
    dst=backup/src.relative_to(repo); dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)

def field(text,key,value):
    pat=re.compile(rf'(?m)^({re.escape(key)}:\s*).*$')
    if pat.search(text): return pat.sub(rf'\g<1>{value}',text,count=1)
    parts=text.split('---',2)
    if len(parts)<3: raise ValueError('front matter missing')
    return '---'+parts[1].rstrip()+f'\n{key}: {value}\n---'+parts[2]

def section(text,start,end,body):
    pat=re.compile(rf'(?ms)^{re.escape(start)}\s*\n.*?(?=^{re.escape(end)}\s*$)')
    if not pat.search(text): raise ValueError(f'section missing: {start}')
    return pat.sub(start+'\n'+body.rstrip()+'\n\n',text,count=1)

def step0(text,body):
    marker=body.split('\n',1)[0]
    if marker in text:return text
    anchor='## Procedure\n'
    if anchor not in text: raise ValueError('Procedure heading missing')
    return text.replace(anchor,anchor+body.rstrip()+'\n\n',1)

def rollback(text,body):
    anchor='## Rollback and stop conditions\n'
    if anchor not in text:return text
    first=body.split('\n',1)[0]
    if first in text:return text
    return text.replace(anchor,anchor+body.rstrip()+'\n',1)

def apply_patch(slug,checks,rb,st0=None):
    f=repo/'_procedures'/f'{slug}.md'; t=f.read_text(encoding='utf-8')
    t=section(t,'### Targeted checks','### Targeted remediation sequence',checks)
    if st0:t=step0(t,st0)
    t=rollback(t,rb); f.write_text(t,encoding='utf-8')

# Phase 1 taxonomy: severity is changed with priority so verification-v2 keeps the audited mapping.
for slug,(sev,pri) in manifest['taxonomy'].items():
    f=repo/'_procedures'/f'{slug}.md'; t=f.read_text(encoding='utf-8')
    t=field(t,'severity',sev); t=field(t,'verification_priority',pri); t=field(t,'classification_audit','sprint1-2026-08-13')
    f.write_text(t,encoding='utf-8'); print(f'Taxonomy {slug}: {pri}/{sev}')

# Phase 2 governance controls.
apply_patch('respond-to-a-ransomware-alert',
'''- Identify affected and at-risk devices, identities, services and network paths from EDR/SIEM, identity, email and network evidence.
- Preserve alerts, timestamps and volatile/high-value evidence before cleanup where feasible.
- Determine whether execution, credential theft, exfiltration or lateral movement is still active.
- Never ask the user to re-open suspicious content or re-execute the suspected payload.''',
'''- **Containment rollback:** release from isolation only after Incident Response confirms investigation and mitigation are complete; verify security telemetry before restoring normal access.
- Do not wipe, reimage or destroy artefacts merely to recover service without incident-owner approval.''',
'''0. **Isolate and contain immediately.** Treat a credible ransomware alert as an active security incident. Isolate affected endpoints/identities through approved EDR, identity or network controls before ordinary investigation; establish the incident owner and preserve evidence.''')

apply_patch('respond-to-suspected-data-leakage',
'''- Identify the active leakage path: account/session, endpoint, mailbox rule, sharing link, cloud storage, application/API, removable media or other channel.
- Preserve DLP/Purview/SIEM/EDR, identity, email and file-access audit evidence.
- Determine data classification, volume, recipients/destinations and regulatory/privacy impact.
- Do not reproduce the suspected leakage by resending or re-sharing protected data.''',
'''- **Containment rollback:** restore legitimate sharing or account/device access only after Security/Privacy approval and verification that the leakage path has been corrected.
- Do not delete audit records, messages, files or DLP evidence as a rollback method.''',
'''0. **Contain the active leakage path immediately.** Disable or isolate the suspected exfiltration channel before ordinary investigation while preserving audit evidence.''')

apply_patch('respond-to-a-suspected-compromised-account',
'''- Check Entra sign-in/risk evidence, recent MFA/security-info changes, registered authentication methods and privileged-role activity.
- Check suspicious OAuth/application consent and high-risk sessions.
- Preserve source IP, device, application, Conditional Access and timestamp evidence before changing credentials.''',
'''- **Identity containment rollback:** re-enable the account only after Security/IAM clears the incident, legitimate authentication methods are restored and unauthorised sessions/rules/forwarding are removed.
- Restore a legitimate mailbox rule only after owner verification; do not blindly restore the compromised state.''',
'''0. **Contain the identity immediately.** Block or restrict the suspected account and revoke active sessions/tokens through the approved identity-incident process before normal troubleshooting.''')

apply_patch('triage-a-site-internet-outage',
'''- Check ISP/provider circuit status and edge/WAN monitoring before changing endpoints.
- Check firewall/router/SD-WAN HA state, WAN interfaces, routing, DNS and recent network changes.
- Confirm site power/UPS state and test raw-IP versus DNS/application reachability from multiple clients/VLANs.''',
'''- Before any remote Cisco IOS/IOS-XE switch/router configuration change, capture the running configuration and schedule `reload in 10`; use `reload cancel` only after management and service verification. Use the vendor-equivalent confirmed-commit/rollback timer on other platforms.''')

apply_patch('triage-a-site-wide-lan-outage',
'''- Check core/distribution switch health, stack/MLAG state, power/UPS and uplinks before endpoint troubleshooting.
- Check STP state, trunks, VLAN gateways, DHCP/DNS and recent switch/firewall changes from more than one segment.
- Confirm WAN/Internet health to distinguish LAN failure from site-WAN failure.''',
'''- Before Cisco IOS/IOS-XE configuration changes, capture the running configuration and schedule `reload in 10`; cancel with `reload cancel` only after topology and service verification. Use the vendor-equivalent rollback timer elsewhere.''')

apply_patch('triage-a-wireless-access-point-outage',
'''- Check the wireless controller/cloud platform and confirm whether the AP is unreachable, disabled or isolated.
- Check switch-port link, VLAN/trunk and **PoE power budget** before restarting or replacing the AP.
- Check neighbouring AP health/client coverage, cabling and recent controller/switch changes.''',
'''- Capture existing port/VLAN/PoE configuration before changes. On Cisco IOS/IOS-XE schedule `reload in 10` before a remote switch change and use `reload cancel` only after verification; use the vendor-equivalent safety mechanism elsewhere.''')

apply_patch('triage-a-windows-server-that-is-unreachable',
'''- Check iDRAC/iLO/IPMI or approved OOB management for power state, POST/hardware alarms and console availability.
- For virtual servers, check hypervisor/cloud console, host health and VM power state.
- Test required service ports/dependencies from more than one network point and review redundancy/recent changes before restart.''',
'''- Before restart/failover, record redundancy state, current service ownership, start order and dependencies; define the failback path and verify redundancy after recovery.''',
'''0. **Check out-of-band management first.** Use iDRAC/iLO/IPMI or the approved hardware/hypervisor console to confirm power, POST/hardware health and console availability before OS-level remediation.''')

apply_patch('triage-a-cloud-service-outage',
'''- **First check the official provider health/status source** before blaming internal networking: Azure Service Health/Azure Status, Microsoft 365 Service health, AWS Health or the provider equivalent.
- Confirm provider region, tenant/subscription/account, affected service/resource health, quotas and incident/advisory IDs.
- Check recent deployments/configuration changes and dependencies only after provider status is captured.''',
'''- Preserve resource configuration, disks/snapshots and routing/DNS state before failover or redeployment; define explicit backout and failback criteria.
- Do not repeatedly restart healthy customer resources when the official provider health/status source confirms an upstream outage.''')

apply_patch('declare-and-coordinate-a-major-incident',
'''- Confirm major-incident criteria: business impact, urgency, affected critical services, users/sites and workaround availability.
- Search for an existing parent/major incident before creating a duplicate.
- Assign an Incident Commander, technical lead and communications owner; establish the bridge/channel and single ITSM source of truth.''',
'''- **Incident-status rollback:** if declaration criteria are not met, downgrade the incident deliberately, notify stakeholders and retain the audit trail.
- Every emergency technical change must reference its own tested backout plan.''')

apply_patch('triage-an-office-or-site-wide-outage',
'''- Check building/site power, UPS and core network equipment before user-device troubleshooting.
- Check WAN/ISP, LAN core, DNS/DHCP, identity and relevant cloud-provider health in a defined order.
- Search for an existing major incident and assign/confirm the Incident Commander when impact criteria are met.''',
'''- This umbrella procedure must not make broad technical changes directly; each resolver-group change must use its own approved backout plan.
- If impact drops below major-incident criteria, downgrade deliberately while preserving ownership and monitoring until stability is confirmed.''')

apply_patch('respond-to-a-lost-or-stolen-computer',
'''- Confirm serial/asset number, ownership, encryption status and last MDM/EDR check-in.
- Determine user privilege level, sensitive-data exposure and evidence of activity after loss.
- Confirm Legal/Security/asset-management requirements before remote wipe.''',
'''- Restore lock/isolation only after physical recovery, identity verification and Security/Endpoint approval.
- **Remote wipe is irreversible:** record the serial number, ownership and Legal/Security/asset-owner approval before issuing wipe.''',
'''0. **Contain corporate access immediately.** Revoke/restrict corporate sessions and remotely lock/isolate the missing computer where policy and platform controls support it; record the serial/asset number.''')

apply_patch('respond-to-a-lost-or-stolen-mobile-device',
'''- Confirm corporate-owned versus BYOD ownership, IMEI/serial, encryption/compliance state and last MDM check-in.
- Determine corporate apps/tokens/data exposed.
- Confirm permitted lost-mode, lock, selective-wipe and full-wipe actions before destructive commands.''',
'''- Remove lost mode or restore corporate access only after physical recovery, identity verification and MDM/Security approval.
- **Selective wipe is irreversible** for managed data; full wipe can destroy personal/corporate data. Record IMEI/serial, ownership, scope and approval first.''',
'''0. **Contain corporate access and mark the device lost.** Revoke corporate sessions/tokens and issue the approved MDM lost-mode/lock action; record IMEI/serial and ownership.''')

apply_patch('troubleshoot-a-print-server-outage',
'''- Confirm whether the print server is unreachable versus only the Spooler, one queue, driver or printer.
- Check disk/free space, PrintService/System event logs, Spooler dependencies, RPC/network reachability and cluster/failover role.
- Test from the server and multiple clients; preserve queued-job evidence before destructive queue cleanup.''',
'''- **Print rollback:** export printer configuration before driver/queue/port changes and restore the original configuration if service worsens.
- Preserve queued-job evidence before mass deletion and document print-role ownership before restart/failover.''')

# Exchange persistence check immediately after the compromised-account reset/remediation step.
f=repo/'_procedures/respond-to-a-suspected-compromised-account.md'; t=f.read_text(encoding='utf-8')
if 'Mailbox forwarding and Inbox-rule persistence check' not in t:
    pat=re.compile(r'(?ms)^5\. \*\*Apply the primary approved remediation\.\*\*.*?(?=^6\. \*\*Re-test the original task\.\*\*)')
    block='''5. **Reset credentials and check persistence immediately.** After approved identity verification, reset the compromised password, revoke sessions and remove unauthorised authentication methods. Immediately inspect Exchange inbox rules and mailbox forwarding before restoring normal access.

{% capture enterprise_exchange_persistence %}
$Mailbox = "user@contoso.com"
Get-InboxRule -Mailbox $Mailbox -IncludeHidden |
  Select-Object Name,Enabled,Priority,ForwardTo,ForwardAsAttachmentTo,RedirectTo,DeleteMessage
Get-Mailbox -Identity $Mailbox |
  Format-List ForwardingAddress,ForwardingSmtpAddress,DeliverToMailboxAndForward
{% endcapture %}
{% include command.html shell="powershell" label="Mailbox forwarding and Inbox-rule persistence check" command=enterprise_exchange_persistence %}

   <div class="expected"><strong>Expected result:</strong> Credential/session containment is complete and no unauthorised Inbox rule or mailbox forwarding remains.</div>

'''
    if not pat.search(t): raise SystemExit('ERROR: compromised-account Step 5 changed')
    t=pat.sub(block,t,count=1); f.write_text(t,encoding='utf-8')

# Phase 3 symptom severity.
sf=repo/'_symptoms/windows-blue-screen.md'; st=sf.read_text(encoding='utf-8')
st=field(st,'severity','medium'); st=field(st,'classification_audit','sprint1-2026-08-13'); sf.write_text(st,encoding='utf-8')
print('Symptom windows-blue-screen: medium')

# Install regression validator and docs.
for src in (patch/'payload').rglob('*'):
    if not src.is_file() or src.name=='manifest.json': continue
    rel=src.relative_to(patch/'payload'); dst=repo/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)

pkgp=repo/'package.json'; pkg=json.loads(pkgp.read_text(encoding='utf-8')); scripts=pkg.setdefault('scripts',{})
scripts['sprint1:audit:check']='node scripts/validate-sprint1-taxonomy-governance.js'
check=scripts.get('check','')
if 'npm run sprint1:audit:check' not in check: scripts['check']=(check+' && ' if check else '')+'npm run sprint1:audit:check'
pkgp.write_text(json.dumps(pkg,indent=2)+'\n',encoding='utf-8')

# Phase 4 deliberately not auto-executed: no fabricated verification.
if (repo/'node_modules').exists() and 'verification:v2:apply' in scripts:
    if subprocess.run(['npm','run','verification:v2:apply'],cwd=repo).returncode: raise SystemExit('verification:v2:apply failed')
if subprocess.run(['node','scripts/validate-sprint1-taxonomy-governance.js'],cwd=repo).returncode:
    raise SystemExit('Sprint 1 governance validation failed')
after=(len(list((repo/'_procedures').glob('*.md'))),len(list((repo/'_symptoms').glob('*.md'))))
if after!=before: raise SystemExit(f'ERROR: content counts changed {before}->{after}')
print('Sprint 1 Phases 1-3 applied. No procedure promoted to Verified.')
print('Backup:',backup.relative_to(repo))
