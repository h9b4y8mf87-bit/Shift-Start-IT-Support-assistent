#!/usr/bin/env python3
from pathlib import Path
import shutil
import subprocess
import sys

patch_root = Path(__file__).resolve().parent
repo_root = patch_root.parent
required = [repo_root / "_procedures", repo_root / "_symptoms", repo_root / "package.json"]
if not all(path.exists() for path in required):
    raise SystemExit("ERROR: Extract the patch inside the ShiftStart repository root before running this script.")

before_procedures = len(list((repo_root / "_procedures").glob("*.md")))
before_symptoms = len(list((repo_root / "_symptoms").glob("*.md")))
if before_procedures != 421 or before_symptoms != 446:
    raise SystemExit(f"ERROR: Expected 421 procedures and 446 symptoms before patching; found {before_procedures} and {before_symptoms}.")

copied = []
for source in patch_root.rglob("*"):
    if not source.is_file() or source.name == Path(__file__).name:
        continue
    relative = source.relative_to(patch_root)
    target = repo_root / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    copied.append(str(relative))

after_procedures = len(list((repo_root / "_procedures").glob("*.md")))
after_symptoms = len(list((repo_root / "_symptoms").glob("*.md")))
if (after_procedures, after_symptoms) != (421, 446):
    raise SystemExit("ERROR: Content count changed while applying the device patch.")

checks = [
    ["node", "--check", "assets/js/app.js"],
    ["node", "--check", "assets/js/search.js"],
    ["node", "scripts/validate-responsive.js"],
]
for command in checks:
    result = subprocess.run(command, cwd=repo_root)
    if result.returncode:
        raise SystemExit(f"ERROR: Validation failed: {' '.join(command)}")

print("Device optimisation applied successfully.")
print(f"Updated {len(copied)} interface/build files.")
print("Content preserved: 421 procedures and 446 symptoms.")
