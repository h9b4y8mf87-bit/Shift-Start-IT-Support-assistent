#!/usr/bin/env python3
from pathlib import Path
import shutil, sys

repo = Path.cwd()
patch = Path(__file__).resolve().parent
files_dir = patch / "files"

required = [
    repo / "index.html",
    repo / "_includes" / "header.html",
    repo / "_includes" / "footer.html",
    repo / "_layouts" / "default.html",
]
missing = [str(p) for p in required if not p.exists()]
if missing:
    print("ERROR: Run this script from the ShiftStart repository root.", file=sys.stderr)
    print("Missing:", *missing, sep="\n- ", file=sys.stderr)
    raise SystemExit(1)

# Preserve content collections: this patch never touches them.
protected = ["_procedures", "_symptoms", "_causes", "_commands"]
before_counts = {}
for name in protected:
    directory = repo / name
    before_counts[name] = len(list(directory.glob("*.md"))) if directory.exists() else 0

for src in files_dir.rglob("*"):
    if not src.is_file():
        continue
    rel = src.relative_to(files_dir)
    dest = repo / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)
    print("Updated:", rel)

layout_path = repo / "_layouts" / "default.html"
layout = layout_path.read_text(encoding="utf-8")
fusion_tag = """  <link rel="stylesheet" href="{{ '/assets/css/supportvault-fusion.css' | relative_url }}">"""
if "/assets/css/supportvault-fusion.css" not in layout:
    anchor = """  <link rel="stylesheet" href="{{ '/assets/css/site.css' | relative_url }}">"""
    if anchor not in layout:
        print("ERROR: Could not find the main stylesheet link in _layouts/default.html.", file=sys.stderr)
        raise SystemExit(1)
    layout = layout.replace(anchor, anchor + "\n" + fusion_tag, 1)
    layout_path.write_text(layout, encoding="utf-8")
    print("Updated: _layouts/default.html")
else:
    print("Already linked: assets/css/supportvault-fusion.css")

after_counts = {}
for name in protected:
    directory = repo / name
    after_counts[name] = len(list(directory.glob("*.md"))) if directory.exists() else 0

if before_counts != after_counts:
    print("ERROR: Content collection counts changed. Aborting.", file=sys.stderr)
    print("Before:", before_counts, file=sys.stderr)
    print("After:", after_counts, file=sys.stderr)
    raise SystemExit(1)

checks = {
    "index.html": [
        "Operational IT support library",
        "sv-control-console",
        "sv-signal-strip",
        "sv-governance-section",
        "sv-coverage-grid",
        "id=\"wizard\"",
        "Shift checklist",
        "Common procedures",
    ],
    "_includes/header.html": [
        "ShiftStart KB",
        "Controlled IT support knowledge",
        "Symptom wizard",
        "Procedures",
        "Coverage",
        "Quality",
        "kb-search",
    ],
    "_includes/footer.html": [
        "ShiftStart IT Support Knowledge Base",
        "Git-backed Markdown",
        "Reviewed · governed · evidence-ready",
    ],
    "assets/css/supportvault-fusion.css": [
        ".sv-control-console",
        ".sv-governance-section",
        ".sv-coverage-grid",
        ".sv-procedure-card",
        "@media",
    ],
}

for rel, tokens in checks.items():
    text = (repo / rel).read_text(encoding="utf-8")
    absent = [token for token in tokens if token not in text]
    if absent:
        print(f"ERROR: {rel} failed validation: {absent}", file=sys.stderr)
        raise SystemExit(1)

print("")
print("ShiftStart controlled-support design fusion applied successfully.")
print("Original ShiftStart search, wizard, checklist, content and claymorphism are preserved.")
print("Added: operational console, control principles, governed cards, quality lifecycle, coverage map and enterprise footer.")
print("Protected Markdown counts:", before_counts)
