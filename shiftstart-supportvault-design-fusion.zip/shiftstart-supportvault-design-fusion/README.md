# ShiftStart + controlled-support design fusion

This patch merges the supplied controlled IT knowledge-base design into the existing ShiftStart presentation without replacing or reducing the original site.

## Preserved

- Current ShiftStart brand
- Claymorphism visual system
- Permanent search
- Multi-select symptom wizard
- Shift checklist
- Common-procedure section
- Complete procedure catalogue
- Quality / assurance system
- Coverage pages
- All procedure, symptom, cause and command Markdown
- Existing Jekyll / GitHub Pages architecture

## Added from the supplied design

- Operational IT support-library kicker
- “Clear procedures. Safer support.” secondary framing
- Enterprise operational-status console
- Risk & permissions → controlled resolution → validation & rollback → escalation & evidence workflow
- Knowledge-base operating-principle signal strip
- Risk-first procedure-card hierarchy
- Draft → Review → Publish → Revalidate governance lifecycle
- Repository-generated support-domain coverage map
- Stronger enterprise footer and brand subtitle

The source design uses an operational console that explicitly surfaces risk/permissions, controlled resolution, validation/rollback and escalation/evidence. The patch adapts that structure to ShiftStart instead of copying the SupportVault brand.

## Apply

First make sure your Codespace is current:

```bash
git fetch origin
git pull --rebase origin main
```

Then upload this ZIP to the repository root and run:

```bash
unzip -q shiftstart-supportvault-design-fusion.zip

python3   shiftstart-supportvault-design-fusion/apply-fusion.py

npm install --no-audit --no-fund
npm run check

rm -f shiftstart-supportvault-design-fusion.zip
rm -rf shiftstart-supportvault-design-fusion

git add -A
git commit -m "Fuse controlled support design into ShiftStart"
git push origin main
```
