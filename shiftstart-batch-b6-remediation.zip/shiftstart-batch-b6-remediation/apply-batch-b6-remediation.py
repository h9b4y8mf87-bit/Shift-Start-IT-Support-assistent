#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import json, re, shutil, subprocess

repo = Path.cwd()
patch = Path(__file__).resolve().parent
m = json.loads((patch / "payload" / "_batch-b6-manifest.json").read_text(encoding="utf-8"))

if not (repo / "package.json").exists() or not (repo / "_procedures").exists():
    raise SystemExit("ERROR: run from ShiftStart repository root")

if not (repo / "_data" / "batch-b5-audit-remediation.json").exists():
    raise SystemExit("ERROR: Batch B-5 audit record is missing. Finish/apply Batch B-5 before Batch B-6.")

required = list(m["procedures"]) + [
    "troubleshoot-a-teams-phone-device",
    "troubleshoot-high-cpu-utilisation",
    "troubleshoot-high-memory-utilisation",
    "password-reset",
    "trace-an-active-directory-account-lockout-source",
    "troubleshoot-a-saml-application-error",
    "troubleshoot-an-external-monitor",
]

missing = [s for s in required if not (repo / "_procedures" / f"{s}.md").exists()]
if missing:
    raise SystemExit("ERROR: missing procedures: " + ", ".join(missing))

before = len(list((repo / "_procedures").glob("*.md")))
if before != 421:
    raise SystemExit(f"ERROR: expected 421 procedures; found {before}")

# Require prior canonical remediation so B6 doesn't merge into stale baselines.
checks = {
    "troubleshoot-a-teams-phone-device": "batch-b2-2026-08-13",
    "troubleshoot-high-cpu-utilisation": "batch-b5-2026-08-13",
    "troubleshoot-high-memory-utilisation": "batch-b5-2026-08-13",
}
for slug, token in checks.items():
    txt = (repo / "_procedures" / f"{slug}.md").read_text(encoding="utf-8")
    if token not in txt:
        raise SystemExit(f"ERROR: expected prior remediation marker {token} in {slug}")

backup = repo / ".shiftstart-backups" / ("batch-b6-" + datetime.now().strftime("%Y%m%d-%H%M%S"))
targets = [repo / "package.json"] + [repo / "_procedures" / f"{s}.md" for s in required]
for src in targets:
    dst = backup / src.relative_to(repo)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

def q(v):
    return "'" + str(v).replace("'", "''") + "'"

def set_field(t, k, v):
    p = re.compile(rf"(?m)^({re.escape(k)}:\s*).*$")
    if p.search(t):
        return p.sub(rf"\g<1>{v}", t, count=1)
    a = t.split("---", 2)
    if len(a) < 3:
        raise ValueError(f"front matter missing {k}")
    return "---" + a[1].rstrip() + f"\n{k}: {v}\n---" + a[2]

def block(rec):
    xs = [
        "## Mandatory Batch B-6 controls",
        "These audit-derived controls are mandatory before more invasive remediation.",
        "",
        "### Pre-checks",
    ]
    xs += [f"{i+1}. {x}" for i, x in enumerate(rec["prechecks"])]
    xs += ["", "### Rollback / undo", f"- {rec['rollback']}", ""]
    return "\n".join(xs)

def add_controls(t, rec):
    b = block(rec)
    p = re.compile(r"(?ms)^## Mandatory Batch B-6 controls\n.*?(?=^## )")
    if p.search(t):
        return p.sub(b, t, count=1)
    for anchor in ["\n## Preconditions and authorisation", "\n## Procedure"]:
        i = t.find(anchor)
        if i != -1:
            return t[:i] + "\n" + b + t[i+1:]
    a = t.split("---", 2)
    return "---" + a[1] + "---\n" + b + a[2].lstrip("\n")

def insert_before_procedure(t, block_text):
    if block_text.split("\n", 1)[0] in t:
        return t
    i = t.find("\n## Procedure")
    if i == -1:
        return t + "\n" + block_text
    return t[:i] + "\n" + block_text + t[i+1:]

# Apply B6 taxonomy and controls to all 28.
for slug, rec in m["procedures"].items():
    p = repo / "_procedures" / f"{slug}.md"
    t = p.read_text(encoding="utf-8")
    t = set_field(t, "severity", rec["severity"])
    t = set_field(t, "verification_priority", rec["priority"])
    t = set_field(t, "classification_audit", "batch-b6-2026-08-13")
    t = set_field(t, "risk_basis", q(f"Batch B-6 audit classification: {rec['priority']} / {rec['severity']}."))
    if slug not in m["merge_policy"]:
        t = add_controls(t, rec)
    p.write_text(t, encoding="utf-8")
    print(f"{slug}: {rec['priority']}/{rec['severity']}")

# ---------- Merge Group B: No dial tone -> Teams Phone ----------
canon = repo / "_procedures" / "troubleshoot-a-teams-phone-device.md"
t = canon.read_text(encoding="utf-8")
branch = """## No-dial-tone branch
Use this branch when a managed desk/Teams phone powers on but has no dial tone or cannot place calls.

1. Check handset/cabling, PoE/power and device registration.
2. Check Teams Phone/voice service health and the assigned line/account/profile.
3. Confirm network reachability and that the device is not failing registration/authentication.
4. Preserve the current profile/update state before restart, reset or firmware action.
5. Verify an outbound and inbound test call after remediation.

"""
t = insert_before_procedure(t, branch)
canon.write_text(t, encoding="utf-8")

# ---------- Merge Group A: Server CPU/memory -> B5 canonicals ----------
cpu = repo / "_procedures" / "troubleshoot-high-cpu-utilisation.md"
t = cpu.read_text(encoding="utf-8")
t = set_field(t, "canonical_role", "definitive-high-cpu-utilisation-runbook")
branch = """## Server/service high-CPU branch
For servers or shared services, treat scope and change control differently from a single-user endpoint:

- Check service/application impact, host capacity, top processes/services and scheduled workload.
- Correlate CPU pressure with deployments, patches, jobs, security alerts and dependent services.
- Capture performance evidence before restarting a service or process.
- Restart/rollback only under the owning service's change authority and after checking dependencies.

"""
t = insert_before_procedure(t, branch)
cpu.write_text(t, encoding="utf-8")

mem = repo / "_procedures" / "troubleshoot-high-memory-utilisation.md"
t = mem.read_text(encoding="utf-8")
t = set_field(t, "canonical_role", "definitive-high-memory-utilisation-runbook")
branch = """## Server/service high-memory branch
For servers or shared services:

- Identify top consumers, commit/private memory, paging/swap and sustained leak patterns.
- Correlate growth with deployments, scheduled jobs and service/application errors.
- Capture evidence before restarting services or changing memory limits.
- Restore a confirmed bad deployment/configuration through the approved service change process.

"""
t = insert_before_procedure(t, branch)
mem.write_text(t, encoding="utf-8")

# ---------- Merge Group C: SharePoint sync -> OneDrive sync ----------
onedrive = repo / "_procedures" / "troubleshoot-onedrive-synchronisation.md"
t = onedrive.read_text(encoding="utf-8")
t = set_field(t, "canonical_role", "definitive-onedrive-sharepoint-sync-runbook")
branch = """## SharePoint library synchronisation branch
SharePoint document-library synchronisation uses the OneDrive sync client, so diagnose it here rather than in a second competing runbook.

1. Confirm the library is accessible in SharePoint web and identify whether the problem is one library, one user or broader.
2. Check OneDrive client status, storage/disk state, path/name restrictions, permissions and exact sync error.
3. Establish the source of truth between SharePoint cloud content and unsynchronised local files before reset or relink.
4. Preserve unsynchronised local data and use version history/recycle-bin recovery where required.
5. Verify the affected SharePoint library synchronises end-to-end after remediation.

"""
t = insert_before_procedure(t, branch)
onedrive.write_text(t, encoding="utf-8")

# ---------- Merge Group D: Unlock -> user-account access recovery ----------
acct = repo / "_procedures" / "password-reset.md"
t = acct.read_text(encoding="utf-8")
t = set_field(t, "canonical_role", "definitive-user-account-access-recovery")
branch = """## User account access recovery decision path
Use the narrowest recovery path after verifying the user's identity:

- **One-time lockout, no compromise evidence:** identify obvious stale-credential causes, unlock under policy, then verify sign-in.
- **Forgotten/expired password:** follow the approved password-reset flow and MFA/recovery controls.
- **Repeated lockout:** use `trace-an-active-directory-account-lockout-source` before repeatedly unlocking the account.
- **Brute force or suspected compromise:** stop routine unlock/reset handling and invoke the compromised-account/security process.

Do not repeatedly unlock an account without diagnosing an immediate relock.

"""
t = insert_before_procedure(t, branch)
acct.write_text(t, encoding="utf-8")

# Cross-reference lockout diagnostic back to canonical access recovery.
lock = repo / "_procedures" / "trace-an-active-directory-account-lockout-source.md"
t = lock.read_text(encoding="utf-8")
if "password-reset" not in t or "User account access recovery" not in t:
    rel = """## User account access recovery relationship
Use `password-reset` as the canonical user-account access-recovery decision path. Use this procedure when the account repeatedly locks and the source must be traced before another unlock/reset.

"""
    t = insert_before_procedure(t, rel)
lock.write_text(t, encoding="utf-8")

# Deprecate duplicate compatibility pages while preserving URL/history.
for slug, policy in m["merge_policy"].items():
    p = repo / "_procedures" / f"{slug}.md"
    old = p.read_text(encoding="utf-8")
    a = old.split("---", 2)
    if len(a) < 3:
        raise SystemExit(f"ERROR: invalid front matter in {slug}")
    front = "---" + a[1] + "---\n"
    rec = m["procedures"][slug]
    front = set_field(front, "severity", rec["severity"])
    front = set_field(front, "verification_priority", rec["priority"])
    front = set_field(front, "content_status", "deprecated")
    front = set_field(front, "verification_governance_state", "deprecated")
    front = set_field(front, "canonical_procedure", policy["canonical"])
    front = set_field(front, "deprecation_reason",
                      q(f"Merged into {policy['canonical']} during Batch B-6 audit."))
    body = f"""## Deprecated — use the canonical procedure
This page has been consolidated into `{policy['canonical']}`.

Use `/procedures/{policy['canonical']}/`.

The canonical runbook now contains the relevant decision branch, rollback and verification path. This compatibility page remains to preserve historical links.
"""
    p.write_text(front + body, encoding="utf-8")

# Explicit Step 0 governance markers.
step0 = {
    "troubleshoot-one-way-audio":
        "0. **Check voice/UC service health before media-policy changes.** Confirm the applicable provider/service is healthy and capture call/session evidence before changing firewall, NAT or media policy.\n\n",
    "troubleshoot-onedrive-synchronisation":
        "0. **Check Microsoft 365/OneDrive service health before sync repair.** Confirm the service is healthy and establish local/cloud source of truth before unlink/reset actions.\n\n",
    "troubleshoot-sharepoint-external-sharing":
        "0. **Verify external-sharing authority before granting access.** Confirm the data owner/sponsor, recipient and approved sharing scope before creating or expanding external access.\n\n",
    "troubleshoot-single-sign-on-failure":
        "0. **Check identity and application service health before SSO changes.** Confirm the IdP and application/provider are healthy, then capture the exact sign-in/federation error before editing SSO configuration.\n\n",
    "validate-a-backup-restore-request":
        "0. **Verify restore authority and target before restoration.** Confirm requester/data owner approval, source data, restore point, destination and overwrite risk before initiating any restore.\n\n",
}
for slug, block0 in step0.items():
    p = repo / "_procedures" / f"{slug}.md"
    t = p.read_text(encoding="utf-8")
    marker = block0.split("\n", 1)[0]
    if marker not in t:
        anchor = "## Procedure\n"
        if anchor not in t:
            raise SystemExit(f"ERROR: Procedure heading missing in {slug}")
        t = t.replace(anchor, anchor + block0, 1)
    p.write_text(t, encoding="utf-8")

# Relationship: SSO parent -> SAML child.
p = repo / "_procedures" / "troubleshoot-single-sign-on-failure.md"
t = p.read_text(encoding="utf-8")
rel = """## SSO protocol relationship
Use this procedure as the broad SSO decision path. If evidence shows a SAML-specific assertion, metadata, ACS, issuer/entity-ID or signing-certificate problem, continue with `troubleshoot-a-saml-application-error`.

"""
t = insert_before_procedure(t, rel)
p.write_text(t, encoding="utf-8")

# Relationship: VDI multi-monitor -> external monitor generic parent.
p = repo / "_procedures" / "troubleshoot-vdi-multi-monitor-support.md"
t = p.read_text(encoding="utf-8")
rel = """## VDI display relationship
First use `troubleshoot-an-external-monitor` to confirm the physical displays, cable/dock and local OS arrangement are healthy. Continue here only when the fault appears inside the VDI session/client or VDI display policy.

"""
t = insert_before_procedure(t, rel)
p.write_text(t, encoding="utf-8")

# Make safety requirements explicit so they survive future template edits.
explicit = {
    "troubleshoot-usb-storage-not-detected":
        """## USB storage security rule
Do not revert a security policy merely to enable USB storage. Confirm whether DLP, endpoint security, Group Policy or MDM intentionally blocks the device before making any change.

""",
    "troubleshoot-wsl":
        """## WSL data-preservation rule
Do not unregister/delete a distribution before an export/backup exists and the required developer data has been verified.

""",
    "validate-a-backup-restore-request":
        """## Restore overwrite safety
A destructive overwrite may be irreversible. Prefer an alternate restore destination or preserve/snapshot the current destination before any approved overwrite.

""",
    "verify-data-after-a-migration":
        """## Migration acceptance gate
Do not decommission or overwrite the source environment/data until file/object counts, integrity samples, permissions/metadata and business acceptance criteria pass.

""",
    "troubleshoot-remote-desktop-connection-failure":
        """## Remote management recovery rule
For servers and VMs, keep an approved console/out-of-band/hypervisor management path available before changing RDP/firewall/GPO configuration; do not describe that path as a security bypass.

""",
}
for slug, section in explicit.items():
    p = repo / "_procedures" / f"{slug}.md"
    t = p.read_text(encoding="utf-8")
    t = insert_before_procedure(t, section)
    p.write_text(t, encoding="utf-8")

# Install manifest, docs and validator.
for src in (patch / "payload").rglob("*"):
    if not src.is_file() or src.name == "_batch-b6-manifest.json":
        continue
    rel = src.relative_to(patch / "payload")
    dst = repo / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

dst = repo / "_data" / "batch-b6-audit-remediation.json"
dst.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(patch / "payload" / "_batch-b6-manifest.json", dst)

pkgp = repo / "package.json"
pkg = json.loads(pkgp.read_text(encoding="utf-8"))
scripts = pkg.setdefault("scripts", {})
scripts["batch:b6:check"] = "python3 scripts/validate-batch-b6-remediation.py"
check = scripts.get("check", "")
if "npm run batch:b6:check" not in check:
    scripts["check"] = (check + " && " if check else "") + "npm run batch:b6:check"
pkgp.write_text(json.dumps(pkg, indent=2) + "\n", encoding="utf-8")

# Pure Python final validation: no Node dependency required.
r = subprocess.run(["python3", "scripts/validate-batch-b6-remediation.py"], cwd=repo)
if r.returncode:
    raise SystemExit("ERROR: Batch B-6 validator failed")

after = len(list((repo / "_procedures").glob("*.md")))
if after != before:
    raise SystemExit(f"ERROR: procedure count changed {before}->{after}")

print("")
print("Batch B-6 remediation applied.")
print("Final P1 audit batch accounted for: 28 procedures.")
print("No procedure was promoted to Verified.")
print("Backup:", backup.relative_to(repo))
