# ShiftStart M1 Day 1–2 — Verification Governance v2

This package performs Month 1, Day 1–2 of the ShiftStart verification programme.

## It implements

- one authoritative public trust state: `verification_governance_state`;
- Verification Evidence Schema v2;
- risk-based P0–P4 Minimum Viable Verification rules;
- automatic review-due calculation from real test/review dates;
- `Revalidation Required` for legacy/raw verified procedures that do not satisfy v2;
- `Live Validation Pending` for structurally ready procedures without complete live evidence;
- a strict v2 promotion command;
- machine-readable verification-v2 JSON/CSV reports;
- enterprise explorer/catalog/article status alignment.

## It deliberately does NOT

- fabricate test evidence;
- set missing test fields to true;
- invent reviewer names;
- invent owner sign-off;
- auto-promote procedures to Verified;
- delete or rewrite procedure body content.

## Apply

From the ShiftStart repository root:

```bash
git status
git fetch origin
git pull --rebase origin main

unzip -q shiftstart-m1-day1-2-verification-governance.zip
python3 shiftstart-m1-day1-2-verification-governance/apply-m1-day1-2.py

npm install --no-audit --no-fund

# Required migration/calculation pass.
npm run verification:v2:apply

npm run check
node scripts/validate-enterprise-overhaul.js
npm run build
```

Inspect:

```bash
cat reports/verification-v2.json
git status
```

The migration will add governance metadata to procedure front matter. This is expected. It does not create positive evidence.

If validation passes:

```bash
rm -f shiftstart-m1-day1-2-verification-governance.zip
rm -rf shiftstart-m1-day1-2-verification-governance
rm -rf .shiftstart-backups

# Generated audit timestamps may change during checks/build.
git restore reports/content-audit.json 2>/dev/null || true

git add -A
git status
git commit -m "Implement verification governance v2"
git push origin main
```

## Future promotion

After REAL evidence has been added to one or more procedures:

```bash
npm run readiness:promote
npm run check
```

Only the v2 evidence gate can now promote an under-review procedure.
