#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import shutil, sys, json, re

repo = Path.cwd()
patch = Path(__file__).resolve().parent
payload = patch / "payload"

required = [
    repo / "package.json",
    repo / "_layouts/article.html",
    repo / "_layouts/enterprise-explorer.html",
    repo / "assets/js/enterprise-shell.js",
    repo / "enterprise-catalog.json",
    repo / "_data/verification-policy.yml",
]
missing = [str(p) for p in required if not p.exists()]
if missing:
    print("ERROR: Run from the ShiftStart repository root.", file=sys.stderr)
    for item in missing: print("-", item, file=sys.stderr)
    raise SystemExit(1)

protected = ["_procedures","_symptoms","_causes","_commands"]
before = {n: len(list((repo/n).glob("*.md"))) if (repo/n).exists() else 0 for n in protected}

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = repo / ".shiftstart-backups" / f"m1-day1-2-{stamp}"
for p in required:
    rel = p.relative_to(repo)
    dst = backup / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, dst)

# Copy additive/replacement payload files.
for src in payload.rglob("*"):
    if not src.is_file(): continue
    rel = src.relative_to(payload)
    dst = repo / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    print("Installed:", rel)

# package.json: strict v2 promotion gate + v2 validation.
package_path = repo / "package.json"
pkg = json.loads(package_path.read_text(encoding="utf-8"))
scripts = pkg.setdefault("scripts", {})
scripts["verification:v2:report"] = "node scripts/verification-v2.js"
scripts["verification:v2:apply"] = "node scripts/verification-v2.js --apply"
scripts["readiness:apply"] = "node scripts/production-readiness.js --apply && node scripts/verification-v2.js --apply"
# Critical: remove the old v1 promotion path; v2 is authoritative.
scripts["readiness:promote"] = "node scripts/verification-v2.js --promote"
scripts["readiness:check"] = "node scripts/validate-readiness.js && node scripts/validate-verification-v2.js"
package_path.write_text(json.dumps(pkg, indent=2) + "\n", encoding="utf-8")
print("Updated: package.json")

# Article: authoritative governance state + v2 score/missing count.
article_path = repo / "_layouts/article.html"
article = article_path.read_text(encoding="utf-8")
article = article.replace(
    "{% assign display_status = assurance_status %}{% if assurance_status == 'verified' and evidence_complete == false %}{% assign display_status = 'revalidation' %}{% endif %}",
    "{% assign display_status = page.verification_governance_state | default: assurance_status %}"
)
article = article.replace(
    "{% if page.success_rate %}{% assign confidence_percent = page.success_rate %}{% endif %}",
    "{% if page.verification_v2_score_percent %}{% assign confidence_percent = page.verification_v2_score_percent %}{% elsif page.success_rate %}{% assign confidence_percent = page.success_rate %}{% endif %}\n{% assign verification_missing_count = page.verification_v2_missing | size %}"
)
article = article.replace(
    "{% elsif display_status == 'revalidation' %}<span class=\"ss-status-pill ss-status-revalidation\">◷ Revalidation required</span>",
    "{% elsif display_status == 'revalidation_required' %}<span class=\"ss-status-pill ss-status-revalidation\">◷ Revalidation Required</span>\n        {% elsif display_status == 'live_validation_pending' %}<span class=\"ss-status-pill ss-status-under_review\">◷ Live Validation Pending</span>"
)
article = article.replace(
    "{% if page.verified_by_smes %}<small>Verified by {{ page.verified_by_smes }} SMEs</small>{% elsif page.success_rate %}<small>Recorded success rate</small>{% else %}<small>{{ ev_count }}/6 validation evidence controls recorded</small>{% endif %}",
    "{% if display_status == 'verified' %}<small>Verification-v2 evidence gate complete</small>{% elsif page.verification_v2_missing %}<small>{{ verification_missing_count }} verification-v2 requirement(s) outstanding</small>{% elsif page.verified_by_smes %}<small>Verified by {{ page.verified_by_smes }} SMEs</small>{% else %}<small>Evidence migration pending</small>{% endif %}"
)
article = article.replace(
    "{% if assurance_status == 'under_review' or display_status == 'revalidation' %}",
    "{% if assurance_status == 'under_review' or display_status == 'revalidation_required' or display_status == 'live_validation_pending' %}"
)
article = article.replace(
    "{% if display_status == 'verified' %}Evidence-complete operational guidance{% elsif display_status == 'revalidation' %}Legacy verified status — revalidation evidence incomplete{% elsif assurance_status == 'draft' %}Draft — senior review required{% elsif assurance_status == 'deprecated' %}Deprecated — use replacement guidance{% else %}Technical-owner validation pending{% endif %}",
    "{% if display_status == 'verified' %}Evidence-complete operational guidance{% elsif display_status == 'revalidation_required' %}Revalidation required — verification-v2 evidence incomplete or expired{% elsif display_status == 'live_validation_pending' %}Documentation ready — live validation pending{% elsif assurance_status == 'draft' %}Draft — senior review required{% elsif assurance_status == 'deprecated' %}Deprecated — use replacement guidance{% else %}Technical review in progress{% endif %}"
)
article = article.replace(
    "{% if display_status == 'verified' %}Recorded diagnostic, remediation, rollback, escalation, timing and owner-signoff evidence is complete. Continue to follow organisational change controls.{% elsif display_status == 'revalidation' %}The stored status is verified, but the current evidence gate is incomplete. Treat this procedure as requiring revalidation before relying on the status alone.{% elsif assurance_status == 'under_review' %}Use this runbook with technical-owner judgement until validation is complete. Do not treat under-review content as production approval.{% else %}Review content quality and organisational approvals before applying production changes.{% endif %}",
    "{% if display_status == 'verified' %}This procedure passed the verification-v2 evidence gate and is within its review SLA. Continue to follow organisational change controls.{% elsif display_status == 'revalidation_required' %}A stored verified status exists, but verification-v2 evidence is incomplete or the review SLA has expired. Do not rely on the historical label alone.{% elsif display_status == 'live_validation_pending' %}The runbook structure is ready, but operational evidence or formal promotion is still pending. Use technical-owner judgement.{% elsif assurance_status == 'under_review' %}Technical or documentation review is still incomplete. Do not treat this content as production approval.{% else %}Review content quality and organisational approvals before applying production changes.{% endif %}"
)
article_path.write_text(article, encoding="utf-8")
print("Updated: _layouts/article.html")

# Explorer: use authoritative state and verification priority.
explorer_path = repo / "_layouts/enterprise-explorer.html"
explorer = explorer_path.read_text(encoding="utf-8")
old_priority = """              {% assign severity = item.severity | default: 'low' | downcase %}
              {% case severity %}
                {% when 'critical' %}{% assign priority = 'P0' %}{% assign priority_order = 0 %}
                {% when 'high' %}{% assign priority = 'P1' %}{% assign priority_order = 1 %}
                {% when 'medium' %}{% assign priority = 'P2' %}{% assign priority_order = 2 %}
                {% when 'low' %}{% assign priority = 'P3' %}{% assign priority_order = 3 %}
                {% else %}{% assign priority = 'P4' %}{% assign priority_order = 4 %}
              {% endcase %}"""
new_priority = """              {% assign severity = item.severity | default: 'low' | downcase %}
              {% assign priority = item.verification_priority | default: 'P3' %}
              {% case priority %}
                {% when 'P0' %}{% assign priority_order = 0 %}
                {% when 'P1' %}{% assign priority_order = 1 %}
                {% when 'P2' %}{% assign priority_order = 2 %}
                {% when 'P3' %}{% assign priority_order = 3 %}
                {% else %}{% assign priority_order = 4 %}
              {% endcase %}
              {% assign governance = item.verification_governance_state | default: 'under_review' %}"""
if old_priority not in explorer:
    raise SystemExit("ERROR: enterprise explorer priority block changed; refusing unsafe patch.")
explorer = explorer.replace(old_priority, new_priority, 1)
explorer = explorer.replace(
    'data-status="{{ item.content_status | default: \'under_review\' | escape }}"',
    'data-status="{{ governance | escape }}"'
)
old_badge = """<td><span class="ss-status-pill ss-status-{{ item.content_status | default: 'under_review' }}">{% if item.content_status == 'verified' %}✓{% elsif item.content_status == 'deprecated' %}×{% else %}◷{% endif %} {{ item.content_status | default: 'under_review' | replace: '_', ' ' }}</span></td>"""
new_badge = """<td>{% if governance == 'verified' %}<span class="ss-status-pill ss-status-verified">✓ Verified</span>{% elsif governance == 'revalidation_required' %}<span class="ss-status-pill ss-status-revalidation">◷ Revalidation Required</span>{% elsif governance == 'live_validation_pending' %}<span class="ss-status-pill ss-status-under_review">◷ Live Validation Pending</span>{% elsif governance == 'deprecated' %}<span class="ss-status-pill ss-status-deprecated">× Deprecated</span>{% else %}<span class="ss-status-pill ss-status-under_review">◷ {{ governance | replace: '_', ' ' }}</span>{% endif %}</td>"""
if old_badge not in explorer:
    raise SystemExit("ERROR: enterprise explorer status badge changed; refusing unsafe patch.")
explorer = explorer.replace(old_badge, new_badge, 1)
explorer_path.write_text(explorer, encoding="utf-8")
print("Updated: _layouts/enterprise-explorer.html")

# Enterprise JS: broaden pending filter and consume governanceStatus in widgets.
js_path = repo / "assets/js/enterprise-shell.js"
js = js_path.read_text(encoding="utf-8")
replacements = {
    "if(model.chips.has('under_review')&&row.dataset.status!=='under_review')return false;":
    "if(model.chips.has('under_review')&&!['under_review','live_validation_pending','revalidation_required'].includes(row.dataset.status))return false;",
    "const list=(data.procedures||[]).filter(p=>['P0','P1'].includes(p.priority)&&p.contentStatus!=='deprecated'&&!p.evidenceComplete).slice(0,6);":
    "const list=(data.procedures||[]).filter(p=>['P0','P1'].includes(p.priority)&&p.governanceStatus!=='deprecated'&&p.governanceStatus!=='verified').slice(0,6);",
    "${esc(p.contentStatus.replaceAll('_',' '))}":
    "${esc((p.governanceStatus||p.contentStatus).replaceAll('_',' '))}",
    "const list=(data.procedures||[]).filter(p=>p.contentStatus==='verified'&&p.evidenceComplete).sort((a,b)=>String(b.lastUpdated).localeCompare(String(a.lastUpdated))).slice(0,5);":
    "const list=(data.procedures||[]).filter(p=>p.governanceStatus==='verified'&&p.evidenceComplete).sort((a,b)=>String(b.lastUpdated).localeCompare(String(a.lastUpdated))).slice(0,5);"
}
for old,new in replacements.items():
    if old not in js:
        raise SystemExit(f"ERROR: expected enterprise-shell.js marker not found: {old[:80]}")
    js = js.replace(old,new,1)
js_path.write_text(js, encoding="utf-8")
print("Updated: assets/js/enterprise-shell.js")

# Small config declaration, without changing existing governance settings.
kb_path = repo / "_data/kb.yml"
if kb_path.exists():
    kb = kb_path.read_text(encoding="utf-8")
    if "authoritativeStatusField:" not in kb:
        marker = "  qualityReport: /reports/content-audit.json"
        addition = marker + "\n  verificationSchemaVersion: 2\n  authoritativeStatusField: verification_governance_state"
        if marker in kb:
            kb = kb.replace(marker, addition, 1)
            kb_path.write_text(kb, encoding="utf-8")
            print("Updated: _data/kb.yml")

after = {n: len(list((repo/n).glob("*.md"))) if (repo/n).exists() else 0 for n in protected}
if before != after:
    raise SystemExit(f"ERROR: Knowledge collection counts changed during installer. Before={before} After={after}")

# Structural checks before evidence migration.
checks = {
    "_data/verification-policy.yml": ["schema_version: 2","verification_governance_state","P4:"],
    "scripts/verification-v2.js": ["verification_governance_state","revalidation_required","--promote"],
    "scripts/validate-verification-v2.js": ["verification_schema_version","Evidence-complete Verified"],
    "enterprise-catalog.json": ["governanceStatus","evidenceScore","promotionReady"],
    "_layouts/article.html": ["verification_governance_state","Live Validation Pending","verification_v2_score_percent"],
    "_layouts/enterprise-explorer.html": ["verification_governance_state","Revalidation Required"],
}
for rel,tokens in checks.items():
    text=(repo/rel).read_text(encoding="utf-8")
    miss=[x for x in tokens if x not in text]
    if miss: raise SystemExit(f"ERROR: {rel} missing markers: {miss}")

print("")
print("M1 Day 1-2 verification governance patch installed.")
print("Knowledge collection file counts preserved:", before)
print("Backup:", backup.relative_to(repo))
print("")
print("IMPORTANT: evidence was NOT created or marked complete.")
print("Next run:")
print("  npm install --no-audit --no-fund")
print("  npm run verification:v2:apply")
print("  npm run check")
print("  node scripts/validate-enterprise-overhaul.js")
print("  npm run build")
