# ShiftStart Logo Integration

This patch applies the ShiftStart logo to the current site without changing procedures, symptoms, causes, commands, risk data, search, or wizard logic.

## Included

- `assets/img/shiftstart-mark.svg` — compact header/footer mark
- `assets/img/shiftstart-favicon.svg` — browser/tab icon
- `assets/img/shiftstart-logo.svg` — full horizontal brand lockup
- `assets/css/brand.css` — responsive brand styling
- `apply-logo-branding.py` — installer

## What it changes

1. Replaces the plain `S` in the header with the ShiftStart mark.
2. Replaces the plain `S` in the footer with the same mark.
3. Adds the ShiftStart favicon.
4. Loads the brand stylesheet after the current production-readiness stylesheet.
5. Creates a backup under `.shiftstart-backups/`.
6. Confirms knowledge collection counts do not change.

## Apply from the repository root

```bash
git status
git fetch origin
git pull --rebase origin main

unzip -q shiftstart-logo-integration.zip

python3 shiftstart-logo-integration/apply-logo-branding.py

npm install --no-audit --no-fund
npm run check
```

If the checks pass:

```bash
rm -f shiftstart-logo-integration.zip
rm -rf shiftstart-logo-integration

git add -A
git status
git commit -m "Apply ShiftStart brand logo"
git push origin main
```

After GitHub Pages deploys, hard-refresh with `Ctrl+F5` if the old header mark or favicon is cached.
