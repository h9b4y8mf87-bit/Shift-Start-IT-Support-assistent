#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import shutil, sys

repo = Path.cwd()
patch = Path(__file__).resolve().parent
payload = patch / "payload"

required = {
    "header": repo / "_includes/header.html",
    "footer": repo / "_includes/footer.html",
    "layout": repo / "_layouts/default.html",
}
missing = [str(p) for p in required.values() if not p.exists()]
if missing:
    print("ERROR: Run this from the ShiftStart repository root.", file=sys.stderr)
    for item in missing:
        print("-", item, file=sys.stderr)
    raise SystemExit(1)

protected = ["_procedures", "_symptoms", "_causes", "_commands"]
before = {n: len(list((repo / n).glob("*.md"))) if (repo / n).exists() else 0 for n in protected}

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = repo / ".shiftstart-backups" / f"logo-branding-{stamp}"
for p in required.values():
    rel = p.relative_to(repo)
    target = backup / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, target)

for src in payload.rglob("*"):
    if src.is_file():
        rel = src.relative_to(payload)
        dst = repo / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        print("Added:", rel)

markup = '''<span class="site-brand-mark rd-brand-mark" aria-hidden="true"><img src="{{ '/assets/img/shiftstart-mark.svg' | relative_url }}" alt=""></span>'''

for key in ("header", "footer"):
    p = required[key]
    text = p.read_text(encoding="utf-8")
    if "shiftstart-mark.svg" not in text:
        old = '<span class="site-brand-mark rd-brand-mark" aria-hidden="true">S</span>'
        if old not in text:
            raise SystemExit(f"ERROR: Could not find current {key} brand mark.")
        text = text.replace(old, markup, 1)
        p.write_text(text, encoding="utf-8")
        print("Updated:", p.relative_to(repo))

layout = required["layout"].read_text(encoding="utf-8")
favicon = '''  <link rel="icon" type="image/svg+xml" href="{{ '/assets/img/shiftstart-favicon.svg' | relative_url }}">'''
if "shiftstart-favicon.svg" not in layout:
    title = "  <title>{% if page.title %}{{ page.title | escape }} · {% endif %}{{ site.data.kb.name | escape }}</title>"
    if title in layout:
        layout = layout.replace(title, title + "\n" + favicon, 1)
    elif "</head>" in layout:
        layout = layout.replace("</head>", favicon + "\n</head>", 1)
    else:
        raise SystemExit("ERROR: Could not find favicon insertion point.")

css = '''  <link rel="stylesheet" href="{{ '/assets/css/brand.css' | relative_url }}">'''
if "/assets/css/brand.css" not in layout:
    anchor = '''  <link rel="stylesheet" href="{{ '/assets/css/production-readiness.css' | relative_url }}">'''
    if anchor in layout:
        layout = layout.replace(anchor, anchor + "\n" + css, 1)
    elif "</head>" in layout:
        layout = layout.replace("</head>", css + "\n</head>", 1)
    else:
        raise SystemExit("ERROR: Could not find stylesheet insertion point.")

required["layout"].write_text(layout, encoding="utf-8")
print("Updated: _layouts/default.html")

after = {n: len(list((repo / n).glob("*.md"))) if (repo / n).exists() else 0 for n in protected}
if before != after:
    raise SystemExit(f"ERROR: Knowledge collection counts changed. Before={before} After={after}")

checks = {
    "_includes/header.html": ["shiftstart-mark.svg", "ShiftStart"],
    "_includes/footer.html": ["shiftstart-mark.svg", "ShiftStart IT Support Assistant"],
    "_layouts/default.html": ["shiftstart-favicon.svg", "/assets/css/brand.css"],
    "assets/css/brand.css": [".rd-brand-mark", ".rd-brand-mark img"],
    "assets/img/shiftstart-mark.svg": ["ShiftStart mark", "#23B995"],
}
for rel, tokens in checks.items():
    txt = (repo / rel).read_text(encoding="utf-8")
    miss = [t for t in tokens if t not in txt]
    if miss:
        raise SystemExit(f"ERROR: {rel} missing markers: {miss}")

print("")
print("ShiftStart logo integration applied successfully.")
print("Knowledge collections preserved:", before)
print("Backup:", backup.relative_to(repo))
print("")
print("Next run:")
print("  npm install --no-audit --no-fund")
print("  npm run check")
print('  git add -A && git commit -m "Apply ShiftStart brand logo" && git push origin main')
