#!/usr/bin/env python3
from pathlib import Path
import shutil, sys, re

repo = Path.cwd()
patch = Path(__file__).resolve().parent
files = patch / 'files'

required = [repo/'_layouts'/'default.html', repo/'_layouts'/'article.html', repo/'_layouts'/'list.html', repo/'index.html']
missing = [str(p) for p in required if not p.exists()]
if missing:
    print('ERROR: Run this from the ShiftStart repository root.', file=sys.stderr)
    [print('-', p, file=sys.stderr) for p in missing]
    raise SystemExit(1)

protected = ['_procedures','_symptoms','_causes','_commands']
before = {name: len(list((repo/name).glob('*.md'))) if (repo/name).exists() else 0 for name in protected}

for src in files.rglob('*'):
    if src.is_file():
        rel = src.relative_to(files)
        dest = repo / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)
        print('Added/updated:', rel)

default_path = repo/'_layouts'/'default.html'
default = default_path.read_text(encoding='utf-8')
css_tag = "  <link rel=\"stylesheet\" href=\"{{ '/assets/css/productivity.css' | relative_url }}\">"
if '/assets/css/productivity.css' not in default:
    anchor = "  <link rel=\"stylesheet\" href=\"{{ '/assets/css/supportvault-fusion.css' | relative_url }}\">"
    if anchor not in default:
        anchor = "  <link rel=\"stylesheet\" href=\"{{ '/assets/css/site.css' | relative_url }}\">"
    default = default.replace(anchor, anchor+'\n'+css_tag, 1)
manifest_tag = "  <link rel=\"manifest\" href=\"{{ '/manifest.webmanifest' | relative_url }}\">"
if '/manifest.webmanifest' not in default:
    default = default.replace('</head>', manifest_tag+'\n</head>', 1)
js_tag = "  <script defer src=\"{{ '/assets/js/productivity.js' | relative_url }}\"></script>"
if '/assets/js/productivity.js' not in default:
    anchor = "  <script defer src=\"{{ '/assets/js/search.js' | relative_url }}\"></script>"
    default = default.replace(anchor, anchor+'\n'+js_tag, 1)
shortcuts = '''
  <dialog class="shortcuts-modal" data-shortcuts-modal>
    <div class="shortcuts-inner">
      <div class="shortcuts-head"><h2>Keyboard shortcuts</h2><button class="shortcuts-close" type="button" data-shortcuts-close aria-label="Close shortcuts">×</button></div>
      <div class="shortcuts-grid">
        <div class="shortcut-row"><span>Focus global search</span><kbd>/</kbd></div>
        <div class="shortcut-row"><span>Open this shortcut guide</span><kbd>?</kbd></div>
        <div class="shortcut-row"><span>Pin/unpin current procedure</span><kbd>B</kbd></div>
        <div class="shortcut-row"><span>Copy current procedure handover</span><kbd>H</kbd></div>
      </div>
    </div>
  </dialog>'''
if 'data-shortcuts-modal' not in default:
    default = default.replace('</body>', shortcuts+'\n</body>', 1)
default_path.write_text(default, encoding='utf-8')
print('Updated: _layouts/default.html')

index_path = repo/'index.html'
index = index_path.read_text(encoding='utf-8')
workspace = '''
<section class="shell shift-workspace" data-shift-workspace hidden>
  <div class="workspace-head">
    <div><span class="sv-section-kicker">Shift workspace</span><h2 class="!mt-1">Your working set</h2></div>
    <p>Pinned and recently opened procedures are stored only in this browser so your most-used runbooks stay one click away.</p>
  </div>
  <div class="workspace-columns">
    <section class="workspace-panel">
      <div class="workspace-panel-head"><h3>★ Pinned procedures</h3><span class="badge">Local</span></div>
      <div class="workspace-list" data-pinned-list></div>
      <p class="workspace-empty" data-pinned-empty>Pin a procedure from its page to keep it here.</p>
    </section>
    <section class="workspace-panel">
      <div class="workspace-panel-head"><h3>Recent procedures</h3><button class="btn-secondary" type="button" data-clear-recent>Clear</button></div>
      <div class="workspace-list" data-recent-list></div>
      <p class="workspace-empty" data-recent-empty>No procedures opened on this device yet.</p>
    </section>
  </div>
</section>'''
if 'data-shift-workspace' not in index:
    marker = '<section id="wizard" class="wizard-section">'
    if marker not in index:
        print('ERROR: Could not locate wizard section in index.html', file=sys.stderr); raise SystemExit(1)
    index = index.replace(marker, workspace+'\n'+marker, 1)
    index_path.write_text(index, encoding='utf-8')
    print('Updated: index.html')

article_path = repo/'_layouts'/'article.html'
article = article_path.read_text(encoding='utf-8')
if 'data-procedure-page' not in article:
    replacement = '''{% if page.content_type == 'procedure' %}<div class="reading-progress-enhanced" data-reading-progress aria-hidden="true"><span></span></div>{% endif %}
<article class="shell article-shell"{% if page.content_type == 'procedure' %} data-procedure-page data-title="{{ page.title | escape }}" data-url="{{ page.url | relative_url }}" data-category="{{ page.category | escape }}" data-severity="{{ page.severity | escape }}" data-status="{{ page.content_status | default: 'under_review' | escape }}" data-owner="{{ page.owner_team | escape }}" data-tier="{{ page.support_tier | escape }}"{% endif %}>'''
    article = article.replace('<article class="shell article-shell">', replacement, 1)
command_bar = '''
    {% if page.content_type == 'procedure' %}
    <div class="procedure-command-bar" aria-label="Procedure quick actions">
      <button class="btn-secondary" type="button" data-pin-procedure aria-pressed="false">☆ Pin procedure</button>
      <button class="btn-secondary" type="button" data-copy-procedure-link>Copy link</button>
      <button class="btn-secondary" type="button" data-copy-handover>Copy handover</button>
      <a class="btn-secondary" href="{{ '/#wizard' | relative_url }}">Open symptom wizard</a>
    </div>
    {% endif %}'''
if 'data-pin-procedure' not in article:
    marker = "    {% if page.content_type == 'procedure' %}\n    <dl class=\"assurance-meta\">"
    if marker in article:
        article = article.replace(marker, command_bar+'\n'+marker, 1)
    else:
        article = article.replace('    {% if page.tldr %}', command_bar+'\n    {% if page.tldr %}', 1)
if 'data-procedure-toc' not in article:
    old = '    <div class="article-body" data-article-body>{{ content }}</div>'
    new = '''    {% if page.content_type == 'procedure' %}
    <div class="procedure-workspace">
      <aside class="procedure-sidebar">
        <section class="procedure-sidebar-card" data-toc-panel>
          <p class="procedure-sidebar-title">On this page</p>
          <nav class="procedure-toc" data-procedure-toc aria-label="Procedure sections"></nav>
        </section>
        <section class="procedure-sidebar-card procedure-notes">
          <p class="procedure-sidebar-title">Private shift note</p>
          <textarea data-procedure-note aria-label="Private note for this procedure" placeholder="Ticket number, device name, evidence to collect…"></textarea>
          <div class="procedure-note-meta"><span data-note-status>Saved locally on this device</span><button type="button" data-clear-note>Clear</button></div>
        </section>
      </aside>
      <div class="article-body" data-article-body>{{ content }}</div>
    </div>
    {% else %}
    <div class="article-body" data-article-body>{{ content }}</div>
    {% endif %}'''
    if old not in article:
        print('ERROR: Could not locate article body insertion point.', file=sys.stderr); raise SystemExit(1)
    article = article.replace(old, new, 1)
article_path.write_text(article, encoding='utf-8')
print('Updated: _layouts/article.html')

list_path = repo/'_layouts'/'list.html'
lst = list_path.read_text(encoding='utf-8')
if 'data-catalog-status' not in lst:
    end = '</select></label>'
    first = lst.find(end)
    if first == -1: print('ERROR: Could not locate catalogue category filter.', file=sys.stderr); raise SystemExit(1)
    insert_at = first + len(end)
    status_control = '''{% if page.collection_name == 'procedures' %}<label class="catalog-status-control"><span>Quality status</span><select class="wizard-input" data-catalog-status><option value="all">All statuses</option><option value="verified">Verified</option><option value="under_review">Under review</option><option value="draft">Draft</option><option value="deprecated">Deprecated</option></select></label>{% endif %}<button class="btn-secondary" type="button" data-catalog-reset>Reset</button>'''
    lst = lst[:insert_at] + status_control + lst[insert_at:]
if 'data-catalog-empty' not in lst:
    marker = '  <div class="catalog-grid" data-catalog-items>'
    empty = '''  <div class="catalog-empty-enhanced" data-catalog-empty hidden><strong>No articles match the current filters.</strong><p>Broaden the search, choose another category/status, or reset the filters.</p><button class="btn-secondary" type="button" data-catalog-reset>Reset filters</button></div>\n'''
    lst = lst.replace(marker, empty+marker, 1)
lst = lst.replace('data-category="{{ item.category | escape }}" data-search=', 'data-category="{{ item.category | escape }}" data-status="{{ item.content_status | default: \'\' | escape }}" data-search=')
lst = re.sub(r"\n<script>\ndocument\.addEventListener\('DOMContentLoaded'.*?</script>\n?$", '\n', lst, flags=re.S)
list_path.write_text(lst, encoding='utf-8')
print('Updated: _layouts/list.html')

after = {name: len(list((repo/name).glob('*.md'))) if (repo/name).exists() else 0 for name in protected}
if before != after:
    print('ERROR: Markdown content counts changed.', before, after, file=sys.stderr); raise SystemExit(1)

checks = {
    '_layouts/default.html': ['productivity.css','productivity.js','manifest.webmanifest','data-shortcuts-modal'],
    'index.html': ['data-shift-workspace','data-pinned-list','data-recent-list','sv-control-console'],
    '_layouts/article.html': ['data-procedure-page','data-pin-procedure','data-copy-handover','data-procedure-toc','data-procedure-note'],
    '_layouts/list.html': ['data-catalog-status','data-catalog-empty','data-status='],
    'assets/js/productivity.js': ['serviceWorker','shiftstart:pinned:v1','initHandover','initCatalogEnhancements'],
    'sw.js': ['shiftstart-kb-v1','offline.html'],
}
for rel,tokens in checks.items():
    text=(repo/rel).read_text(encoding='utf-8')
    miss=[t for t in tokens if t not in text]
    if miss: print(f'ERROR: {rel} missing {miss}', file=sys.stderr); raise SystemExit(1)

print('')
print('Shift Workspace enhancements applied successfully.')
print('Preserved Markdown collections:', before)
print('Added: pinned procedures, recent work, local notes, handover copy, TOC, keyboard shortcuts, quality filters, offline/PWA support.')
print('Cloudflare challenge JavaScript was intentionally NOT included.')
