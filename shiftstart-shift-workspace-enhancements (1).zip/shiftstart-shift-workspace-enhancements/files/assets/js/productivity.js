(() => {
  "use strict";

  const BASE = (window.KB_BASE || "/").replace(/\/?$/, "/");
  const STORAGE = {
    pinned: "shiftstart:pinned:v1",
    recent: "shiftstart:recent:v1",
    notes: "shiftstart:notes:v1"
  };

  document.addEventListener("DOMContentLoaded", () => {
    initConnectionStatus();
    initPWA();
    initKeyboardShortcuts();
    initWorkspace();
    initProcedureTools();
    initCatalogEnhancements();
  });

  function initConnectionStatus() {
    let badge = document.querySelector("[data-connection-status]");
    if (!badge) {
      badge = document.createElement("div");
      badge.className = "connection-status";
      badge.dataset.connectionStatus = "";
      badge.setAttribute("role", "status");
      badge.setAttribute("aria-live", "polite");
      document.body.appendChild(badge);
    }
    const update = () => {
      const online = navigator.onLine;
      badge.textContent = online ? "Online · live content" : "Offline · cached content only";
      badge.classList.toggle("is-offline", !online);
      badge.classList.add("is-visible");
      clearTimeout(update._timer);
      update._timer = setTimeout(() => badge.classList.remove("is-visible"), online ? 2200 : 7000);
    };
    window.addEventListener("online", update);
    window.addEventListener("offline", update);
    if (!navigator.onLine) update();
  }

  function initPWA() {
    if (!("serviceWorker" in navigator)) return;
    window.addEventListener("load", () => {
      navigator.serviceWorker.register(`${BASE}sw.js`).catch((error) => {
        console.info("ShiftStart service worker not available", error);
      });
    });
  }

  function initKeyboardShortcuts() {
    const modal = document.querySelector("[data-shortcuts-modal]");
    const close = modal?.querySelector("[data-shortcuts-close]");

    document.addEventListener("keydown", (event) => {
      const editable = /INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName || "") || document.activeElement?.isContentEditable;
      if (event.key === "?" && !editable) {
        event.preventDefault();
        modal?.showModal?.();
      }
      if (event.key.toLowerCase() === "b" && !editable && document.querySelector("[data-procedure-page]")) {
        event.preventDefault();
        document.querySelector("[data-pin-procedure]")?.click();
      }
      if (event.key.toLowerCase() === "h" && !editable && document.querySelector("[data-copy-handover]")) {
        event.preventDefault();
        document.querySelector("[data-copy-handover]")?.click();
      }
    });

    close?.addEventListener("click", () => modal.close());
    modal?.addEventListener("click", (event) => {
      if (event.target === modal) modal.close();
    });
  }

  function initWorkspace() {
    const workspace = document.querySelector("[data-shift-workspace]");
    if (!workspace) return;

    const pinnedTarget = workspace.querySelector("[data-pinned-list]");
    const recentTarget = workspace.querySelector("[data-recent-list]");
    const pinnedEmpty = workspace.querySelector("[data-pinned-empty]");
    const recentEmpty = workspace.querySelector("[data-recent-empty]");

    const render = () => {
      const pinned = read(STORAGE.pinned, []);
      const recent = read(STORAGE.recent, []).slice(0, 6);
      renderCards(pinnedTarget, pinned.slice(0, 6), "pinned");
      renderCards(recentTarget, recent, "recent");
      if (pinnedEmpty) pinnedEmpty.hidden = pinned.length > 0;
      if (recentEmpty) recentEmpty.hidden = recent.length > 0;
      workspace.hidden = false;
    };

    workspace.querySelector("[data-clear-recent]")?.addEventListener("click", () => {
      localStorage.removeItem(STORAGE.recent);
      render();
    });

    window.addEventListener("shiftstart:workspace-changed", render);
    render();
  }

  function renderCards(target, items, mode) {
    if (!target) return;
    target.innerHTML = items.map((item) => `
      <article class="workspace-card">
        <a href="${escapeHtml(item.url)}">
          <div class="workspace-card-top">
            <span class="badge ${item.status ? `status-${escapeHtml(item.status)}` : ""}">${escapeHtml((item.status || "procedure").replaceAll("_", " "))}</span>
            ${item.severity ? `<span class="workspace-severity">${escapeHtml(item.severity)}</span>` : ""}
          </div>
          <strong>${escapeHtml(item.title)}</strong>
          <p>${escapeHtml(item.category || "Procedure")}</p>
        </a>
        ${mode === "pinned" ? `<button type="button" class="workspace-remove" data-unpin-url="${escapeHtml(item.url)}" aria-label="Remove ${escapeHtml(item.title)} from pinned procedures">×</button>` : ""}
      </article>
    `).join("");

    target.querySelectorAll("[data-unpin-url]").forEach((button) => {
      button.addEventListener("click", () => {
        const url = button.dataset.unpinUrl;
        write(STORAGE.pinned, read(STORAGE.pinned, []).filter((item) => item.url !== url));
        window.dispatchEvent(new CustomEvent("shiftstart:workspace-changed"));
      });
    });
  }

  function initProcedureTools() {
    const article = document.querySelector("[data-procedure-page]");
    if (!article) return;

    const record = {
      title: article.dataset.title || document.querySelector("h1")?.textContent?.trim() || "Procedure",
      url: article.dataset.url || location.pathname,
      category: article.dataset.category || "",
      severity: article.dataset.severity || "",
      status: article.dataset.status || "",
      owner: article.dataset.owner || "",
      tier: article.dataset.tier || "",
      at: Date.now()
    };

    const recent = [record, ...read(STORAGE.recent, []).filter((item) => item.url !== record.url)].slice(0, 12);
    write(STORAGE.recent, recent);
    window.dispatchEvent(new CustomEvent("shiftstart:workspace-changed"));

    initPin(record);
    initArticleToc();
    initReadingProgress();
    initCopyLink();
    initHandover(record);
    initProcedureNotes(record);
  }

  function initPin(record) {
    const button = document.querySelector("[data-pin-procedure]");
    if (!button) return;

    const refresh = () => {
      const pinned = read(STORAGE.pinned, []);
      const active = pinned.some((item) => item.url === record.url);
      button.dataset.pinned = String(active);
      button.setAttribute("aria-pressed", String(active));
      button.textContent = active ? "★ Pinned" : "☆ Pin procedure";
    };

    button.addEventListener("click", () => {
      let pinned = read(STORAGE.pinned, []);
      if (pinned.some((item) => item.url === record.url)) {
        pinned = pinned.filter((item) => item.url !== record.url);
        announce("Procedure removed from pinned items.");
      } else {
        pinned = [record, ...pinned].slice(0, 30);
        announce("Procedure pinned to your shift workspace.");
      }
      write(STORAGE.pinned, pinned);
      refresh();
      window.dispatchEvent(new CustomEvent("shiftstart:workspace-changed"));
    });

    refresh();
  }

  function initArticleToc() {
    const body = document.querySelector("[data-article-body]");
    const container = document.querySelector("[data-procedure-toc]");
    if (!body || !container) return;

    const headings = [...body.querySelectorAll("h2, h3")].filter((el) => el.textContent.trim());
    if (headings.length < 2) {
      container.closest("[data-toc-panel]")?.setAttribute("hidden", "");
      return;
    }

    const used = new Set();
    headings.forEach((heading, index) => {
      if (!heading.id) {
        let base = slugify(heading.textContent) || `section-${index + 1}`;
        let id = base;
        let n = 2;
        while (used.has(id) || document.getElementById(id)) id = `${base}-${n++}`;
        heading.id = id;
      }
      used.add(heading.id);
    });

    container.innerHTML = headings.map((heading) => `
      <a href="#${escapeHtml(heading.id)}" class="${heading.tagName === "H3" ? "toc-level-3" : ""}">
        ${escapeHtml(heading.textContent.trim())}
      </a>
    `).join("");

    if ("IntersectionObserver" in window) {
      const links = new Map([...container.querySelectorAll("a")].map((link) => [decodeURIComponent(link.hash.slice(1)), link]));
      const observer = new IntersectionObserver((entries) => {
        const visible = entries.filter((entry) => entry.isIntersecting)
          .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);
        if (!visible.length) return;
        container.querySelectorAll("a").forEach((link) => link.classList.remove("active"));
        links.get(visible[0].target.id)?.classList.add("active");
      }, { rootMargin: "-18% 0px -70% 0px", threshold: [0, 1] });
      headings.forEach((heading) => observer.observe(heading));
    }
  }

  function initReadingProgress() {
    const bar = document.querySelector("[data-reading-progress] span");
    const article = document.querySelector("[data-procedure-page]");
    if (!bar || !article) return;
    let ticking = false;
    const update = () => {
      ticking = false;
      const start = article.offsetTop;
      const total = Math.max(article.offsetHeight - innerHeight, 1);
      const ratio = Math.max(0, Math.min(1, (scrollY - start) / total));
      bar.style.transform = `scaleX(${ratio})`;
    };
    addEventListener("scroll", () => {
      if (!ticking) {
        ticking = true;
        requestAnimationFrame(update);
      }
    }, { passive: true });
    update();
  }

  function initCopyLink() {
    document.querySelector("[data-copy-procedure-link]")?.addEventListener("click", async (event) => {
      await copy(location.href);
      temporary(event.currentTarget, "Link copied", "Copy link");
    });
  }

  function initHandover(record) {
    const button = document.querySelector("[data-copy-handover]");
    if (!button) return;

    button.addEventListener("click", async () => {
      const expected = [...document.querySelectorAll(".expected")].slice(0, 4).map((el) => el.textContent.trim()).filter(Boolean);
      const escalation = document.querySelector(".escalation")?.textContent?.trim() || "";
      const tldr = document.querySelector(".tldr")?.textContent?.replace(/^TL;DR\s*/i, "").trim() || "";
      const text = [
        "ShiftStart handover",
        `Procedure: ${record.title}`,
        record.category ? `Category: ${record.category}` : "",
        record.owner ? `Owner: ${record.owner}` : "",
        record.tier ? `Tier: ${record.tier}` : "",
        record.severity ? `Severity: ${record.severity}` : "",
        record.status ? `Content status: ${record.status.replaceAll("_", " ")}` : "",
        tldr ? `TL;DR: ${tldr}` : "",
        expected.length ? `Expected/verification evidence:\n- ${expected.join("\n- ")}` : "",
        escalation ? `Escalation: ${escalation}` : "",
        `Source: ${location.href}`,
        `Captured: ${new Date().toLocaleString()}`
      ].filter(Boolean).join("\n\n");

      await copy(text);
      temporary(button, "Handover copied", "Copy handover");
      announce("Handover summary copied to clipboard.");
    });
  }

  function initProcedureNotes(record) {
    const textarea = document.querySelector("[data-procedure-note]");
    const clear = document.querySelector("[data-clear-note]");
    if (!textarea) return;

    const notes = read(STORAGE.notes, {});
    textarea.value = notes[record.url] || "";
    let timer;

    textarea.addEventListener("input", () => {
      clearTimeout(timer);
      timer = setTimeout(() => {
        const current = read(STORAGE.notes, {});
        const value = textarea.value.trim();
        if (value) current[record.url] = value;
        else delete current[record.url];
        write(STORAGE.notes, current);
        const state = document.querySelector("[data-note-status]");
        if (state) state.textContent = value ? "Saved locally on this device" : "No local note";
      }, 250);
    });

    clear?.addEventListener("click", () => {
      textarea.value = "";
      const current = read(STORAGE.notes, {});
      delete current[record.url];
      write(STORAGE.notes, current);
      const state = document.querySelector("[data-note-status]");
      if (state) state.textContent = "Local note cleared";
    });
  }

  function initCatalogEnhancements() {
    const root = document.querySelector("[data-catalog-root]");
    if (!root) return;

    const status = root.querySelector("[data-catalog-status]");
    const q = root.querySelector("[data-catalog-search]");
    const category = root.querySelector("[data-catalog-category]");
    const items = [...root.querySelectorAll(".catalog-item")];
    const count = root.querySelector("[data-catalog-count]");
    const empty = root.querySelector("[data-catalog-empty]");
    const resetButtons = root.querySelectorAll("[data-catalog-reset]");
    let frame;

    const apply = () => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const term = (q?.value || "").trim().toLowerCase();
        const cat = category?.value || "all";
        const state = status?.value || "all";
        let shown = 0;

        items.forEach((item) => {
          const show =
            (!term || item.dataset.search.includes(term)) &&
            (cat === "all" || item.dataset.category === cat) &&
            (state === "all" || item.dataset.status === state);
          item.hidden = !show;
          if (show) shown++;
        });

        if (count) count.textContent = `Showing ${shown} of ${items.length} articles.`;
        if (empty) empty.hidden = shown !== 0;
      });
    };

    q?.addEventListener("input", apply, { passive: true });
    category?.addEventListener("change", apply);
    status?.addEventListener("change", apply);
    resetButtons.forEach((button) => button.addEventListener("click", () => {
      if (q) q.value = "";
      if (category) category.value = "all";
      if (status) status.value = "all";
      apply();
      q?.focus();
    }));
    apply();
  }

  function read(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key) || "") || fallback; }
    catch { return fallback; }
  }
  function write(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
  }
  function slugify(value) {
    return String(value).toLowerCase().trim().replace(/[^a-z0-9\s-]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-");
  }
  async function copy(text) {
    if (navigator.clipboard?.writeText && isSecureContext) return navigator.clipboard.writeText(text);
    const area = document.createElement("textarea");
    area.value = text;
    area.setAttribute("readonly", "");
    area.style.position = "fixed";
    area.style.opacity = "0";
    document.body.appendChild(area);
    area.select();
    document.execCommand("copy");
    area.remove();
  }
  function temporary(element, value, original) {
    element.textContent = value;
    setTimeout(() => element.textContent = original, 1600);
  }
  function announce(message) {
    let live = document.querySelector("[data-productivity-live]");
    if (!live) {
      live = document.createElement("div");
      live.className = "sr-only";
      live.dataset.productivityLive = "";
      live.setAttribute("aria-live", "polite");
      document.body.appendChild(live);
    }
    live.textContent = "";
    requestAnimationFrame(() => live.textContent = message);
  }
  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>'"]/g, (char) => ({
      "&":"&amp;", "<":"&lt;", ">":"&gt;", "'":"&#39;", '"':"&quot;"
    }[char]));
  }
})();