const CACHE = "shiftstart-kb-v1";
const APP_SHELL = [
  "./",
  "./procedures/",
  "./symptoms/",
  "./enterprise-coverage/",
  "./content-quality/",
  "./offline.html",
  "./assets/css/site.css",
  "./assets/css/supportvault-fusion.css",
  "./assets/css/productivity.css",
  "./assets/js/lunr.min.js",
  "./assets/js/app.js",
  "./assets/js/search.js",
  "./assets/js/productivity.js",
  "./assets/data/search-index.json",
  "./assets/data/search-documents.json",
  "./assets/data/wizard-data.json"
];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE).map((key) => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});
self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  const url = new URL(event.request.url);
  if (url.origin !== location.origin) return;

  if (event.request.mode === "navigate") {
    event.respondWith(
      fetch(event.request)
        .then((response) => {
          const copy = response.clone();
          caches.open(CACHE).then((cache) => cache.put(event.request, copy));
          return response;
        })
        .catch(async () => (await caches.match(event.request)) || caches.match("./offline.html"))
    );
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cached) => {
      const network = fetch(event.request).then((response) => {
        if (response.ok) {
          const copy = response.clone();
          caches.open(CACHE).then((cache) => cache.put(event.request, copy));
        }
        return response;
      }).catch(() => cached);
      return cached || network;
    })
  );
});
