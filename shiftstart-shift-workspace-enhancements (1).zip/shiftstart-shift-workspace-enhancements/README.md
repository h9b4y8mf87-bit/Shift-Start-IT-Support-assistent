# ShiftStart Shift Workspace enhancements

Adds technician-productivity features without replacing the existing claymorphism or controlled-support design.

Features:
- pinned procedures;
- recently opened procedures;
- private per-procedure local notes;
- long-procedure TOC and reading progress;
- copy link and structured handover;
- keyboard shortcuts;
- quality-status catalogue filtering;
- online/offline status;
- PWA manifest and service worker;
- cached app shell and visited pages for short connectivity interruptions.

The supplied Cloudflare `_cf_chl_opt` / `/cdn-cgi/challenge-platform/` script is intentionally not included because it is Cloudflare challenge infrastructure rather than application UI code.

Apply from Codespaces:

```bash
git fetch origin
git pull --rebase origin main

unzip -q shiftstart-shift-workspace-enhancements.zip

python3   shiftstart-shift-workspace-enhancements/apply-shift-workspace.py

npm install --no-audit --no-fund
npm run check

rm -f shiftstart-shift-workspace-enhancements.zip
rm -rf shiftstart-shift-workspace-enhancements

git add -A
git status
git commit -m "Add Shift Workspace productivity enhancements"
git push origin main
```
