#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import json,re,shutil,subprocess

repo=Path.cwd();patch=Path(__file__).resolve().parent
m=json.loads((patch/"payload/_batch-b5-manifest.json").read_text(encoding="utf-8"))
if not (repo/"package.json").exists() or not (repo/"_procedures").exists():
    raise SystemExit("ERROR: run from ShiftStart repository root")
if not (repo/"_data/batch-b4-audit-remediation.json").exists():
    raise SystemExit("ERROR: Batch B-4 audit record is missing. Finish/apply Batch B-4 before Batch B-5.")

required=list(m["procedures"])+["troubleshoot-an-external-monitor","investigate-an-antivirus-or-edr-alert"]
missing=[s for s in required if not (repo/"_procedures"/f"{s}.md").exists()]
if missing:raise SystemExit("ERROR: missing procedures: "+", ".join(missing))
before=len(list((repo/"_procedures").glob("*.md")))
if before!=421:raise SystemExit(f"ERROR: expected 421 procedures; found {before}")

# Ensure B4's external-monitor canonical exists before B5 extends it.
canon_text=(repo/"_procedures/troubleshoot-an-external-monitor.md").read_text(encoding="utf-8")
if "definitive-cross-platform-external-monitor-runbook" not in canon_text:
    raise SystemExit("ERROR: Batch B-4 external-monitor merge is not present. Run/validate Batch B-4 first.")

backup=repo/".shiftstart-backups"/("batch-b5-"+datetime.now().strftime("%Y%m%d-%H%M%S"))
targets=[repo/"package.json"]+[repo/"_procedures"/f"{s}.md" for s in required]
for src in targets:
    dst=backup/src.relative_to(repo);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)

def q(v):return "'"+str(v).replace("'","''")+"'"
def set_field(t,k,v):
    p=re.compile(rf"(?m)^({re.escape(k)}:\s*).*$")
    if p.search(t):return p.sub(rf"\g<1>{v}",t,count=1)
    a=t.split("---",2)
    if len(a)<3:raise ValueError(f"front matter missing {k}")
    return "---"+a[1].rstrip()+f"\n{k}: {v}\n---"+a[2]
def block(r):
    xs=["## Mandatory Batch B-5 controls","These audit-derived controls are mandatory before more invasive remediation.","","### Pre-checks"]
    xs += [f"{i+1}. {x}" for i,x in enumerate(r["prechecks"])]
    xs += ["","### Rollback / undo",f"- {r['rollback']}",""]
    return "\n".join(xs)
def add_controls(t,r):
    b=block(r)
    p=re.compile(r"(?ms)^## Mandatory Batch B-5 controls\n.*?(?=^## )")
    if p.search(t):return p.sub(b,t,count=1)
    for a in ["\n## Preconditions and authorisation","\n## Procedure"]:
        i=t.find(a)
        if i!=-1:return t[:i]+"\n"+b+t[i+1:]
    z=t.split("---",2);return "---"+z[1]+"---\n"+b+z[2].lstrip("\n")

for slug,r in m["procedures"].items():
    p=repo/"_procedures"/f"{slug}.md";t=p.read_text(encoding="utf-8")
    t=set_field(t,"severity",r["severity"]);t=set_field(t,"verification_priority",r["priority"])
    t=set_field(t,"classification_audit","batch-b5-2026-08-13")
    t=set_field(t,"risk_basis",q(f"Batch B-5 audit classification: {r['priority']} / {r['severity']}."))
    if slug not in m["merge_policy"]:t=add_controls(t,r)
    p.write_text(t,encoding="utf-8")

# HTTP 500 Step 0.
p=repo/"_procedures/troubleshoot-an-http-500-error.md";t=p.read_text(encoding="utf-8")
marker="0. **Check platform and application health before deployment changes.**"
if marker not in t:
    a="## Procedure\n";step=marker+" Check provider/platform health and active incidents, then capture the exact request timestamp, response detail and application/server logs before restarting or rolling back anything.\n\n"
    if a not in t:raise SystemExit("ERROR: HTTP500 Procedure heading missing")
    t=t.replace(a,a+step,1)
p.write_text(t,encoding="utf-8")

# Directory sync Step 0 and criticality note.
p=repo/"_procedures/troubleshoot-directory-synchronisation.md";t=p.read_text(encoding="utf-8")
marker="0. **Check directory-sync service health before synchronization changes.**"
if marker not in t:
    a="## Procedure\n";step=marker+" Check Microsoft Entra Connect/Cloud Sync health and active service incidents, then inspect connector run history and export/import errors before changing rules or forcing synchronisation.\n\n"
    if a not in t:raise SystemExit("ERROR: directory-sync Procedure heading missing")
    t=t.replace(a,a+step,1)
if "## Directory synchronization escalation gate" not in t:
    b="""## Directory synchronization escalation gate
Keep the runbook P1 by default. Escalate to the organisation's major-incident/P0 process based on actual scope and business impact—such as widespread authentication/provisioning failure or a critical identity dependency—not on elapsed time alone.

"""
    i=t.find("\n## Procedure")
    t=t[:i]+"\n"+b+t[i+1:] if i!=-1 else t+"\n"+b
p.write_text(t,encoding="utf-8")

# Encryption decision path.
p=repo/"_procedures/troubleshoot-disk-encryption-compliance.md";t=p.read_text(encoding="utf-8")
if "## Encryption compliance decision path" not in t:
    b="""## Encryption compliance decision path
1. Confirm actual encryption state and recovery-key escrow in the authoritative MDM/endpoint-management platform.
2. Determine whether the issue is encryption disabled, protection suspended, missing escrow, unhealthy TPM/Secure Enclave, or only stale compliance reporting.
3. Preserve recovery access before firmware, protector or policy changes.
4. Do not decrypt the device as routine remediation; resume protection after authorised maintenance and verify escrow/compliance.

"""
    i=t.find("\n## Procedure")
    t=t[:i]+"\n"+b+t[i+1:] if i!=-1 else t+"\n"+b
p.write_text(t,encoding="utf-8")

# Endpoint protection: health vs incident.
p=repo/"_procedures/troubleshoot-endpoint-protection-health.md";t=p.read_text(encoding="utf-8")
if "## Endpoint protection health decision path" not in t:
    b="""## Endpoint protection health decision path
1. Check EDR/AV console health, last sensor check-in, engine/signature/sensor state and tamper protection.
2. If the device has an active credible threat alert or compromise evidence, stop routine health repair and use `investigate-an-antivirus-or-edr-alert`.
3. For health-only faults, repair management connectivity, policy or the supported sensor/agent without disabling protection as a shortcut.
4. Return the endpoint to normal service only after expected protection and management telemetry are healthy.

"""
    i=t.find("\n## Procedure")
    t=t[:i]+"\n"+b+t[i+1:] if i!=-1 else t+"\n"+b
p.write_text(t,encoding="utf-8")

# Gmail provider health literal Step 0.
p=repo/"_procedures/troubleshoot-gmail-send-or-receive.md";t=p.read_text(encoding="utf-8")
marker="0. **Check Google Workspace service health before mail-flow changes.**"
if marker not in t:
    a="## Procedure\n";step=marker+" Check current Workspace/Gmail service alerts and determine whether the failure is user-specific, policy/routing-specific or domain-wide before changing mail flow.\n\n"
    if a not in t:raise SystemExit("ERROR: Gmail Procedure heading missing")
    t=t.replace(a,a+step,1)
p.write_text(t,encoding="utf-8")

# Linux cert trust decision path.
p=repo/"_procedures/troubleshoot-linux-certificate-trust.md";t=p.read_text(encoding="utf-8")
if "## Linux certificate trust decision path" not in t:
    b="""## Linux certificate trust decision path
1. Verify date/time/NTP and identify which trust store the failing application actually uses.
2. Inspect the presented TLS chain and verification result with approved tooling such as `openssl s_client`.
3. Check hostname, issuer/intermediate chain, expiry and whether the required CA exists in the relevant system/application/container trust store.
4. Back up trust-store configuration before change; restore the previous approved CA/certificate bundle if an authorised update causes regression.

"""
    i=t.find("\n## Procedure")
    t=t[:i]+"\n"+b+t[i+1:] if i!=-1 else t+"\n"+b
p.write_text(t,encoding="utf-8")

# Explicit safety text to make validator robust and user-visible.
for slug,section in {
"troubleshoot-chrome-profile-synchronisation":"""## Sync-data preservation
Do not clear cloud sync data until the authoritative source and a recovery path for user data are confirmed.
""",
"troubleshoot-known-folder-move":"""## Known Folder Move data-preservation rule
Do not blindly stop sync, unlink OneDrive or move redirected folders. First establish the authoritative local/cloud copy and preserve unsynchronised user data.
""",
"troubleshoot-google-drive-synchronisation":"""## Google Drive data-preservation rule
Preserve unsynchronised local data before repair and do not overwrite cloud data merely to force synchronisation.
""",
"troubleshoot-blocked-browser-downloads":"""## Security-control rule
If browser, EDR, DLP, web-filter or reputation tooling blocks/quarantines the file, do not release it automatically. Use the approved security/false-positive review process.
""",
}.items():
    p=repo/"_procedures"/f"{slug}.md";t=p.read_text(encoding="utf-8")
    header=section.split("\n",1)[0]
    if header not in t:
        i=t.find("\n## Procedure")
        t=t[:i]+"\n"+section+"\n"+t[i+1:] if i!=-1 else t+"\n"+section
    p.write_text(t,encoding="utf-8")

# Extend B4 external-monitor canonical, then deprecate B5 arrangement page.
p=repo/"_procedures/troubleshoot-an-external-monitor.md";t=p.read_text(encoding="utf-8")
if "### Arrangement and resolution branch" not in t:
    branch="""### Arrangement and resolution branch
- Confirm all expected displays are detected before changing arrangement or resolution.
- Record the current topology, primary display, orientation, scaling and resolution.
- Apply supported/native resolutions and arrange displays to match physical placement.
- If a confirmed graphics/display driver change caused regression, restore the previous approved driver/configuration.

"""
    anchor="### No-signal branch"
    i=t.find(anchor)
    if i!=-1:
        # insert before next top-level section after no-signal branch
        j=t.find("\n## ",i)
        if j==-1:j=len(t)
        t=t[:j]+"\n"+branch+t[j:]
    else:
        i=t.find("\n## Procedure")
        t=t[:i]+"\n"+branch+t[i+1:] if i!=-1 else t+"\n"+branch
p.write_text(t,encoding="utf-8")

p=repo/"_procedures/troubleshoot-multiple-monitor-arrangement-or-resolution.md";old=p.read_text(encoding="utf-8")
a=old.split("---",2)
if len(a)<3:raise SystemExit("ERROR: multiple-monitor front matter invalid")
front="---"+a[1]+"---\n"
front=set_field(front,"severity","low")
front=set_field(front,"verification_priority","P3")
front=set_field(front,"content_status","deprecated")
front=set_field(front,"verification_governance_state","deprecated")
front=set_field(front,"canonical_procedure","troubleshoot-an-external-monitor")
front=set_field(front,"deprecation_reason",q("Merged into the definitive cross-platform external-monitor runbook during Batch B-5 audit."))
body="""## Deprecated — use the definitive external-monitor procedure
This procedure has been merged into **Troubleshoot an external monitor**.

Use `/procedures/troubleshoot-an-external-monitor/`.

The canonical runbook now includes an arrangement/resolution branch in addition to Windows, macOS and no-signal diagnostics. This page remains only to preserve historical links.
"""
p.write_text(front+body,encoding="utf-8")

# Install manifest, docs, validator.
for src in (patch/"payload").rglob("*"):
    if not src.is_file() or src.name=="_batch-b5-manifest.json":continue
    rel=src.relative_to(patch/"payload");dst=repo/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
dst=repo/"_data/batch-b5-audit-remediation.json";dst.parent.mkdir(parents=True,exist_ok=True)
shutil.copy2(patch/"payload/_batch-b5-manifest.json",dst)

pkgp=repo/"package.json";pkg=json.loads(pkgp.read_text(encoding="utf-8"));scripts=pkg.setdefault("scripts",{})
scripts["batch:b5:check"]="python3 scripts/validate-batch-b5-remediation.py"
check=scripts.get("check","")
if "npm run batch:b5:check" not in check:scripts["check"]=(check+" && " if check else "")+"npm run batch:b5:check"
pkgp.write_text(json.dumps(pkg,indent=2)+"\n",encoding="utf-8")

r=subprocess.run(["python3","scripts/validate-batch-b5-remediation.py"],cwd=repo)
if r.returncode:raise SystemExit("ERROR: Batch B-5 validator failed")
after=len(list((repo/"_procedures").glob("*.md")))
if after!=before:raise SystemExit(f"ERROR: procedure count changed {before}->{after}")

print("")
print("Batch B-5 remediation applied.")
print("No procedure was promoted to Verified.")
print("Backup:",backup.relative_to(repo))
