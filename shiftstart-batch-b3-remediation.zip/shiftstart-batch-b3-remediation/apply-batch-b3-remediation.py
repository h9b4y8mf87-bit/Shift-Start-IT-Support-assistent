#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import json, re, shutil, subprocess

repo=Path.cwd()
patch=Path(__file__).resolve().parent
manifest=json.loads((patch/"payload/_batch-b3-manifest.json").read_text(encoding="utf-8"))

if not (repo/"package.json").exists() or not (repo/"_procedures").exists():
    raise SystemExit("ERROR: run from ShiftStart repository root")

required=list(manifest["procedures"]) + [
    "trace-an-active-directory-account-lockout-source",
]
missing=[slug for slug in required if not (repo/"_procedures"/f"{slug}.md").exists()]
if missing:
    raise SystemExit("ERROR: missing procedures: "+", ".join(missing))

before=len(list((repo/"_procedures").glob("*.md")))
if before != 421:
    raise SystemExit(f"ERROR: expected 421 procedures; found {before}")

backup=repo/".shiftstart-backups"/("batch-b3-"+datetime.now().strftime("%Y%m%d-%H%M%S"))
for src in [repo/"package.json"]+[repo/"_procedures"/f"{slug}.md" for slug in required]:
    dst=backup/src.relative_to(repo)
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dst)

def q(v): return "'" + str(v).replace("'","''") + "'"

def set_field(text,key,value):
    pat=re.compile(rf"(?m)^({re.escape(key)}:\s*).*$")
    if pat.search(text):
        return pat.sub(rf"\g<1>{value}",text,count=1)
    parts=text.split("---",2)
    if len(parts)<3: raise ValueError(f"front matter missing: {key}")
    return "---"+parts[1].rstrip()+f"\n{key}: {value}\n---"+parts[2]

def list_field(text,key):
    parts=text.split("---",2)
    fm=parts[1] if len(parts)>=3 else ""
    lines=fm.splitlines(); out=[]; active=False
    for line in lines:
        if re.match(rf"^{re.escape(key)}:\s*$",line):
            active=True; continue
        if active:
            m=re.match(r"^\s*-\s+(.*)$",line)
            if m: out.append(m.group(1).strip().strip("'\""))
            elif line and not line.startswith(" "): break
    return out

def control_block(rec):
    lines=[
        "## Mandatory Batch B-3 controls",
        "These audit-derived controls are mandatory before more invasive remediation.",
        "",
        "### Pre-checks",
    ]
    lines += [f"{i+1}. {x}" for i,x in enumerate(rec["prechecks"])]
    lines += ["","### Rollback / undo",f"- {rec['rollback']}",""]
    return "\n".join(lines)

def add_controls(text,rec):
    block=control_block(rec)
    pat=re.compile(r"(?ms)^## Mandatory Batch B-3 controls\n.*?(?=^## )")
    if pat.search(text):
        return pat.sub(block,text,count=1)
    for anchor in ["\n## Preconditions and authorisation","\n## Diagnostic Steps","\n## Procedure"]:
        idx=text.find(anchor)
        if idx!=-1:
            return text[:idx]+"\n"+block+text[idx+1:]
    parts=text.split("---",2)
    return "---"+parts[1]+"---\n"+block+parts[2].lstrip("\n")

# Apply taxonomy and controls.
for slug,rec in manifest["procedures"].items():
    p=repo/"_procedures"/f"{slug}.md"
    t=p.read_text(encoding="utf-8")
    t=set_field(t,"severity",rec["severity"])
    t=set_field(t,"verification_priority",rec["priority"])
    t=set_field(t,"classification_audit","batch-b3-2026-08-13")
    t=set_field(t,"risk_basis",q(f"Batch B-3 audit classification: {rec['priority']} / {rec['severity']}."))
    if slug not in manifest["merge_policy"]:
        t=add_controls(t,rec)
    p.write_text(t,encoding="utf-8")
    print(f"{slug}: {rec['priority']}/{rec['severity']}")

# Literal Step 0 corrections for the 10 blocked procedures.
step0={
"deprovision-a-departing-user-account":"0. **Verify authorised offboarding before action.** Confirm the approved HR/identity-lifecycle record, effective time, target identity and any legal/retention constraints before disabling access or altering data.\n\n",
"escalate-a-legal-hold-or-retention-request":"0. **Verify Legal/Compliance authority before action.** Confirm the authorised case/ticket, custodians, scope and written instruction before placing, changing or releasing a hold.\n\n",
"handle-a-sensitive-data-misdelivery":"0. **Contain the data exposure immediately.** Revoke the affected sharing path/session or use approved mail/security containment while preserving evidence; then determine recipients, access and classification.\n\n",
"investigate-an-antivirus-or-edr-alert":"0. **Contain a credible active threat before ordinary investigation.** For an active or high-severity threat, isolate the affected endpoint through approved EDR/network controls and preserve the alert evidence.\n\n",
"perform-an-approved-remote-wipe":"0. **Verify wipe authority and exact device before issuing the command.** Confirm ownership, serial/asset identity, wipe scope and required approvals. If any element is uncertain, abort; a remote wipe is irreversible.\n\n",
"recover-a-device-requesting-a-bitlocker-recovery-key":"0. **Verify identity and exact device before using a recovery key.** Match the managed device and recovery-key ID to the authorised escrow record; never copy the secret into the ticket.\n\n",
"recover-a-mac-requesting-a-filevault-recovery-key":"0. **Verify identity and exact Mac before using a recovery key.** Match the managed Mac/escrow record before disclosing or applying the FileVault recovery secret.\n\n",
"recover-data-from-a-failing-drive-safely":"0. **Stop normal use and protect the source drive first.** If physical-failure signs or serious media errors exist, stop and escalate to approved recovery specialists; verify backups before any recovery attempt.\n\n",
"report-and-contain-a-phishing-email":"0. **Report and contain the phishing message immediately.** Preserve message/header evidence and use approved mail/security tooling to quarantine/purge confirmed malicious content and block confirmed indicators.\n\n",
"resolve-a-conditional-access-block":"0. **Check Entra service health before policy changes.** Confirm no active service incident, then use sign-in and Conditional Access evaluation evidence to identify the exact policy and reason for the block.\n\n",
}
for slug,block in step0.items():
    p=repo/"_procedures"/f"{slug}.md"; t=p.read_text(encoding="utf-8")
    marker=block.split("\n",1)[0]
    if marker not in t:
        anchor="## Procedure\n"
        if anchor not in t:
            raise SystemExit(f"ERROR: Procedure heading missing in {slug}")
        t=t.replace(anchor,anchor+block,1)
    # Security/evidence procedures must not ask users to reproduce dangerous activity.
    if slug in {"handle-a-sensitive-data-misdelivery","investigate-an-antivirus-or-edr-alert","report-and-contain-a-phishing-email"}:
        t=t.replace(
            "1. **Confirm the report and reproduce safely.** Ask the user to demonstrate the original task or reproduce it with non-sensitive test data. Do not repeatedly trigger lockouts, failed jobs, duplicate transactions or destructive actions.",
            "1. **Confirm the incident without recreating the risky action.** Validate the report from preserved telemetry, message/log evidence and user statements. Do not re-open, resend or re-execute suspicious content merely to reproduce the incident."
        )
    p.write_text(t,encoding="utf-8")

# Printer duplicate -> one definitive P2 driver/device management runbook.
canon=repo/"_procedures/install-or-update-a-printer-driver.md"
ct=canon.read_text(encoding="utf-8")
ct=set_field(ct,"canonical_role","definitive-printer-driver-device-management")
decision="\n".join([
"## Printer driver and device management decision path",
"- Update/install branch: verify model, architecture/OS compatibility, signed/trusted source and current driver before change.",
"- Clean reinstall branch: export current printer/driver configuration with approved tooling such as Printbrm before removing the queue/driver.",
"- Check disk space and Print Spooler health before extracting/installing drivers.",
"- If the new driver causes regression, restore the previous approved driver/configuration and verify a controlled print job.",
"",
])
if "## Printer driver and device management decision path" not in ct:
    idx=ct.find("\n## Procedure")
    if idx==-1: idx=ct.find("\n## Diagnostic Steps")
    if idx==-1: raise SystemExit("ERROR: cannot insert printer decision path")
    ct=ct[:idx]+"\n"+decision+ct[idx+1:]
canon.write_text(ct,encoding="utf-8")

dup=repo/"_procedures/remove-and-reinstall-a-printer-cleanly.md"
dt=dup.read_text(encoding="utf-8")
parts=dt.split("---",2)
front="---"+parts[1]+"---\n"
front=set_field(front,"severity","medium")
front=set_field(front,"verification_priority","P2")
front=set_field(front,"content_status","deprecated")
front=set_field(front,"verification_governance_state","deprecated")
front=set_field(front,"canonical_procedure","install-or-update-a-printer-driver")
front=set_field(front,"deprecation_reason",q("Merged into the definitive Printer Driver & Device Management runbook during Batch B-3 audit."))
dup.write_text(front+"""## Deprecated — use the definitive printer driver/device procedure
This workflow has been merged into **Install or update a printer driver**.

Use `/procedures/install-or-update-a-printer-driver/`.

The canonical procedure now contains update, clean-reinstall, rollback and verification branches. This page remains to preserve historical links.
""",encoding="utf-8")

# Repeated lockouts -> canonical B1 account-lockout source runbook.
lockcanon=repo/"_procedures/trace-an-active-directory-account-lockout-source.md"
lt=lockcanon.read_text(encoding="utf-8")
if "## Repeated lockout decision path" not in lt:
    block="""## Repeated lockout decision path
Use this as the definitive account-lockout source runbook. Correlate domain-controller lockout evidence, stale cached credentials, services/scheduled tasks, mapped resources and mobile clients before repeatedly unlocking the user.

"""
    idx=lt.find("\n## Procedure")
    if idx==-1: idx=lt.find("\n## Diagnostic Steps")
    if idx==-1: raise SystemExit("ERROR: cannot insert lockout decision path")
    lt=lt[:idx]+"\n"+block+lt[idx+1:]
lockcanon.write_text(lt,encoding="utf-8")

ldup=repo/"_procedures/investigate-repeated-account-lockouts.md"
ldt=ldup.read_text(encoding="utf-8")
parts=ldt.split("---",2)
front="---"+parts[1]+"---\n"
front=set_field(front,"severity","medium")
front=set_field(front,"verification_priority","P2")
front=set_field(front,"content_status","deprecated")
front=set_field(front,"verification_governance_state","deprecated")
front=set_field(front,"canonical_procedure","trace-an-active-directory-account-lockout-source")
front=set_field(front,"deprecation_reason",q("Merged into the definitive Active Directory account-lockout source runbook during Batch B-3 audit."))
ldup.write_text(front+"""## Deprecated — use the definitive account-lockout source procedure
This procedure has been merged into **Trace an Active Directory account lockout source**.

Use `/procedures/trace-an-active-directory-account-lockout-source/`.

This page remains only to preserve historical links.
""",encoding="utf-8")

# Identity lifecycle module relationship (cross-reference, not destructive merge).
lifecycle_text="""## Identity lifecycle relationship
This procedure is part of the governed Joiner/Mover/Leaver lifecycle.

- **Provision:** `provision-a-new-user-account`
- **Deprovision:** `deprovision-a-departing-user-account`

Both workflows must use an approved HR/identity-lifecycle record, least privilege, dated ownership/approval and auditable completion evidence. Deprovisioning additionally enforces legal/retention preservation and immediate access revocation at the authorised effective time.

"""
for slug in ["deprovision-a-departing-user-account","provision-a-new-user-account"]:
    p=repo/"_procedures"/f"{slug}.md"; t=p.read_text(encoding="utf-8")
    if "## Identity lifecycle relationship" not in t:
        idx=t.find("\n## Procedure")
        if idx==-1: idx=t.find("\n## Diagnostic Steps")
        if idx==-1: raise SystemExit(f"ERROR: cannot add lifecycle relationship to {slug}")
        t=t[:idx]+"\n"+lifecycle_text+t[idx+1:]
    p.write_text(t,encoding="utf-8")

# Symptom mapping correction for BitLocker/FileVault-specific symptoms only.
def related_symptoms(text):
    parts=text.split("---",2)
    f=parts[1] if len(parts)>=3 else ""
    out=[]; active=False
    for line in f.splitlines():
        if re.match(r"^related_symptoms:\s*$",line):
            active=True; continue
        if active:
            m=re.match(r"^\s*-\s+(.*)$",line)
            if m: out.append(m.group(1).strip().strip("'\""))
            elif line and not line.startswith(" "): break
    return out

for proc_slug,policy in manifest["symptom_mapping_policy"].items():
    pt=(repo/"_procedures"/f"{proc_slug}.md").read_text(encoding="utf-8")
    rel=related_symptoms(pt)
    matches=[s for s in rel if all(term in s.lower() for term in policy["match_terms"])]
    if not matches:
        raise SystemExit(f"ERROR: could not identify specific recovery-key symptom for {proc_slug}")
    for symptom_slug in matches:
        sp=repo/"_symptoms"/f"{symptom_slug}.md"
        if not sp.exists():
            raise SystemExit(f"ERROR: missing symptom {symptom_slug}")
        # Back up discovered symptom before editing.
        dst=backup/sp.relative_to(repo)
        dst.parent.mkdir(parents=True,exist_ok=True)
        if not dst.exists(): shutil.copy2(sp,dst)
        st=sp.read_text(encoding="utf-8")
        st=set_field(st,"severity",policy["target_severity"])
        st=set_field(st,"classification_audit","batch-b3-2026-08-13")
        sp.write_text(st,encoding="utf-8")
        print(f"Symptom {symptom_slug}: {policy['target_severity']}")

# Install audit record, pure-Python validator and docs.
for src in (patch/"payload").rglob("*"):
    if not src.is_file() or src.name=="_batch-b3-manifest.json": continue
    rel=src.relative_to(patch/"payload")
    dst=repo/rel
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dst)

audit=repo/"_data/batch-b3-audit-remediation.json"
audit.parent.mkdir(parents=True,exist_ok=True)
shutil.copy2(patch/"payload/_batch-b3-manifest.json",audit)

pkgp=repo/"package.json"
pkg=json.loads(pkgp.read_text(encoding="utf-8"))
scripts=pkg.setdefault("scripts",{})
scripts["batch:b3:check"]="python3 scripts/validate-batch-b3-remediation.py"
check=scripts.get("check","")
if "npm run batch:b3:check" not in check:
    scripts["check"]=(check+" && " if check else "")+"npm run batch:b3:check"
pkgp.write_text(json.dumps(pkg,indent=2)+"\n",encoding="utf-8")

# Pure Python validation; no Node dependencies required.
r=subprocess.run(["python3","scripts/validate-batch-b3-remediation.py"],cwd=repo)
if r.returncode:
    raise SystemExit("ERROR: Batch B-3 validator failed")

after=len(list((repo/"_procedures").glob("*.md")))
if after!=before:
    raise SystemExit(f"ERROR: procedure count changed {before}->{after}")

print("")
print("Batch B-3 remediation applied.")
print("No procedure was promoted to Verified.")
print("Backup:",backup.relative_to(repo))
print("")
print("Next:")
print("  npm install --no-audit --no-fund")
print("  npm run verification:v2:apply")
print("  npm run verification:queue")
print("  npm run verification:batches")
print("  npm run batch:b3:check")
print("  npm run check")
print("  npm run build")
