#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import shutil, sys, re

repo = Path.cwd()
header_path = repo / '_includes' / 'header.html'
css_path = repo / 'assets' / 'css' / 'header-enterprise-fix.css'

for p in (header_path, css_path):
    if not p.exists():
        raise SystemExit(f'ERROR: Missing required file: {p}. Run from the ShiftStart repo root.')

header = header_path.read_text(encoding='utf-8')
css = css_path.read_text(encoding='utf-8')

if 'ss-enterprise-header' not in header:
    raise SystemExit('ERROR: Current enterprise header marker was not found. Apply the enterprise header fix first.')

stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
backup = repo / '.shiftstart-backups' / f'header-responsive-search-{stamp}'
for p in (header_path, css_path):
    rel = p.relative_to(repo)
    dest = backup / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, dest)

mobile_search = '''        <form class="rd-global-search ss-mobile-search" action="{{ '/search/' | relative_url }}" method="get" role="search" data-search-region>
          <svg class="rd-search-icon" aria-hidden="true" viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"></circle><path d="m20 20-3.5-3.5"></path></svg>
          <label class="sr-only" for="kb-search">Search symptoms, procedures, domains or error codes</label>
          <input id="kb-search" class="search-input rd-search-input ss-mobile-search-input" type="search" name="q" inputmode="search" enterkeyhint="search" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="Search symptom, error code or procedure…" aria-controls="search-results" aria-autocomplete="list" aria-expanded="false">
          <button class="search-clear rd-search-clear ss-mobile-search-clear" type="button" data-search-clear aria-label="Clear search" hidden>Clear</button>
          <div id="search-results" class="search-results rd-search-results ss-mobile-search-results hidden" role="listbox" aria-label="Search suggestions"></div>
          <p id="search-status" class="sr-only" aria-live="polite"></p>
        </form>
'''

if 'ss-mobile-search' not in header:
    pattern = r'(?m)^(\s*)<div class="shell ss-mobile-nav-grid">\s*$'
    match = re.search(pattern, header)
    if not match:
        raise SystemExit('ERROR: Could not find the enterprise mobile navigation grid insertion point.')
    indent = match.group(1)
    insertion = match.group(0) + '\n' + mobile_search
    header = header[:match.start()] + insertion + header[match.end():]
    header_path.write_text(header, encoding='utf-8')
    print('Updated: _includes/header.html')
else:
    print('Header already contains the mobile quick-search control.')

css_patch = r'''

/* === ShiftStart enterprise header responsive-search repair === */
.ss-mobile-search{
  position:relative;
  grid-column:1/-1;
  display:grid;
  grid-template-columns:auto minmax(0,1fr) auto;
  align-items:center;
  gap:.5rem;
  min-width:0;
  margin:0 0 .25rem;
  border:1px solid rgba(174,202,226,.16);
  border-radius:.76rem;
  background:rgba(255,255,255,.055);
  padding:.38rem .45rem .38rem .68rem;
}
.ss-mobile-search .rd-search-icon{
  position:static;
  transform:none;
  color:#9fb5c8;
  pointer-events:none;
}
.ss-mobile-search-input{
  width:100%;
  min-width:0;
  min-height:2.5rem;
  border:0!important;
  outline:0;
  background:transparent!important;
  padding:.42rem .15rem!important;
  color:#f5f9fc!important;
  font:inherit;
  font-size:.82rem;
}
.ss-mobile-search-input::placeholder{color:#96adbf;opacity:1}
.ss-mobile-search-input:focus-visible{box-shadow:none!important}
.ss-mobile-search:focus-within{
  border-color:rgba(91,201,176,.55);
  box-shadow:0 0 0 3px rgba(35,185,149,.11);
}
.ss-mobile-search-clear{
  position:static!important;
  min-height:2.1rem;
  border:1px solid rgba(255,255,255,.12)!important;
  border-radius:.5rem!important;
  background:rgba(255,255,255,.07)!important;
  padding:.32rem .48rem!important;
  color:#d9e7f1!important;
  font:inherit;
  font-size:.68rem!important;
  font-weight:800!important;
  cursor:pointer;
}
.ss-mobile-search-clear:hover{background:rgba(255,255,255,.12)!important;color:#fff!important}
.ss-mobile-search-results{
  position:absolute!important;
  top:calc(100% + .36rem)!important;
  right:0!important;
  left:0!important;
  z-index:130!important;
  max-height:min(52vh,24rem);
  overflow:auto;
  border:1px solid rgba(174,202,226,.18)!important;
  border-radius:.78rem!important;
  background:#10283e!important;
  box-shadow:0 18px 42px rgba(1,12,23,.34)!important;
}
.ss-mobile-search-results .rd-search-result{color:#e9f2f8!important}
.ss-mobile-search-results .rd-search-result p,
.ss-mobile-search-results .rd-search-result-meta{color:#a9becf!important}
.ss-mobile-search-results .rd-search-result:hover,
.ss-mobile-search-results .rd-search-result.active{background:rgba(255,255,255,.075)!important}
.ss-mobile-search-results .rd-view-all-results{color:#75dcc1!important}
.ss-mobile-search-results .rd-search-empty{color:#c8d8e4!important}

@media(min-width:681px){
  .ss-mobile-search{display:none}
}

@media(max-width:680px){
  .ss-mobile-search{display:grid}
}

@media(max-width:420px){
  .ss-mobile-search{grid-template-columns:auto minmax(0,1fr)}
  .ss-mobile-search-clear{grid-column:1/-1;justify-self:end}
}

@media(forced-colors:active){
  .ss-mobile-search,.ss-mobile-search-clear,.ss-mobile-search-results{
    border-color:CanvasText!important;
    background:Canvas!important;
    color:CanvasText!important;
  }
  .ss-mobile-search-input{color:CanvasText!important}
}
/* === End responsive-search repair === */
'''

if 'enterprise header responsive-search repair' not in css:
    css_path.write_text(css.rstrip() + css_patch + '\n', encoding='utf-8')
    print('Updated: assets/css/header-enterprise-fix.css')
else:
    print('Responsive-search CSS already present.')

# Validate the exact CI hooks that failed.
final_header = header_path.read_text(encoding='utf-8')
required = {
    'inputmode="search"': 'mobile search keyboard hint',
    'data-search-clear': 'search clear control',
    'id="kb-search"': 'search input hook',
    'id="search-results"': 'search result hook',
    'data-search-region': 'search interaction region',
    'data-menu-toggle': 'mobile navigation toggle',
    'mobile-navigation': 'mobile navigation region',
}
missing = [label for token, label in required.items() if token not in final_header]
if missing:
    raise SystemExit('ERROR: Header validation failed; missing: ' + ', '.join(missing))

print('')
print('Header responsive-search repair applied successfully.')
print('Backup:', backup.relative_to(repo))
print('Next: npm run responsive:check && npm run check')
