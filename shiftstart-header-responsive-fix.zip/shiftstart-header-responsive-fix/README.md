# ShiftStart Header Responsive Search Repair

This is a narrow follow-up patch for the enterprise header.

## Why it exists

The enterprise header redesign intentionally replaced the old full-width global search bar with the Ctrl+K command palette. The existing responsive CI validator still requires a mobile-native search input and clear control in `_includes/header.html`, and `assets/js/search.js` still enhances those hooks.

This patch restores a **real mobile quick-search field inside the mobile navigation drawer**. It does not add dummy hidden markup and does not change the desktop enterprise header.

## Changes

- `_includes/header.html`
  - Adds `#kb-search`
  - Adds `inputmode="search"` and `enterkeyhint="search"`
  - Adds `data-search-clear`
  - Adds `#search-results`, `#search-status`, and `data-search-region`
- `assets/css/header-enterprise-fix.css`
  - Styles the mobile search field and suggestions for the enterprise dark header
  - Keeps the field hidden above the mobile breakpoint
  - Adds forced-colour support

## Apply

From the ShiftStart repository root:

```bash
git status
git fetch origin
git pull --rebase origin main

unzip -q shiftstart-header-responsive-fix.zip
python3 shiftstart-header-responsive-fix/apply-header-responsive-fix.py
```

Then validate the exact failed gate first:

```bash
npm run responsive:check
```

Then the full suite:

```bash
npm run check
npm run build
```

If all checks pass:

```bash
rm -f shiftstart-header-responsive-fix.zip
rm -rf shiftstart-header-responsive-fix
rm -rf .shiftstart-backups

git restore reports/content-audit.json 2>/dev/null || true

git add -A
git status
git commit -m "Restore responsive search controls in enterprise header"
git push origin main
```
