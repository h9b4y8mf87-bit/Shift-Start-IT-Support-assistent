#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import shutil, sys, json

repo = Path.cwd()
patch = Path(__file__).resolve().parent
payload = patch / "payload"

required = [
    repo / "package.json",
    repo / "_data/verification-policy.yml",
    repo / "scripts/verification-v2.js",
    repo / "scripts/validate-verification-v2.js",
]
missing = [str(p) for p in required if not p.exists()]
if missing:
    print("ERROR: M1 Day 1-2 Verification Governance v2 must be installed first.", file=sys.stderr)
    for item in missing: print("-", item, file=sys.stderr)
    raise SystemExit(1)

policy_text = (repo / "_data/verification-policy.yml").read_text(encoding="utf-8")
if "schema_version: 2" not in policy_text or "verification_governance_state" not in policy_text:
    raise SystemExit("ERROR: Verification Governance v2 markers not found. Apply Day 1-2 first.")

protected = ["_procedures","_symptoms","_causes","_commands"]
before = {n: len(list((repo/n).glob("*.md"))) if (repo/n).exists() else 0 for n in protected}

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = repo / ".shiftstart-backups" / f"m1-day3-{stamp}"
package_path = repo / "package.json"
backup.mkdir(parents=True, exist_ok=True)
shutil.copy2(package_path, backup / "package.json")

for src in payload.rglob("*"):
    if not src.is_file(): continue
    rel = src.relative_to(payload)
    dst = repo / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    print("Installed:", rel)

pkg = json.loads(package_path.read_text(encoding="utf-8"))
scripts = pkg.setdefault("scripts", {})
scripts["verification:queue"] = "node scripts/build-verification-priority-queue.js"
scripts["verification:queue:check"] = "node scripts/validate-verification-priority-queue.js"
# Add queue validation to check without replacing existing gates.
current = scripts.get("check","")
queue_check = "npm run verification:queue && npm run verification:queue:check"
if "verification:queue" not in current:
    scripts["check"] = current + " && " + queue_check if current else queue_check
package_path.write_text(json.dumps(pkg, indent=2) + "\n", encoding="utf-8")
print("Updated: package.json")

after = {n: len(list((repo/n).glob("*.md"))) if (repo/n).exists() else 0 for n in protected}
if before != after:
    raise SystemExit(f"ERROR: Knowledge collection counts changed. Before={before} After={after}")

checks = {
    "_data/verification-priority-policy.yml": ["verification-priority-v1","temporary_topic_proxy","evidence_readiness"],
    "_data/verification-demand.yml": ["Do not invent counts","procedures: {}"],
    "scripts/build-verification-priority-queue.js": ["Verification Priority Score","temporary_topic_proxy","top50"],
    "scripts/validate-verification-priority-queue.js": ["Verification priority queue validation passed"],
}
for rel,tokens in checks.items():
    text=(repo/rel).read_text(encoding="utf-8")
    missing_tokens=[t for t in tokens if t not in text]
    if missing_tokens:
        raise SystemExit(f"ERROR: {rel} missing expected markers: {missing_tokens}")

print("")
print("M1 Day 3 verification priority queue installed.")
print("Knowledge collection counts preserved:", before)
print("Backup:", backup.relative_to(repo))
print("")
print("Next run:")
print("  npm run verification:v2:apply")
print("  npm run verification:queue")
print("  npm run verification:queue:check")
print("  npm run check")
