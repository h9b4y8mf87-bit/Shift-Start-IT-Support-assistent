# ShiftStart M1 Day 3 — Verification Priority Queue

Prerequisite: M1 Day 1–2 Verification Governance v2 must already be installed.

## What this implements

- demand-weighted verification backlog;
- transparent 0–100 priority score;
- risk + demand + escalation + business criticality + evidence-readiness scoring;
- actionable queue bands;
- top-50 and top-10 verification candidate outputs;
- CSV/JSON reports;
- no automatic procedure promotion;
- no invented search counts.

## Apply

```bash
git status
git fetch origin
git pull --rebase origin main

unzip -q shiftstart-m1-day3-verification-priority-queue.zip

python3 \
  shiftstart-m1-day3-verification-priority-queue/apply-m1-day3.py
```

Then:

```bash
npm install --no-audit --no-fund

npm run verification:v2:apply
npm run verification:queue
npm run verification:queue:check

npm run check
```

Inspect the queue:

```bash
head -25 reports/verification-priority-queue.csv
```

or:

```bash
node -e "const r=require('./reports/verification-priority-queue.json'); console.table(r.top50.slice(0,15).map(x=>({rank:x.rank,priority:x.priority,score:x.priority_score,slug:x.slug,band:x.queue_band,demand:x.search_demand_source})))"
```

If validation passes:

```bash
rm -f shiftstart-m1-day3-verification-priority-queue.zip
rm -rf shiftstart-m1-day3-verification-priority-queue
rm -rf .shiftstart-backups

git restore reports/content-audit.json 2>/dev/null || true

git add -A
git status
git commit -m "Add verification priority queue"
git push origin main
```
