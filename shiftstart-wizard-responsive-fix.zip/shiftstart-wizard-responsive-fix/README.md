# ShiftStart responsive symptom wizard fix

This patch corrects the unstyled inline symptom list shown in the enterprise wizard.

It adds:

- one-column symptom cards on phones;
- two columns on tablets;
- three columns on ordinary desktops;
- four columns on ultrawide screens;
- readable checkbox, title and description spacing;
- responsive category headings and count badges;
- a compact selected-symptom area;
- a sticky safe-area-aware submit panel;
- keyboard, high-contrast and reduced-motion handling.

## Apply in Codespaces

Run from the repository root:

```bash
unzip -q shiftstart-wizard-responsive-fix.zip

python3 shiftstart-wizard-responsive-fix/apply-wizard-responsive-fix.py

npm run check

rm -f shiftstart-wizard-responsive-fix.zip
rm -rf shiftstart-wizard-responsive-fix

git add -A
git commit -m "Fix responsive symptom wizard layout"
git push
```

After GitHub Pages deploys, refresh the website with Ctrl+F5.
On iPhone or iPad, close and reopen the tab if Safari retains the old CSS.
