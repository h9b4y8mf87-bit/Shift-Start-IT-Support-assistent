#!/usr/bin/env python3
from pathlib import Path
import sys

MARKER_START = "/* === ShiftStart responsive symptom wizard fix === */"
MARKER_END = "/* === End ShiftStart responsive symptom wizard fix === */"

repo = Path.cwd()
target = repo / "_assets" / "css" / "tailwind.css"
patch_css = Path(__file__).with_name("wizard-responsive-fix.css").read_text(encoding="utf-8")

if not target.exists():
    print(f"ERROR: {target} was not found. Run this script from the repository root.", file=sys.stderr)
    raise SystemExit(1)

original = target.read_text(encoding="utf-8")

if MARKER_START in original and MARKER_END in original:
    before = original.split(MARKER_START, 1)[0].rstrip()
    after = original.split(MARKER_END, 1)[1].lstrip()
    updated = before + "\n\n" + patch_css
    if after:
        updated += "\n" + after
else:
    updated = original.rstrip() + "\n\n" + patch_css

target.write_text(updated, encoding="utf-8")

required = [
    ".symptom-grid",
    ".symptom-option",
    ".symptom-group",
    ".wizard-count",
    ".wizard-submit",
]
missing = [token for token in required if token not in updated]
if missing:
    print("ERROR: Required responsive selectors are missing:", ", ".join(missing), file=sys.stderr)
    raise SystemExit(1)

print("Responsive wizard fix applied successfully.")
print("Updated:", target)
print("Breakpoints: phone, tablet, desktop and ultrawide.")
print("All symptom content remains unchanged.")
