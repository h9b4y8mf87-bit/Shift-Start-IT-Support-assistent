# ShiftStart operational UX hardening

This enhancement responds to the second usability review without undoing the existing operational-dashboard redesign.

The current site already has persistent navigation, global search, a dedicated Wizard page, above-the-fold CTAs, coloured risk/status badges, breadcrumbs, related knowledge, skip-link support and responsive layouts. This patch strengthens the remaining gaps.

## Added

- Dynamic Domains switcher in the desktop header.
- Stronger visual prominence for Wizard navigation.
- Sticky procedure Quick Glance:
  - risk;
  - review status;
  - support tier;
  - estimated time;
  - owner.
- Focus mode for technicians executing long runbooks.
- Automatic visual grouping of existing Markdown sections:
  - Evidence;
  - Safety / Risk;
  - Diagnostic;
  - Remediation;
  - Rollback;
  - Verification;
  - Escalation.
- Stronger numbered-step styling without modifying procedure text.
- More explicit Under Review deterrence.
- Status symbols in addition to colour.
- Strong keyboard focus-visible styling.
- Restores the `catalog-filter-panel` marker required by responsive CI.

No Markdown knowledge content is edited.

## Apply

Make sure your local branch is clean first:

```bash
git status
git fetch origin
git pull --rebase origin main
```

Then upload the ZIP and run:

```bash
unzip -q shiftstart-operational-ux-hardening.zip

python3   shiftstart-operational-ux-hardening/apply-operational-ux-hardening.py

npm install --no-audit --no-fund
npm run check

rm -f shiftstart-operational-ux-hardening.zip
rm -rf shiftstart-operational-ux-hardening

git add -A
git status
git commit -m "Harden technician navigation and procedure UX"
git push origin main
```
