#!/usr/bin/env python3
from pathlib import Path
import shutil, sys

repo = Path.cwd()
patch = Path(__file__).resolve().parent
payload = patch / "payload"

required = [
    repo / "_layouts" / "default.html",
    repo / "_layouts" / "article.html",
    repo / "_layouts" / "list.html",
    repo / "_includes" / "header.html",
]
missing = [str(path) for path in required if not path.exists()]
if missing:
    print("ERROR: Run this from the ShiftStart repository root.", file=sys.stderr)
    for item in missing:
        print("-", item, file=sys.stderr)
    raise SystemExit(1)

protected = ["_procedures", "_symptoms", "_causes", "_commands"]
before = {
    name: len(list((repo / name).glob("*.md"))) if (repo / name).exists() else 0
    for name in protected
}

for source in payload.rglob("*"):
    if not source.is_file():
        continue
    relative = source.relative_to(payload)
    target = repo / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    print("Updated:", relative)

after = {
    name: len(list((repo / name).glob("*.md"))) if (repo / name).exists() else 0
    for name in protected
}
if before != after:
    print("ERROR: Protected Markdown counts changed.", file=sys.stderr)
    print("Before:", before, file=sys.stderr)
    print("After:", after, file=sys.stderr)
    raise SystemExit(1)

checks = {
    "_layouts/default.html": ["operational-hardening.css", "operational-hardening.js", "skip-link"],
    "_includes/header.html": ["data-domain-menu", "rd-nav-wizard", "rd-global-search", "data-menu-toggle"],
    "_layouts/list.html": ["catalog-filter-panel", "data-catalog-risk", "data-catalog-status", "data-catalog-tier"],
    "_layouts/article.html": ["assurance-banner", "/reports/content-audit.json", "rd-quick-glance", "data-focus-mode", "procedure-actions"],
    "assets/js/operational-hardening.js": ["groupProcedureSections", "initFocusMode", "classifySection"],
    "assets/css/operational-hardening.css": [":focus-visible", ".rd-procedure-section", ".rd-quick-glance", "forced-colors"],
}
for rel, tokens in checks.items():
    text = (repo / rel).read_text(encoding="utf-8")
    missing_tokens = [token for token in tokens if token not in text]
    if missing_tokens:
        print(f"ERROR: {rel} missing {missing_tokens}", file=sys.stderr)
        raise SystemExit(1)

print("")
print("Operational UX hardening applied successfully.")
print("Protected knowledge collections:", before)
print("Added: domain switcher, prominent Wizard nav, sticky quick glance, focus mode, semantic procedure grouping, stronger steps and keyboard focus.")
print("Responsive CI compatibility retained: catalog-filter-panel.")
