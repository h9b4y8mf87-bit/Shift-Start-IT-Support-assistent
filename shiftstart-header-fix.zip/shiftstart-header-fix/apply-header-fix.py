#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import shutil, sys

repo = Path.cwd()
patch = Path(__file__).resolve().parent
payload = patch / 'payload'

required = [repo / '_includes/header.html', repo / '_layouts/default.html']
if any(not p.exists() for p in required):
    raise SystemExit('ERROR: Run this from the ShiftStart repository root.')

protected = ['_procedures','_symptoms','_causes','_commands']
before = {n: len(list((repo/n).glob('*.md'))) if (repo/n).exists() else 0 for n in protected}

stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
backup = repo / '.shiftstart-backups' / f'header-fix-{stamp}'
for p in required:
    rel = p.relative_to(repo)
    dest = backup / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, dest)

for src in payload.rglob('*'):
    if src.is_file():
        rel = src.relative_to(payload)
        dest = repo / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)
        print('Applied:', rel)

layout = (repo / '_layouts/default.html').read_text(encoding='utf-8')
css = "  <link rel=\"stylesheet\" href=\"{{ '/assets/css/header-enterprise-fix.css' | relative_url }}\">"
if 'header-enterprise-fix.css' not in layout:
    anchor = "  <link rel=\"stylesheet\" href=\"{{ '/assets/css/commercial.css' | relative_url }}\">"
    if anchor in layout:
        layout = layout.replace(anchor, anchor + '\n' + css, 1)
    else:
        layout = layout.replace('</head>', css + '\n</head>', 1)

js = "  <script defer src=\"{{ '/assets/js/header-enterprise-fix.js' | relative_url }}\"></script>"
if 'header-enterprise-fix.js' not in layout:
    anchor = "  <script defer src=\"{{ '/assets/js/enterprise-shell.js' | relative_url }}\"></script>"
    if anchor in layout:
        layout = layout.replace(anchor, anchor + '\n' + js, 1)
    else:
        layout = layout.replace('</body>', js + '\n</body>', 1)

(repo / '_layouts/default.html').write_text(layout, encoding='utf-8')
print('Updated: _layouts/default.html')

after = {n: len(list((repo/n).glob('*.md'))) if (repo/n).exists() else 0 for n in protected}
if before != after:
    raise SystemExit(f'ERROR: Knowledge collection counts changed. Before={before} After={after}')

checks = {
    '_includes/header.html': ['ss-command-launch','data-command-trigger','data-theme-toggle','data-open-request-modal','mobile-navigation'],
    '_layouts/default.html': ['header-enterprise-fix.css','header-enterprise-fix.js'],
    'assets/css/header-enterprise-fix.css': ['.ss-header-primary','.ss-command-launch','.ss-header-secondary','@media(max-width:680px)'],
    'assets/js/header-enterprise-fix.js': ['data-theme-toggle','shiftstart-theme','data-header-command-key'],
}
for rel, tokens in checks.items():
    text = (repo/rel).read_text(encoding='utf-8')
    missing = [t for t in tokens if t not in text]
    if missing:
        raise SystemExit(f'ERROR: {rel} missing expected markers: {missing}')

print('\nShiftStart enterprise header fix applied successfully.')
print('Knowledge collections preserved:', before)
print('Backup:', backup.relative_to(repo))
print('\nNext:')
print('  node --check assets/js/header-enterprise-fix.js')
print('  npm run check')
print('  npm run build')
