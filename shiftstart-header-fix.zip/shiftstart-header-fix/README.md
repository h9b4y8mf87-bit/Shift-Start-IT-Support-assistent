# ShiftStart Enterprise Header Fix

This patch corrects the overcrowded header created when the legacy global search/navigation and the enterprise command/theme/avatar controls are rendered together.

## New header architecture

Top row:
- ShiftStart logo + product name
- Enterprise command palette trigger (`Ctrl+K` / `Cmd+K`)
- Dark/light theme toggle
- Technician avatar
- Mobile menu

Second row:
- Dashboard
- Procedures
- Symptom Wizard
- Coverage
- Quality
- For Organisations
- Governed knowledge indicator
- Request Procedure action

Mobile:
- Compact brand row
- Command palette icon
- Theme toggle
- Hamburger menu
- Full navigation drawer

## Apply

From the repository root:

```bash
git status
git fetch origin
git pull --rebase origin main

unzip -q shiftstart-header-fix.zip
python3 shiftstart-header-fix/apply-header-fix.py

node --check assets/js/header-enterprise-fix.js
npm run check
npm run build
```

If validation passes:

```bash
rm -f shiftstart-header-fix.zip
rm -rf shiftstart-header-fix
rm -rf .shiftstart-backups

git restore reports/content-audit.json 2>/dev/null || true

git add -A
git status
git commit -m "Fix ShiftStart enterprise header"
git push origin main
```
