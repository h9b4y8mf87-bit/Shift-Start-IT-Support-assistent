#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import shutil

repo = Path.cwd()
patch = Path(__file__).resolve().parent
payload = patch / 'payload'

EXPECTED = {
    '_procedures': 421,
    '_symptoms': 446,
    '_causes': 10,
    '_commands': 3,
}

required = [
    repo / '_includes/header.html',
    repo / '_layouts/default.html',
    repo / 'assets/js/header-enterprise-fix.js',
]
if any(not p.exists() for p in required):
    raise SystemExit('ERROR: Run this installer from the ShiftStart repository root.')

for folder, expected in EXPECTED.items():
    path = repo / folder
    actual = len(list(path.glob('*.md'))) if path.exists() else 0
    if actual != expected:
        raise SystemExit(f'ERROR: Expected {expected} files in {folder}, found {actual}. Patch aborted.')

header_path = repo / '_includes/header.html'
layout_path = repo / '_layouts/default.html'
theme_js_path = repo / 'assets/js/header-enterprise-fix.js'

header = header_path.read_text(encoding='utf-8')
layout = layout_path.read_text(encoding='utf-8')
theme_js = theme_js_path.read_text(encoding='utf-8')

header_anchor = '<span class="site-brand-mark rd-brand-mark" aria-hidden="true"><img src="{{ \'/assets/img/shiftstart-mark.svg\' | relative_url }}" alt=""></span>'
header_replacement = '<span class="site-brand-mark rd-brand-mark" data-theme-brand-mark aria-hidden="true"><img src="{{ \'/assets/img/shiftstart-mark.svg\' | relative_url }}" alt=""></span>'

favicon_anchor = '<link rel="icon" type="image/svg+xml" href="{{ \'/assets/img/shiftstart-favicon.svg\' | relative_url }}">'
favicon_replacement = """<link id=\"shiftstart-favicon\" rel=\"icon\" type=\"image/png\" href=\"{{ '/assets/img/shiftstart-logo-light-theme.png' | relative_url }}\" data-light-href=\"{{ '/assets/img/shiftstart-logo-light-theme.png' | relative_url }}\" data-dark-href=\"{{ '/assets/img/shiftstart-logo-dark-theme.png' | relative_url }}\">\n  <script>\n    (() => {\n      const icon = document.getElementById('shiftstart-favicon');\n      if (!icon) return;\n      const theme = document.documentElement.dataset.theme || 'light';\n      icon.href = theme === 'dark' ? icon.dataset.darkHref : icon.dataset.lightHref;\n    })();\n  </script>"""

css_tag = '  <link rel="stylesheet" href="{{ \'/assets/css/theme-logo-favicon.css\' | relative_url }}">'

if 'data-theme-brand-mark' not in header:
    if header_anchor not in header:
        raise SystemExit('ERROR: Current header logo markup no longer matches the validated main-branch baseline.')
    header = header.replace(header_anchor, header_replacement, 1)

if 'id="shiftstart-favicon"' not in layout:
    if favicon_anchor not in layout:
        raise SystemExit('ERROR: Current favicon markup no longer matches the validated main-branch baseline.')
    layout = layout.replace(favicon_anchor, favicon_replacement, 1)

if 'theme-logo-favicon.css' not in layout:
    css_anchor = '  <link rel="stylesheet" href="{{ \'/assets/css/supportvault-product-polish.css\' | relative_url }}">'
    if css_anchor not in layout:
        raise SystemExit('ERROR: Could not locate the product-polish stylesheet anchor in _layouts/default.html.')
    layout = layout.replace(css_anchor, css_anchor + '\n' + css_tag, 1)

if 'function syncThemeBranding' not in theme_js:
    strict_anchor = "  'use strict';\n"
    helper = """\n  function syncThemeBranding(theme) {\n    const favicon = document.getElementById('shiftstart-favicon');\n    if (!favicon) return;\n    const nextHref = theme === 'dark' ? favicon.dataset.darkHref : favicon.dataset.lightHref;\n    if (nextHref) favicon.href = nextHref;\n  }\n"""
    if strict_anchor not in theme_js:
        raise SystemExit('ERROR: Theme script baseline changed; unable to add favicon synchronisation safely.')
    theme_js = theme_js.replace(strict_anchor, strict_anchor + helper, 1)

    dom_anchor = "  document.addEventListener('DOMContentLoaded', () => {\n"
    if dom_anchor not in theme_js:
        raise SystemExit('ERROR: Theme script DOMContentLoaded anchor changed.')
    theme_js = theme_js.replace(
        dom_anchor,
        dom_anchor + "    syncThemeBranding(document.documentElement.dataset.theme || 'light');\n",
        1,
    )

    toggle_anchor = "        document.documentElement.dataset.theme = next;\n"
    if toggle_anchor not in theme_js:
        raise SystemExit('ERROR: Theme-toggle assignment anchor changed.')
    theme_js = theme_js.replace(
        toggle_anchor,
        toggle_anchor + "        syncThemeBranding(next);\n",
        1,
    )

stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
backup = repo / '.shiftstart-backups' / f'theme-logo-favicon-{stamp}'
for source in required:
    rel = source.relative_to(repo)
    dest = backup / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, dest)

for src in payload.rglob('*'):
    if src.is_file():
        rel = src.relative_to(payload)
        dest = repo / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)

header_path.write_text(header, encoding='utf-8')
layout_path.write_text(layout, encoding='utf-8')
theme_js_path.write_text(theme_js, encoding='utf-8')

checks = {
    '_includes/header.html': ['data-theme-brand-mark'],
    '_layouts/default.html': [
        'id="shiftstart-favicon"',
        'data-light-href',
        'data-dark-href',
        'theme-logo-favicon.css',
    ],
    'assets/js/header-enterprise-fix.js': [
        'function syncThemeBranding',
        'syncThemeBranding(next)',
    ],
    'assets/css/theme-logo-favicon.css': [
        'shiftstart-logo-light-theme.png',
        'shiftstart-logo-dark-theme.png',
        'html[data-theme="dark"]',
    ],
}
for rel, tokens in checks.items():
    text = (repo / rel).read_text(encoding='utf-8')
    missing = [token for token in tokens if token not in text]
    if missing:
        raise SystemExit(f'ERROR: {rel} is missing expected markers after patch: {missing}')

for asset in [
    'assets/img/shiftstart-logo-light-theme.png',
    'assets/img/shiftstart-logo-dark-theme.png',
]:
    if not (repo / asset).exists():
        raise SystemExit(f'ERROR: Missing approved branding asset after patch: {asset}')

for folder, expected in EXPECTED.items():
    actual = len(list((repo / folder).glob('*.md')))
    if actual != expected:
        raise SystemExit(f'ERROR: Knowledge collection changed unexpectedly: {folder}={actual}, expected {expected}.')

print('ShiftStart theme-aware logo + favicon patch applied successfully.')
print('Light theme  -> approved light logo + light favicon')
print('Dark theme   -> approved dark logo + dark favicon')
print('Approved PNGs were copied unchanged; no image redesign was performed.')
print('Knowledge collections preserved: 421 procedures / 446 symptoms / 10 causes / 3 commands.')
print(f'Backup: {backup}')
print('\nNEXT:')
print('  node --check assets/js/header-enterprise-fix.js')
print('  npm run check')
print('  npm run build')
print('  python3 scripts/clean-pages-artifact.py --check')
print('  git status --short')
