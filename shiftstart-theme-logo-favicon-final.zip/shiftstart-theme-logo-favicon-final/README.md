# ShiftStart Theme-Aware Logo + Favicon Patch

This patch uses the **two approved images exactly as supplied**. It does not regenerate, redraw, crop, or resize either logo.

## Behaviour
- Light theme: approved light icon is used as the site logo and browser favicon.
- Dark theme: approved dark icon is used as the site logo and browser favicon.
- Changing theme updates the favicon immediately using the existing ShiftStart theme toggle.
- The existing `ShiftStart / IT Support Assistant` wordmark remains unchanged.
- No knowledge, taxonomy, priority, risk, or verification content is modified.

## Apply from the repository root
```bash
unzip -t shiftstart-theme-logo-favicon-final.zip
unzip -q -o shiftstart-theme-logo-favicon-final.zip
python3 shiftstart-theme-logo-favicon-final/apply-theme-logo-favicon.py

node --check assets/js/header-enterprise-fix.js
npm run check
npm run build
python3 scripts/clean-pages-artifact.py --check
git status --short
```

Do not commit until all validation commands pass.
