# ShiftStart enterprise claymorphism theme

A restrained claymorphism design for the technician-first knowledge base.

It adds raised knowledge cards, inset search and filter controls, tactile actions, clay-styled wizard selections and recommendations, semantic status chips, responsive shadows, and accessibility fallbacks. Command blocks remain dark and high-contrast.

No procedures, symptoms, commands, relationships or ranking logic are changed.

## Apply in Codespaces

```bash
unzip -q shiftstart-enterprise-claymorphism-theme.zip

python3   shiftstart-enterprise-claymorphism-theme/apply-claymorphism-theme.py

npm run check

rm -f shiftstart-enterprise-claymorphism-theme.zip
rm -rf shiftstart-enterprise-claymorphism-theme

git add -A
git commit -m "Add enterprise claymorphism design"
git push
```

After deployment, refresh with `Ctrl + F5`. On iPhone or iPad, close and reopen the browser tab if the previous stylesheet remains cached.
