#!/usr/bin/env python3
from pathlib import Path
import sys

START='/* === ShiftStart enterprise claymorphism theme === */'
END='/* === End ShiftStart enterprise claymorphism theme === */'
repo=Path.cwd(); css=repo/'_assets/css/tailwind.css'; layout=repo/'_layouts/default.html'; patch=Path(__file__).with_name('enterprise-claymorphism.css')
for p in (css,layout,patch):
    if not p.exists():
        print(f'ERROR: Required file not found: {p}',file=sys.stderr); print('Run this script from the repository root.',file=sys.stderr); raise SystemExit(1)
html=layout.read_text(encoding='utf-8')
if 'class="min-h-full clay-ui"' not in html:
    if 'class="min-h-full"' not in html: print('ERROR: Could not locate the body class.',file=sys.stderr); raise SystemExit(1)
    html=html.replace('class="min-h-full"','class="min-h-full clay-ui"',1)
html=html.replace('<meta name="theme-color" content="#0f172a">','<meta name="theme-color" content="#0c1d36">')
layout.write_text(html,encoding='utf-8')
source=css.read_text(encoding='utf-8'); theme=patch.read_text(encoding='utf-8')
if START in source and END in source:
    before=source.split(START,1)[0].rstrip(); after=source.split(END,1)[1].lstrip(); source=before+'\n\n'+theme+('\n'+after if after else '')
else: source=source.rstrip()+'\n\n'+theme
css.write_text(source,encoding='utf-8')
for token in ('body.clay-ui','--clay-raised','.symptom-option','.result-card','.command-block','@media(forced-colors:active)','@media print'):
    if token not in source: print(f'ERROR: Missing theme token: {token}',file=sys.stderr); raise SystemExit(1)
print('Enterprise claymorphism theme applied successfully.')
print('Updated:',layout); print('Updated:',css)
print('Preserved: procedures, symptoms, ranking logic and accessibility controls.')
