# ShiftStart technician UI/UX optimisation

This patch improves technician workflow on top of the responsive claymorphism theme.

It adds current-nav state, dashboard coverage stats, recently opened procedures, breadcrumbs, reading progress, automatic article TOC, active section highlighting, copy-link, triage context, back-to-top, catalogue quality filters/reset/empty-state, richer search metadata and a wizard fallback for zero-result searches.

No Markdown procedure or symptom content is removed or changed.

## Apply in Codespaces

```bash
unzip -q shiftstart-ui-ux-optimisation.zip
python3 shiftstart-ui-ux-optimisation/apply-ui-ux.py
npm run check
rm -f shiftstart-ui-ux-optimisation.zip
rm -rf shiftstart-ui-ux-optimisation
git add -A
git commit -m "Apply technician UI UX optimisation"
git push
```
