#!/usr/bin/env python3
from pathlib import Path
import shutil, sys
repo=Path.cwd(); patch=Path(__file__).resolve().parent; files=patch/'files'; css_patch=(patch/'ux.css').read_text(encoding='utf-8'); css_target=repo/'_assets'/'css'/'tailwind.css'; default_layout=repo/'_layouts'/'default.html'
if not css_target.exists() or not default_layout.exists(): print('ERROR: Run this script from the ShiftStart repository root.',file=sys.stderr); raise SystemExit(1)
for source in files.rglob('*'):
    if source.is_file():
        rel=source.relative_to(files); target=repo/rel; target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(source,target); print('Updated:',rel)
start='/* === ShiftStart technician UX optimisation === */'; end='/* === End ShiftStart technician UX optimisation === */'; css=css_target.read_text(encoding='utf-8')
if start in css and end in css:
    before=css.split(start,1)[0].rstrip(); after=css.split(end,1)[1].lstrip(); css=before+'\n\n'+css_patch+(('\n'+after) if after else '')
else: css=css.rstrip()+'\n\n'+css_patch
css_target.write_text(css,encoding='utf-8'); print('Updated:',css_target.relative_to(repo))
layout=default_layout.read_text(encoding='utf-8'); tag='  <script defer src="{{ '/assets/js/ux.js' | relative_url }}"></script>'; anchor='  <script defer src="{{ '/assets/js/search.js' | relative_url }}"></script>'
if '/assets/js/ux.js' not in layout:
    if anchor not in layout: print('ERROR: Could not locate search.js script tag.',file=sys.stderr); raise SystemExit(1)
    layout=layout.replace(anchor,anchor+'\n'+tag)
default_layout.write_text(layout,encoding='utf-8'); print('Updated:',default_layout.relative_to(repo))
checks={'_layouts/article.html':['data-article-toc','data-reading-progress','data-copy-article-link','data-triage-context'],'_layouts/list.html':['data-catalog-status','data-catalog-reset','data-catalog-empty'],'index.html':['data-recent-section','home-status-strip'],'assets/js/ux.js':['initRecentProcedures','initArticleToc','initCatalogExperience'],'assets/js/search.js':['content_status','search-result-meta'],'scripts/generate-search-data.js':['content_status','support_tier','owner_team']}
for filename,tokens in checks.items():
    text=(repo/filename).read_text(encoding='utf-8'); missing=[t for t in tokens if t not in text]
    if missing: print(f'ERROR: {filename} missing {missing}',file=sys.stderr); raise SystemExit(1)
print('\nTechnician UI/UX optimisation applied successfully.')
print('Preserved: all knowledge-base Markdown content and wizard ranking logic.')
print('Added: recent work, article TOC, reading progress, triage context, enhanced filters and richer search metadata.')
