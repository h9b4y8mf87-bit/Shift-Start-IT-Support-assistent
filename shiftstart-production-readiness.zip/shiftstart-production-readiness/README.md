# ShiftStart production-readiness verification package

This package executes the repository-side actions from the verification audit and adds a hard evidence gate for the part that requires your real environment.

## Current source of truth

The current repository audit reports:

- 421 procedures
- 410 `under_review`
- 11 `verified`

## Action 1 — verification queue by risk

After installation run:

```bash
npm run readiness:apply
```

That reviews all 421 procedure records and writes:

- explicit `severity`
- `risk_model: impact-v1`
- a non-empty `risk_basis`
- `verification_priority`
  - Critical → P0
  - High → P1
  - Medium → P2
  - Low → P3
- `verification_state: awaiting_live_validation` on under-review procedures

It generates:

- `reports/verification-queue.csv`
- `reports/verification-queue.json`
- `reports/risk-classification.json`
- `_data/verification-dashboard.json`

It does **not** automatically promote anything.

### Evidence required before promotion

Populate this front matter after a real validation session:

```yaml
verification_evidence:
  diagnostic_tested: true
  remediation_tested: true
  rollback_confirmed: true
  escalation_confirmed: true
  time_validated: true
  owner_signoff: "Named owner / change record"
last_tested: 2026-08-10
tested_platforms:
- "Actual tested platform/build"
```

Then run:

```bash
npm run readiness:promote
```

Only evidence-complete under-review procedures are changed to `verified`.

## Action 2 — standardise current verified runbooks

The package standardises all 11 current verified procedures into `enterprise-v1`:

1. symptom-based title
2. explicit risk
3. verified status
4. support tier
5. estimated time
6. owner
7. canonical domain
8. Diagnostic Steps
9. Remediation Steps
10. Rollback Steps
11. Verification Steps
12. Escalation Path

The existing verified status is retained, but these legacy records are labelled:

```yaml
verification_evidence_state: legacy_verified_pending_revalidation
```

because the repository currently does not record a live test date/platform plus owner sign-off.

## Action 3 — explicit risk on every procedure

The bulk classifier evaluates all procedures against the audit's four impact levels.

A `medium` value is no longer accepted as an unexplained default: every procedure gets a `risk_basis` and `risk_model`.

The existing UI already contains red/orange/yellow/green risk classes, so the updated `severity` field drives those badges automatically.

## Verification dashboard

The homepage gains:

- Verified status
- Evidence-complete verified
- Under Review
- Draft
- Missing Risk
- 80% verified target

## Apply

From the repository root:

```bash
git status
git fetch origin
git pull --rebase origin main

unzip -q shiftstart-production-readiness.zip

python3   shiftstart-production-readiness/apply-production-readiness.py

npm install --no-audit --no-fund

npm run readiness:apply
npm run check

rm -f shiftstart-production-readiness.zip
rm -rf shiftstart-production-readiness

git add -A
git status
git commit -m "Add production readiness risk and verification controls"
git push origin main
```

## About the "at least 100 verified" target

This package deliberately does not manufacture 100 green badges. The acceptance criteria require actual live testing and owner sign-off. The generated P0/P1 queue is the immediate test plan; once evidence is entered, `npm run readiness:promote` performs the status change automatically and safely.
