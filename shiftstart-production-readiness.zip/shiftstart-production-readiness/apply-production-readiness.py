#!/usr/bin/env python3
from pathlib import Path
import shutil
import json
import sys

repo = Path.cwd()
patch = Path(__file__).resolve().parent
files = patch / "files"

required = [
    repo / "package.json",
    repo / "index.html",
    repo / "_layouts" / "default.html",
    repo / "_procedures",
]
missing = [str(p) for p in required if not p.exists()]
if missing:
    print("ERROR: Run from the ShiftStart repository root.", file=sys.stderr)
    for p in missing:
        print("-", p, file=sys.stderr)
    raise SystemExit(1)

before_count = len(list((repo / "_procedures").glob("*.md")))
if before_count != 421:
    raise SystemExit(f"ERROR: Expected 421 procedures before applying; found {before_count}")

for src in files.rglob("*"):
    if src.is_file():
        rel = src.relative_to(files)
        dest = repo / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)
        print("Updated:", rel)

package_path = repo / "package.json"
package = json.loads(package_path.read_text(encoding="utf-8"))
scripts = package.setdefault("scripts", {})
scripts["readiness:apply"] = "node scripts/production-readiness.js --apply"
scripts["readiness:promote"] = "node scripts/production-readiness.js --promote"
scripts["readiness:check"] = "node scripts/validate-readiness.js"
check = scripts.get("check", "")
if "npm run readiness:check" not in check:
    scripts["check"] = check + " && npm run readiness:check"
package_path.write_text(json.dumps(package, indent=2) + "\n", encoding="utf-8")
print("Updated: package.json")

default_path = repo / "_layouts" / "default.html"
default = default_path.read_text(encoding="utf-8")
css_tag = """  <link rel="stylesheet" href="{{ '/assets/css/production-readiness.css' | relative_url }}">"""
if "/assets/css/production-readiness.css" not in default:
    anchor = """  <link rel="stylesheet" href="{{ '/assets/css/operational-hardening.css' | relative_url }}">"""
    if anchor not in default:
        anchor = """  <link rel="stylesheet" href="{{ '/assets/css/redesign.css' | relative_url }}">"""
    if anchor not in default:
        raise SystemExit("ERROR: Could not find redesign stylesheet anchor in default layout.")
    default = default.replace(anchor, anchor + "\n" + css_tag, 1)
    default_path.write_text(default, encoding="utf-8")
    print("Updated: _layouts/default.html")

index_path = repo / "index.html"
index = index_path.read_text(encoding="utf-8")
include_line = "{% include readiness-dashboard.html %}"
if include_line not in index:
    anchors = [
        '<section class="shell rd-dashboard-section rd-trust-section">',
        '<section class="shell rd-trust-section">'
    ]
    inserted = False
    for anchor in anchors:
        if anchor in index:
            index = index.replace(anchor, include_line + "\n\n" + anchor, 1)
            inserted = True
            break
    if not inserted:
        index = index.rstrip() + "\n\n" + include_line + "\n"
    index_path.write_text(index, encoding="utf-8")
    print("Updated: index.html")

after_count = len(list((repo / "_procedures").glob("*.md")))
if after_count != 421:
    raise SystemExit(f"ERROR: Procedure count changed after applying; found {after_count}")

print("")
print("Production-readiness tooling installed.")
print("Next: npm install --no-audit --no-fund")
print("Then: npm run readiness:apply")
print("Then: npm run check")
print("No under-review procedure is promoted by this installer.")
