# ShiftStart phone, tablet and desktop responsive update

This package preserves the dashboard's existing desktop layout and features while adding dedicated phone and tablet/iPad layouts. Phones below 768px receive single-column cards. Tablets and iPads from 768px through 1024px receive touch-first navigation, two-column cards and a stacked procedure workspace. Desktop screens from 1025px upward retain the full horizontal navigation and multi-column dashboard.

## Files

- `_includes/header.html` replaces the JavaScript hamburger control with a CSS-only checkbox/label control.
- `_layouts/default.html` retains the responsive viewport meta tag and loads the mobile stylesheet last.
- `assets/css/mobile-responsive.css` contains the phone, tablet/iPad and desktop breakpoints, safe-area handling, typography, touch-target, overflow and stacked-workspace rules.

## Apply to the repository

Upload the three files to the matching paths in `h9b4y8mf87-bit/Shift-Start-IT-Support-assistent`, replacing the two existing HTML files and adding the new CSS file. Commit the changes to `main`. GitHub Pages should rebuild automatically.

## Verification checklist

Test the homepage and `/procedures/` at phone widths of 320px, 375px, 430px and 767px. Confirm that:

1. The hamburger opens and closes without JavaScript.
2. Dashboard cards appear one per row.
3. The procedure category rail, results and detail rail appear vertically.
4. Procedure rows display as cards instead of a wide table.
5. Buttons, links and fields have at least a 44px touch area.
6. The page does not scroll horizontally.
7. Search, theme switching, procedure filtering and command-palette behaviour still work.

Test tablets and iPads at 768px, 820px, 834px and 1024px. Confirm that the hamburger remains active, cards use a maximum of two columns, touch targets remain at least 44px, and the procedure category, results and detail regions remain vertically stacked without horizontal overflow. Rotate once to confirm that safe-area padding protects the header, menu and floating request button.

Then test at 1025px, 1366px and 1920px. Confirm that the desktop navigation becomes horizontal, dashboard cards return to their original multi-column grids, and the procedure workspace retains its three-pane desktop layout.
