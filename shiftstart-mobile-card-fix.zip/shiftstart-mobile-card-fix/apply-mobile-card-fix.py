from pathlib import Path

css_path = Path('_assets/css/tailwind.css')
index_path = Path('index.html')

if not css_path.exists() or not index_path.exists():
    raise SystemExit('Run this script from the repository root.')

css = css_path.read_text(encoding='utf-8')
old_badge = '''  .badge {\n    @apply inline-flex max-w-full items-center rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold leading-5 text-slate-700;\n    overflow-wrap: anywhere;\n  }'''
new_badge = '''  .badge {\n    @apply inline-flex max-w-full shrink-0 items-center justify-center whitespace-nowrap rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold leading-5 text-slate-700;\n    overflow-wrap: normal;\n    word-break: normal;\n  }\n\n  .card-heading-row {\n    @apply grid min-w-0 grid-cols-[minmax(0,1fr)_auto] items-start gap-3;\n  }\n\n  .card-heading-row > strong {\n    @apply min-w-0;\n    overflow-wrap: anywhere;\n  }'''
if old_badge not in css:
    raise SystemExit('Expected .badge block not found; repository may already be changed.')
css = css.replace(old_badge, new_badge)
css_path.write_text(css, encoding='utf-8')

index = index_path.read_text(encoding='utf-8')
old = '<div class="flex items-start justify-between gap-3"><strong>{{ item.title }}</strong><span class="badge">{{ item.severity }}</span></div>'
new = '<div class="card-heading-row"><strong>{{ item.title }}</strong><span class="badge" aria-label="Severity: {{ item.severity | escape }}">{{ item.severity }}</span></div>'
if old not in index:
    raise SystemExit('Expected common-procedure card heading not found.')
index = index.replace(old, new)
index_path.write_text(index, encoding='utf-8')

print('Mobile card fix applied successfully.')
print('Severity badges now remain on one line and titles retain flexible width.')
