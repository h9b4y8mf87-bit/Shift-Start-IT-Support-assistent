# ShiftStart mobile card fix

This patch fixes severity badges wrapping words such as `medium` onto two lines on narrow screens.

It updates:
- `_assets/css/tailwind.css`
- `index.html`

Run from the repository root:

```bash
python3 shiftstart-mobile-card-fix/apply-mobile-card-fix.py
npm run check
git add -A
git commit -m "Fix mobile severity badge wrapping"
git push
```
