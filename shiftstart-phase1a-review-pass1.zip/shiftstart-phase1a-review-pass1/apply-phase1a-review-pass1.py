#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime, timezone
import json
import shutil
import sys

ROOT = Path.cwd()
PACKAGE = Path(__file__).resolve().parent
PAYLOAD = PACKAGE / "payload"

EXPECTED_PROCEDURES = 421
EXPECTED_SYMPTOMS = 446
EXPECTED_DECISIONS = 249
VALID_TYPES = {
    "observable_symptom",
    "service_request",
    "known_condition",
    "context",
    "incident_event",
}

def fail(message):
    print(f"ERROR: {message}", file=sys.stderr)
    sys.exit(1)

if not (ROOT / "package.json").exists() or not (ROOT / "_symptoms").is_dir():
    fail("run this installer from the ShiftStart repository root")

procedure_count = len(list((ROOT / "_procedures").glob("*.md")))
symptom_count = len(list((ROOT / "_symptoms").glob("*.md")))
if procedure_count != EXPECTED_PROCEDURES:
    fail(f"expected {EXPECTED_PROCEDURES} procedures; found {procedure_count}")
if symptom_count != EXPECTED_SYMPTOMS:
    fail(f"expected {EXPECTED_SYMPTOMS} symptom records; found {symptom_count}")

decisions_payload = json.loads(
    (PAYLOAD / "phase1a-review-pass1-decisions.json").read_text(encoding="utf-8")
)
decisions = decisions_payload.get("decisions", {})
if len(decisions) != EXPECTED_DECISIONS:
    fail(f"expected {EXPECTED_DECISIONS} reviewed decisions; found {len(decisions)}")
for slug, object_type in decisions.items():
    if object_type not in VALID_TYPES:
        fail(f"{slug}: invalid reviewed object type {object_type}")

report_path = ROOT / "reports" / "symptom-taxonomy-v2.json"
if not report_path.exists():
    fail("reports/symptom-taxonomy-v2.json is missing; run Phase 1A taxonomy build first")
report = json.loads(report_path.read_text(encoding="utf-8"))
if report.get("sourceCount") != EXPECTED_SYMPTOMS:
    fail(f"taxonomy report sourceCount is {report.get('sourceCount')}, expected {EXPECTED_SYMPTOMS}")

records = report.get("records", {})
for slug, object_type in decisions.items():
    record = records.get(slug)
    if not record:
        fail(f"review decision refers to unknown taxonomy slug: {slug}")
    if record.get("reviewRequired") is False and record.get("objectType") != object_type:
        fail(
            f"{slug}: current accepted taxonomy type is {record.get('objectType')}, "
            f"but Review Pass 1 proposes {object_type}; re-audit before applying"
        )

overrides_path = ROOT / "_data" / "symptom-taxonomy-v2-overrides.json"
cleaner_path = ROOT / "scripts" / "clean-pages-artifact.py"
gitignore_path = ROOT / ".gitignore"

for path in (overrides_path, cleaner_path, gitignore_path):
    if not path.exists():
        fail(f"required file missing: {path}")

overrides = json.loads(overrides_path.read_text(encoding="utf-8"))
override_records = overrides.setdefault("records", {})

reason_by_type = {
    "observable_symptom": "Manual Review Pass 1: the record expresses an observed failure, behaviour or access problem before root cause is established.",
    "service_request": "Manual Review Pass 1: the record primarily represents a requested or required approved support action, change, recovery, validation or administrative task.",
    "known_condition": "Manual Review Pass 1: the record states an identified technical, configuration, capacity, compliance, data-state or physical condition.",
    "context": "Manual Review Pass 1: the record primarily names the affected technology, component or environment and is useful as diagnostic context rather than a standalone fault.",
    "incident_event": "Manual Review Pass 1: the record represents a security event, outage, service degradation or other incident/event requiring incident handling.",
}

changed_overrides = 0
already_reviewed = 0
for slug, object_type in sorted(decisions.items()):
    existing = override_records.get(slug)
    if existing:
        if existing.get("object_type") != object_type or existing.get("reviewed") is not True:
            fail(
                f"{slug}: an existing override conflicts with Review Pass 1 "
                f"({existing.get('object_type')} / reviewed={existing.get('reviewed')})"
            )
        already_reviewed += 1
        continue
    override_records[slug] = {
        "object_type": object_type,
        "reviewed": True,
        "confidence": "high",
        "reason": reason_by_type[object_type],
        "review_source": "Phase 1A Review Pass 1"
    }
    changed_overrides += 1

# Preview the expected final distribution using the committed report plus reviewed decisions.
expected_counts = {}
for slug, record in records.items():
    object_type = decisions.get(slug, record.get("objectType"))
    expected_counts[object_type] = expected_counts.get(object_type, 0) + 1
if sum(expected_counts.values()) != EXPECTED_SYMPTOMS:
    fail("expected post-review object-type counts do not total 446")

cleaner = cleaner_path.read_text(encoding="utf-8")
if '"shiftstart-phase1a-*.zip",' not in cleaner:
    anchor = '    "shiftstart-final-corrective-patch*.zip",\n'
    if anchor not in cleaner:
        fail("Pages cleaner file-pattern anchor changed; no cleanup change made")
    cleaner = cleaner.replace(
        anchor,
        anchor + '    "shiftstart-phase1a-*.zip",\n',
        1,
    )
if '"shiftstart-phase1a-*",' not in cleaner:
    anchor = '    "shiftstart-final-corrective-patch*",\n'
    if anchor not in cleaner:
        fail("Pages cleaner directory-pattern anchor changed; no cleanup change made")
    cleaner = cleaner.replace(
        anchor,
        anchor + '    "shiftstart-phase1a-*",\n',
        1,
    )

gitignore = gitignore_path.read_text(encoding="utf-8")
ignore_block = "shiftstart-phase1a-*/\nshiftstart-phase1a-*.zip\n"
if "shiftstart-phase1a-*.zip" not in gitignore:
    if not gitignore.endswith("\n"):
        gitignore += "\n"
    gitignore += ignore_block

doc_src = PAYLOAD / "docs" / "knowledge-model" / "PHASE-1A-REVIEW-PASS-1.md"
doc_dst = ROOT / "docs" / "knowledge-model" / "PHASE-1A-REVIEW-PASS-1.md"
if doc_dst.exists() and doc_dst.read_bytes() != doc_src.read_bytes():
    fail(f"{doc_dst} already exists with different content")

stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
backup = ROOT / ".shiftstart-backups" / f"phase1a-review-pass1-{stamp}"
backup.mkdir(parents=True, exist_ok=True)
for path in (overrides_path, cleaner_path, gitignore_path):
    rel = path.relative_to(ROOT)
    dst = backup / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, dst)

# Keep the five original overrides plus Review Pass 1 deterministic ordering.
overrides["records"] = dict(sorted(override_records.items()))
overrides_path.write_text(json.dumps(overrides, indent=2) + "\n", encoding="utf-8")
cleaner_path.write_text(cleaner, encoding="utf-8")
gitignore_path.write_text(gitignore, encoding="utf-8")
doc_dst.parent.mkdir(parents=True, exist_ok=True)
if not doc_dst.exists():
    shutil.copy2(doc_src, doc_dst)

if len(list((ROOT / "_procedures").glob("*.md"))) != EXPECTED_PROCEDURES:
    fail("procedure count changed unexpectedly")
if len(list((ROOT / "_symptoms").glob("*.md"))) != EXPECTED_SYMPTOMS:
    fail("symptom source count changed unexpectedly")

print("ShiftStart Phase 1A Review Pass 1 applied.")
print(f"Reviewed decisions in package: {EXPECTED_DECISIONS}")
print(f"New override entries added: {changed_overrides}")
print(f"Review decisions already present: {already_reviewed}")
print("Procedure source files modified: 0")
print("Symptom source files modified: 0")
print(f"Procedures preserved: {EXPECTED_PROCEDURES}")
print(f"Legacy symptom records/URLs preserved: {EXPECTED_SYMPTOMS}")
print(f"Expected post-build object types: {json.dumps(expected_counts, sort_keys=True)}")
print("Expected classifier review queue after rebuild: 0")
print(f"Backup: {backup}")
print()
print("NEXT:")
print("  nvm use 22")
print("  npm run taxonomy:v2:build")
print("  npm run taxonomy:v2:check")
print("  npm run check")
print("  npm run build")
print("  python3 scripts/clean-pages-artifact.py --check")
print("  git status --short")
