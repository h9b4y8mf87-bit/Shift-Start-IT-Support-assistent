# ShiftStart Phase 1A — Review Pass 1

This patch performs the manual review of all 249 records currently flagged `review_required=true` by the Phase 1A taxonomy report.

It also fixes the public Pages hygiene issue by excluding/removing `shiftstart-phase1a-*` ZIPs and extracted patch folders from the generated `_site`.

## Safety

- 421 procedures must exist before and after.
- 446 legacy symptom records must exist before and after.
- No `_procedures/*.md` file is modified.
- No `_symptoms/*.md` file is modified.
- No existing `/symptoms/.../` URL is renamed or deleted.
- Incident priority, execution risk and Verification v2 governance are not changed.
- Conflicting pre-existing taxonomy overrides cause the installer to stop.

## Apply

From the repository root:

```bash
unzip -q -o shiftstart-phase1a-review-pass1.zip
python3 shiftstart-phase1a-review-pass1/apply-phase1a-review-pass1.py
```

Then run:

```bash
nvm use 22
npm run taxonomy:v2:build
npm run taxonomy:v2:check
npm run check
npm run build
python3 scripts/clean-pages-artifact.py --check
git status --short
```

Expected taxonomy review result:

```text
Reviewed/accepted: 446
review required: 0
```

Do not commit until all checks and the production build pass.

## Next QA step

After this pass is green, perform a separate QA pass over the 197 records that the deterministic classifier previously accepted as high-confidence. Review Pass 1 clears the classifier's flagged queue; the QA pass is what should precede freezing Knowledge Model v2 as the final authoritative taxonomy baseline.
