#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import shutil, subprocess
repo=Path.cwd(); patch=Path(__file__).resolve().parent
required=['_includes/header.html','_layouts/list.html','_layouts/default.html','_procedures']
missing=[x for x in required if not (repo/x).exists()]
if missing: raise SystemExit('ERROR: run from ShiftStart repository root; missing: '+', '.join(missing))
count=len(list((repo/'_procedures').glob('*.md')))
if count!=421: raise SystemExit(f'ERROR: expected 421 procedures; found {count}')
backup=repo/'.shiftstart-backups'/('supportvault-product-polish-'+datetime.now().strftime('%Y%m%d-%H%M%S'))
for rel in ['_includes/header.html','_layouts/list.html','_layouts/default.html']:
    src=repo/rel; dst=backup/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
for rel in ['_includes/header.html','_layouts/list.html','assets/css/supportvault-product-polish.css','scripts/validate-supportvault-product-polish.py']:
    src=patch/'payload'/rel; dst=repo/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
p=repo/'_layouts/default.html'; t=p.read_text(encoding='utf-8')
link='  <link rel="stylesheet" href="{{ \'/assets/css/supportvault-product-polish.css\' | relative_url }}">\n'
if 'supportvault-product-polish.css' not in t:
    anchor='  <link rel="stylesheet" href="{{ \'/assets/css/mobile-responsive.css\' | relative_url }}">\n'
    if anchor not in t: raise SystemExit('ERROR: mobile-responsive stylesheet anchor not found in _layouts/default.html')
    t=t.replace(anchor,anchor+link,1); p.write_text(t,encoding='utf-8')
r=subprocess.run(['python3','scripts/validate-supportvault-product-polish.py'],cwd=repo)
if r.returncode: raise SystemExit('ERROR: product-polish validator failed')
print('\nShiftStart SupportVault-style product polish applied.')
print('No procedures, symptoms, governance records or verification evidence were modified.')
print('Backup:',backup.relative_to(repo))
