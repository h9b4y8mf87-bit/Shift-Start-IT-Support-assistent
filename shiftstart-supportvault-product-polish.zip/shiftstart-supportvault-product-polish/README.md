# ShiftStart — Final Governance + SupportVault-style Product Polish

This package safely applies the outstanding post-B6 governance correction **first**, then applies the requested SupportVault presentation advantages:

1. **Simpler marketing/product-style navigation**
2. **Visually polished, concise procedure cards** while retaining the full 421-procedure catalogue
3. **Stronger overall visual polish** across the header, homepage, filters, catalogue, responsive states and dark mode

The wrapper order matters because both the governance correction and the visual redesign touch the procedure catalogue layout.

## What stays intact

- 421 procedures
- Symptom Wizard and command search
- B-1 through B-6 remediation
- Verification v2 and evidence state
- P0/P1/P2/P3 classifications
- deprecated compatibility URLs
- rollback, escalation and evidence content

## New desktop navigation

**Procedures · Symptom Wizard · Quality · For Organisations**

The ShiftStart logo remains Home. Coverage and About remain accessible through mobile navigation and page links.

## New procedure cards

Cards show only what a technician needs to select the right procedure: risk, effective governance status, domain, title, concise description, tier, estimated time, first platform and a clear Open action. Detailed owner/governance/rollback/evidence remains inside the procedure.

## Apply everything in the correct order

```bash
unzip -q -o shiftstart-supportvault-product-polish.zip
python3 shiftstart-supportvault-product-polish/apply-final-product-polish.py
```

Then regenerate and validate:

```bash
npm run verification:v2:apply
npm run generate
npm run post:b6:governance:check
python3 scripts/validate-supportvault-product-polish.py
npm run check
npm run build
```

Do not commit or push unless the complete gate passes.
