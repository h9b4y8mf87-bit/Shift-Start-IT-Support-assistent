#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import json, shutil, subprocess

repo = Path.cwd()
patch = Path(__file__).resolve().parent

required = [
    "package.json",
    "scripts/generate-wizard.js",
    "scripts/generate-search-data.js",
    "scripts/validate-content.js",
    "_layouts/list.html",
    "_layouts/article.html",
]
missing = [p for p in required if not (repo / p).exists()]
if missing:
    raise SystemExit("ERROR: run from ShiftStart repo root; missing: " + ", ".join(missing))
if not (repo / "_data/batch-b6-audit-remediation.json").exists():
    raise SystemExit("ERROR: Batch B-6 audit record is missing. Apply/validate Batch B-6 first.")

backup = repo / ".shiftstart-backups" / ("post-b6-governance-" + datetime.now().strftime("%Y%m%d-%H%M%S"))
for rel in required:
    src = repo / rel
    dst = backup / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

def replace_once(text, old, new, label):
    if old not in text:
        raise SystemExit("ERROR: expected pattern not found for " + label)
    return text.replace(old, new, 1)

# 1. Wizard
p = repo / "scripts/generate-wizard.js"
t = p.read_text(encoding="utf-8")
helper = '''const effectiveProcedureStatus = (data) => {
  const governance = data.verification_governance_state || data.content_status || "under_review";
  if (governance === "verified") {
    return data.verification_v2_complete === true && data.verification_promotion_ready === true
      ? "verified"
      : "revalidation_required";
  }
  return governance;
};

'''
if "const effectiveProcedureStatus" not in t:
    t = replace_once(t, 'const symptoms = readCollection("_symptoms");\n',
                     helper + 'const symptoms = readCollection("_symptoms");\n',
                     "wizard governance helper")
t = replace_once(
    t,
    '''const statusCounts = procedures.reduce((acc, procedure) => {
  const status = procedure.data.content_status || "under_review";
  acc[status] = (acc[status] || 0) + 1;
  return acc;
}, {});
''',
    '''const statusCounts = procedures.reduce((acc, procedure) => {
  const status = effectiveProcedureStatus(procedure.data);
  acc[status] = (acc[status] || 0) + 1;
  return acc;
}, {});
''',
    "wizard status counts",
)
t = replace_once(
    t,
    '    contentStatus: procedure.data.content_status || "under_review",\n',
    '''    contentStatus: effectiveProcedureStatus(procedure.data),
    legacyContentStatus: procedure.data.content_status || "under_review",
    verificationGovernanceState: procedure.data.verification_governance_state || "",
    verificationV2Complete: procedure.data.verification_v2_complete === true,
    verificationPromotionReady: procedure.data.verification_promotion_ready === true,
''',
    "wizard status export",
)
p.write_text(t, encoding="utf-8")

# 2. Search
p = repo / "scripts/generate-search-data.js"
t = p.read_text(encoding="utf-8")
helper = '''const effectiveStatus = (data, collection) => {
  if (collection !== 'procedures') return data.content_status || '';
  const governance = data.verification_governance_state || data.content_status || 'under_review';
  if (governance === 'verified') {
    return data.verification_v2_complete === true && data.verification_promotion_ready === true
      ? 'verified'
      : 'revalidation_required';
  }
  return governance;
};
'''
if "const effectiveStatus" not in t:
    t = replace_once(t, "const documents = [];\n",
                     "const documents = [];\n" + helper,
                     "search governance helper")
t = replace_once(
    t,
    "      contentStatus: data.content_status || '',\n",
    '''      contentStatus: effectiveStatus(data, collection),
      legacyContentStatus: data.content_status || '',
      verificationGovernanceState: data.verification_governance_state || '',
      verificationV2Complete: data.verification_v2_complete === true,
      verificationPromotionReady: data.verification_promotion_ready === true,
''',
    "search status export",
)
p.write_text(t, encoding="utf-8")

# 3. Content validator
p = repo / "scripts/validate-content.js"
t = p.read_text(encoding="utf-8")
helper = '''const effectiveProcedureStatus = (data) => {
  const governanceStatus = data.verification_governance_state || data.content_status || "under_review";
  if (governanceStatus === "verified") {
    return data.verification_v2_complete === true && data.verification_promotion_ready === true
      ? "verified"
      : "revalidation_required";
  }
  return governanceStatus;
};

'''
if "const effectiveProcedureStatus" not in t:
    t = replace_once(t, "const genericDescriptions = /^Enterprise runbook to\\\\b/i;\n\n",
                     "const genericDescriptions = /^Enterprise runbook to\\\\b/i;\n\n" + helper,
                     "content helper")
t = replace_once(
    t,
    '      if (data.owner_team && parsed.content.length < 1200) errors.push(`${file}: procedure content is too short for enterprise use`);\n',
    '''      const effectiveStatus = effectiveProcedureStatus(data);
      const isDeprecatedCompatibility = effectiveStatus === "deprecated" || data.content_status === "deprecated";
      if (data.owner_team && !isDeprecatedCompatibility && parsed.content.length < 1200) {
        errors.push(`${file}: procedure content is too short for enterprise use`);
      }
''',
    "deprecated length exemption",
)
t = replace_once(
    t,
    '''      if (data.content_status === "verified") {
        if (!data.reviewed_by) errors.push(`${file}: verified procedure requires reviewed_by`);
        if (generated) errors.push(`${file}: generated baseline cannot be marked verified`);
        if (data.quality_gate !== "passed") errors.push(`${file}: verified procedure requires quality_gate: passed`);
      }
''',
    '''      if (effectiveStatus === "verified") {
        if (!data.reviewed_by) errors.push(`${file}: verified procedure requires reviewed_by`);
        if (generated) errors.push(`${file}: generated baseline cannot be marked verified`);
        if (data.quality_gate !== "passed") errors.push(`${file}: verified procedure requires quality_gate: passed`);
        if (data.verification_v2_complete !== true || data.verification_promotion_ready !== true) {
          errors.push(`${file}: governance verified requires verification-v2 completion and promotion readiness`);
        }
      } else if (data.content_status === "verified") {
        warnings.push(`${file}: legacy content_status verified is non-authoritative; effective status is '${effectiveStatus}'`);
      }
''',
    "verified validation",
)
t = replace_once(
    t,
    '        commandUse.get(key).push({ file, status: data.content_status, category: data.category });\n',
    '        commandUse.get(key).push({ file, status: effectiveStatus, category: data.category });\n',
    "command status",
)
t = replace_once(
    t,
    '''  statusCounts: [...records.procedures.values()].reduce((acc, item) => {
    const status = item.data.content_status || "missing";
    acc[status] = (acc[status] || 0) + 1;
    return acc;
  }, {}),
''',
    '''  statusCounts: [...records.procedures.values()].reduce((acc, item) => {
    const status = effectiveProcedureStatus(item.data);
    acc[status] = (acc[status] || 0) + 1;
    return acc;
  }, {}),
  legacyStatusCounts: [...records.procedures.values()].reduce((acc, item) => {
    const status = item.data.content_status || "missing";
    acc[status] = (acc[status] || 0) + 1;
    return acc;
  }, {}),
''',
    "audit status counts",
)
p.write_text(t, encoding="utf-8")

# 4. Catalogue
p = repo / "_layouts/list.html"
t = p.read_text(encoding="utf-8")
t = replace_once(
    t,
    '''      <label><span>Review status</span><select class="wizard-input" data-catalog-status><option value="all">All statuses</option><option value="verified">Verified</option><option value="under_review">Under review</option><option value="draft">Draft</option><option value="deprecated">Deprecated</option></select></label>
''',
    '''      <label><span>Review status</span><select class="wizard-input" data-catalog-status><option value="all">All statuses</option><option value="verified">Verified</option><option value="revalidation_required">Revalidation required</option><option value="live_validation_pending">Live validation pending</option><option value="under_review">Under review</option><option value="draft">Draft</option><option value="deprecated">Deprecated</option></select></label>
''',
    "catalog filter",
)
t = replace_once(
    t,
    '''    {% for item in sorted_items %}
    <a class="card catalog-item rd-procedure-card" href="{{ item.url | relative_url }}" data-title="{{ item.title | downcase | escape }}" data-category="{{ item.category | escape }}" data-risk="{{ item.severity | default: '' | downcase | escape }}" data-status="{{ item.content_status | default: '' | escape }}" data-tier="{{ item.support_tier | default: '' | escape }}" data-search="{{ item.title | append: ' ' | append: item.description | append: ' ' | append: item.category | append: ' ' | append: item.tags | append: ' ' | append: item.platforms | append: ' ' | append: item.error_codes | downcase | escape }}">
      <div class="rd-card-badges">{% if item.severity %}<span class="rd-risk rd-risk-{{ item.severity | downcase }}">{{ item.severity }}</span>{% endif %}{% if item.content_status %}<span class="rd-status status-{{ item.content_status }}">{{ item.content_status | replace: '_', ' ' }}</span>{% endif %}</div>
''',
    '''    {% for item in sorted_items %}
    {% assign item_status = item.content_status | default: '' %}
    {% if page.collection_name == 'procedures' and item.verification_governance_state %}{% assign item_status = item.verification_governance_state %}{% endif %}
    {% if page.collection_name == 'procedures' and item_status == 'verified' and item.verification_v2_complete != true %}{% assign item_status = 'revalidation_required' %}{% endif %}
    <a class="card catalog-item rd-procedure-card" href="{{ item.url | relative_url }}" data-title="{{ item.title | downcase | escape }}" data-category="{{ item.category | escape }}" data-risk="{{ item.severity | default: '' | downcase | escape }}" data-status="{{ item_status | escape }}" data-tier="{{ item.support_tier | default: '' | escape }}" data-search="{{ item.title | append: ' ' | append: item.description | append: ' ' | append: item.category | append: ' ' | append: item.tags | append: ' ' | append: item.platforms | append: ' ' | append: item.error_codes | downcase | escape }}">
      <div class="rd-card-badges">{% if item.severity %}<span class="rd-risk rd-risk-{{ item.severity | downcase }}">{{ item.severity }}</span>{% endif %}{% if item_status != '' %}<span class="rd-status status-{{ item_status }}">{{ item_status | replace: '_', ' ' }}</span>{% endif %}</div>
''',
    "catalog authoritative status",
)
p.write_text(t, encoding="utf-8")

# 5. Related-procedure status
p = repo / "_layouts/article.html"
t = p.read_text(encoding="utf-8")
old = '        {% for slug in page.related_procedures %}{% assign item = site.procedures | where: "slug", slug | first %}{% if item %}<a class="card" href="{{ item.url | relative_url }}"><strong>{{ item.title }}</strong><p>Procedure · {{ item.content_status | replace: \'_\', \' \' }}</p></a>{% endif %}{% endfor %}\n'
new = '        {% for slug in page.related_procedures %}{% assign item = site.procedures | where: "slug", slug | first %}{% if item %}{% assign related_status = item.verification_governance_state | default: item.content_status | default: \'under_review\' %}{% if related_status == \'verified\' and item.verification_v2_complete != true %}{% assign related_status = \'revalidation_required\' %}{% endif %}<a class="card" href="{{ item.url | relative_url }}"><strong>{{ item.title }}</strong><p>Procedure · {{ related_status | replace: \'_\', \' \' }}</p></a>{% endif %}{% endfor %}\n'
t = replace_once(t, old, new, "related procedure status")
p.write_text(t, encoding="utf-8")

# Install validator/docs.
for src in (patch / "payload").rglob("*"):
    if src.is_file():
        rel = src.relative_to(patch / "payload")
        dst = repo / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

pkgp = repo / "package.json"
pkg = json.loads(pkgp.read_text(encoding="utf-8"))
scripts = pkg.setdefault("scripts", {})
scripts["post:b6:governance:check"] = "python3 scripts/validate-post-b6-governance.py"
check = scripts.get("check", "")
if "npm run post:b6:governance:check" not in check:
    scripts["check"] = (check + " && " if check else "") + "npm run post:b6:governance:check"
pkgp.write_text(json.dumps(pkg, indent=2) + "\n", encoding="utf-8")

r = subprocess.run(["python3", "scripts/validate-post-b6-governance.py"], cwd=repo)
if r.returncode:
    raise SystemExit("ERROR: post-B6 governance validator failed")

print("")
print("Post-B6 governance fix applied.")
print("Verification v2 is authoritative for wizard/search/catalogue status surfaces.")
print("Deprecated compatibility pages are exempt only from the full-runbook length rule.")
print("No procedure was promoted to Verified.")
print("Backup:", backup.relative_to(repo))
