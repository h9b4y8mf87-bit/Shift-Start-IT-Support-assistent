#!/usr/bin/env python3
from pathlib import Path
import subprocess, sys
pkg=Path(__file__).resolve().parent
steps=[
    [sys.executable, str(pkg/'governance-fix'/'apply-post-b6-governance-fix.py')],
    [sys.executable, str(pkg/'apply-supportvault-product-polish.py')],
]
for cmd in steps:
    r=subprocess.run(cmd)
    if r.returncode:
        raise SystemExit(r.returncode)
print('\nFinal ShiftStart governance + SupportVault-style product polish applied.')
print('Next: npm run verification:v2:apply && npm run generate && npm run check && npm run build')
