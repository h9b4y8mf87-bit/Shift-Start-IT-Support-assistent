# ShiftStart recommendation result layout fix

This patch improves the ranked recommendation panel shown after the technician selects symptoms.

It corrects:

- `1 matches` to `1 match`;
- cramped evidence and warning text;
- the procedure button floating awkwardly halfway down the card;
- weak visual separation between matched and unexplained symptoms;
- mobile stacking and desktop alignment;
- long titles, descriptions, owner names and category badges;
- accessible labels for procedure-opening buttons.

The recommendation ranking algorithm, procedure content and symptom relationships are unchanged.

## Apply in Codespaces

Run these commands from the repository root:

```bash
unzip -q shiftstart-recommendation-layout-fix.zip

python3   shiftstart-recommendation-layout-fix/apply-recommendation-layout-fix.py

npm run check

rm -f shiftstart-recommendation-layout-fix.zip
rm -rf shiftstart-recommendation-layout-fix

git add -A
git commit -m "Improve wizard recommendation results"
git push
```

After GitHub Pages finishes deploying, refresh with `Ctrl + F5`.
On iPhone or iPad, close and reopen the browser tab if old CSS remains cached.
