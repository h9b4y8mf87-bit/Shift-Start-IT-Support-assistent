#!/usr/bin/env python3
from pathlib import Path
import re
import sys

CSS_START = "/* === ShiftStart recommendation result layout fix === */"
CSS_END = "/* === End ShiftStart recommendation result layout fix === */"

repo = Path.cwd()
app_path = repo / "assets" / "js" / "app.js"
css_path = repo / "_assets" / "css" / "tailwind.css"
patch_css_path = Path(__file__).with_name("recommendation-layout-fix.css")

for required in (app_path, css_path, patch_css_path):
    if not required.exists():
        print(f"ERROR: Required file not found: {required}", file=sys.stderr)
        print("Run this script from the repository root.", file=sys.stderr)
        raise SystemExit(1)

app = app_path.read_text(encoding="utf-8")
original_app = app

# Correct singular/plural recommendation count.
app = app.replace(
    '${ranked.length} matches',
    '${ranked.length} ${ranked.length === 1 ? "match" : "matches"}'
)

marker = "const cards = ranked.map"
if marker not in app:
    print("ERROR: Could not locate the wizard recommendation card generator.", file=sys.stderr)
    raise SystemExit(1)

head, tail = app.split(marker, 1)

# Add stable semantic classes to the generated recommendation card.
tail = tail.replace(
    '            <div>\n              <div class=\\"flex flex-wrap gap-2\\">',
    '            <div class=\\"result-card-content\\">\n              <div class=\\"result-badges\\">',
    1
)
tail = tail.replace(
    '              <h4>${escapeHtml(procedure.title)}</h4>',
    '              <h4 class=\\"result-title\\">${escapeHtml(procedure.title)}</h4>',
    1
)
tail = tail.replace(
    '              <p>${escapeHtml(procedure.description)}</p>',
    '              <p class=\\"result-description\\">${escapeHtml(procedure.description)}</p>',
    1
)
tail = tail.replace(
    '<p class=\\"text-xs text-slate-500\\">Owner:',
    '<p class=\\"result-meta\\">Owner:',
    1
)
tail = tail.replace(
    '<a class=\\"btn\\" data-procedure-link',
    '<a class=\\"btn result-card-action\\" aria-label=\\"Open ${escapeHtml(procedure.title)} procedure\\" data-procedure-link',
    1
)

app = head + marker + tail

required_app_tokens = [
    '${ranked.length === 1 ? "match" : "matches"}',
    'result-card-content',
    'result-badges',
    'result-title',
    'result-description',
    'result-meta',
    'result-card-action',
]
missing = [token for token in required_app_tokens if token not in app]
if missing:
    print("ERROR: Recommendation JavaScript update was incomplete:", ", ".join(missing), file=sys.stderr)
    raise SystemExit(1)

app_path.write_text(app, encoding="utf-8")

css = css_path.read_text(encoding="utf-8")
patch_css = patch_css_path.read_text(encoding="utf-8")

if CSS_START in css and CSS_END in css:
    before = css.split(CSS_START, 1)[0].rstrip()
    after = css.split(CSS_END, 1)[1].lstrip()
    css = before + "\n\n" + patch_css
    if after:
        css += "\n" + after
else:
    css = css.rstrip() + "\n\n" + patch_css

css_path.write_text(css, encoding="utf-8")

if app == original_app:
    print("ERROR: app.js was not changed. The repository may already contain a different wizard version.", file=sys.stderr)
    raise SystemExit(1)

print("Recommendation result layout fix applied successfully.")
print("Updated:", app_path)
print("Updated:", css_path)
print("Corrected: singular/plural match count.")
print("Improved: evidence spacing, status badges, warning, and procedure action placement.")
print("Ranking logic and knowledge-base content were not changed.")
