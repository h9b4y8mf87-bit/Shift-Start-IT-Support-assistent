# ShiftStart Enterprise Architecture Overhaul

This package implements the requested enterprise UX architecture while preserving the underlying ShiftStart procedure and symptom collections.

## Implemented

- 20/30/50 three-pane procedure workspace
- infinitely nestable category tree based on category paths (`Network > DNS > Windows Server`)
- sortable procedure data grid with Title, P0–P4 severity, Status, Last Updated and Owner
- in-context right-rail procedure loading without a full page reload
- global Ctrl+K / Cmd+K command palette
- fuzzy typo matching and "Showing results for…" correction feedback
- symptom / procedure / error-code result grouping
- homepage operational widgets
- evidence-aware Verified/revalidation status handling
- executive summary, governance strip, evidence gauge, impact scope and lifecycle timeline
- sticky procedure action bar
- persistent filter chips
- Inter/IBM Plex Sans-first typography stack, 16px base size and 1.7 article line height
- persistent dark mode
- skeleton loaders, top progress indicator and toast notifications
- enterprise trust footer with accurate non-attested compliance readiness labels
- structured Request Procedure, Suggest Edit and Report Error modals
- sponsor disclosure framework
- affiliate-link framework and local prototype tracking dashboard

## Important trust behavior

The patch does **not** falsely claim SOC 2 compliance or GDPR certification. It displays `SOC 2 — Not attested` and `GDPR readiness — Review required` until supporting assurance exists.

Stored `verified` content is only shown as green evidence-complete Verified when all six current validation evidence controls are recorded. Older verified labels with incomplete evidence appear as `Revalidation required`.

## Static-site limitations handled transparently

ShiftStart is currently a static Jekyll site. Therefore:

- "Top searched symptoms" uses weekly local-browser telemetry until a central analytics endpoint is configured.
- Request/Edit/Error forms save locally and copy structured payloads when no endpoint is configured.
- Affiliate clicks are stored locally and can optionally be POSTed to a configured endpoint.
- The affiliate dashboard is a prototype ledger, not authoritative commission accounting.
- "System Knowledge Health" measures procedure verification coverage, not live infrastructure uptime.

## Apply from the repository root

```bash
git status
git fetch origin
git pull --rebase origin main

unzip -q shiftstart-enterprise-architecture-overhaul.zip
python3 shiftstart-enterprise-architecture-overhaul/apply-enterprise-overhaul.py

node --check assets/js/enterprise-shell.js
node scripts/validate-enterprise-overhaul.js
npm install --no-audit --no-fund
npm run check
npm run build
```

If all checks pass:

```bash
rm -f shiftstart-enterprise-architecture-overhaul.zip
rm -rf shiftstart-enterprise-architecture-overhaul
rm -rf .shiftstart-backups

git add -A
git status
git commit -m "Overhaul ShiftStart enterprise architecture"
git push origin main
```

If `reports/content-audit.json` changes only because the validation timestamp was regenerated, you may restore it before committing if you do not want a timestamp-only diff:

```bash
git restore reports/content-audit.json
```
