#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import shutil, sys, re

repo = Path.cwd()
patch = Path(__file__).resolve().parent
payload = patch / 'payload'

required = [
    repo / '_layouts/default.html',
    repo / '_layouts/article.html',
    repo / 'index.html',
    repo / 'procedures/index.html',
    repo / '_data/kb.yml',
]
missing = [str(p) for p in required if not p.exists()]
if missing:
    print('ERROR: Run this from the ShiftStart repository root.', file=sys.stderr)
    for item in missing: print('-', item, file=sys.stderr)
    raise SystemExit(1)

protected = ['_procedures','_symptoms','_causes','_commands']
before = {name: len(list((repo/name).glob('*.md'))) if (repo/name).exists() else 0 for name in protected}

stamp = datetime.now().strftime('%Y%m%d-%H%M%S')
backup = repo / '.shiftstart-backups' / f'enterprise-overhaul-{stamp}'
for source in required:
    rel = source.relative_to(repo)
    dest = backup / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, dest)

# Copy the additive/replacement payload.
for source in payload.rglob('*'):
    if not source.is_file():
        continue
    rel = source.relative_to(payload)
    dest = repo / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, dest)
    print('Applied:', rel)

# Enhance the existing default layout without replacing unrelated integrations.
default_path = repo / '_layouts/default.html'
default = default_path.read_text(encoding='utf-8')

theme_script = '''  <script>\n    (() => {\n      try {\n        const saved = localStorage.getItem('shiftstart-theme');\n        const dark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;\n        document.documentElement.dataset.theme = saved || (dark ? 'dark' : 'light');\n      } catch (_) { document.documentElement.dataset.theme = 'light'; }\n    })();\n  </script>'''
if "shiftstart-theme" not in default:
    title_match = re.search(r'<title>.*?</title>', default, flags=re.S)
    if not title_match:
        raise SystemExit('ERROR: Could not locate <title> in _layouts/default.html')
    default = default[:title_match.end()] + '\n' + theme_script + default[title_match.end():]

css_link = '''  <link rel="stylesheet" href="{{ '/assets/css/enterprise-shell.css' | relative_url }}">'''
if '/assets/css/enterprise-shell.css' not in default:
    anchor = '''  <link rel="stylesheet" href="{{ '/assets/css/brand.css' | relative_url }}">'''
    if anchor not in default:
        anchor = '''  <link rel="stylesheet" href="{{ '/assets/css/production-readiness.css' | relative_url }}">'''
    if anchor in default:
        default = default.replace(anchor, anchor + '\n' + css_link, 1)
    elif '</head>' in default:
        default = default.replace('</head>', css_link + '\n</head>', 1)
    else:
        raise SystemExit('ERROR: Could not locate CSS insertion point.')

controls = '''  {% include enterprise-global-controls.html %}\n  {% include enterprise-trust-footer.html %}\n  {% include footer.html %}'''
if 'enterprise-global-controls.html' not in default:
    footer_include = '{% include footer.html %}'
    if footer_include not in default:
        raise SystemExit('ERROR: Could not locate footer include.')
    default = default.replace(footer_include, controls.strip(), 1)

js_link = '''  <script defer src="{{ '/assets/js/enterprise-shell.js' | relative_url }}"></script>'''
if '/assets/js/enterprise-shell.js' not in default:
    if '</body>' not in default:
        raise SystemExit('ERROR: Could not locate </body>.')
    default = default.replace('</body>', js_link + '\n</body>', 1)

default_path.write_text(default, encoding='utf-8')
print('Updated: _layouts/default.html')

# Add enterprise endpoint configuration without fabricating integrations.
kb_path = repo / '_data/kb.yml'
kb = kb_path.read_text(encoding='utf-8')
if '\nenterprise:\n' not in '\n' + kb:
    kb = kb.rstrip() + '''\n\nenterprise:\n  enabled: true\n  requestProcedureEndpoint: ''\n  editSuggestionEndpoint: ''\n  errorReportEndpoint: ''\n  analyticsEndpoint: ''\n  affiliateTrackingEndpoint: ''\n  telemetryMode: local_browser\n'''
    kb_path.write_text(kb, encoding='utf-8')
    print('Updated: _data/kb.yml')

# Knowledge files must not be added, removed or renamed by this patch.
after = {name: len(list((repo/name).glob('*.md'))) if (repo/name).exists() else 0 for name in protected}
if before != after:
    raise SystemExit(f'ERROR: Protected knowledge counts changed. Before={before} After={after}')

checks = {
    '_layouts/default.html': ['enterprise-shell.css','enterprise-shell.js','enterprise-global-controls.html','enterprise-trust-footer.html','shiftstart-theme'],
    '_layouts/article.html': ['ss-executive-summary','ss-metadata-strip','ss-lifecycle','ss-sticky-action-bar','assurance-banner','reports/content-audit.json','data-sponsored-procedure','data-affiliate-link'],
    '_layouts/enterprise-explorer.html': ['ss-workbench','data-category-tree','data-procedure-rows','data-detail-rail','P0/P1 Critical'],
    'procedures/index.html': ['layout: enterprise-explorer'],
    'index.html': ['enterprise-dashboard.html','data-command-trigger'],
    'enterprise-catalog.json': ['permalink: /assets/data/enterprise-catalog.json','evidenceComplete','symptoms'],
    'assets/js/enterprise-shell.js': ['initCommandPalette','levenshtein','initExplorer','loadDetail','toggleTheme','affiliateTrackingEndpoint'],
    'assets/css/enterprise-shell.css': ['grid-template-columns:minmax(13rem,20%)','data-theme','ss-status-verified'],
    '_includes/enterprise-trust-footer.html': ['SOC 2','Not attested','GDPR readiness','Report an Error'],
}
for rel, tokens in checks.items():
    text = (repo/rel).read_text(encoding='utf-8')
    absent = [token for token in tokens if token not in text]
    if absent:
        raise SystemExit(f'ERROR: {rel} missing expected markers: {absent}')

print('')
print('ShiftStart enterprise architecture overhaul applied successfully.')
print('Knowledge collections preserved:', before)
print('Backup created at:', backup.relative_to(repo))
print('')
print('Validation:')
print('  node --check assets/js/enterprise-shell.js')
print('  npm install --no-audit --no-fund')
print('  npm run check')
print('  npm run build')
