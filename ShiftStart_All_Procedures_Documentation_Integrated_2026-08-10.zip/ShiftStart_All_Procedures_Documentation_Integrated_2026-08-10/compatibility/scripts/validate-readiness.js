const fs = require("fs");
const path = require("path");
const matter = require("gray-matter");

const files = fs.readdirSync("_procedures").filter((name) => name.endsWith(".md")).sort();
const validRisks = new Set(["critical", "high", "medium", "low"]);
const priority = { critical: "P0", high: "P1", medium: "P2", low: "P3" };
const errors = [];
const warnings = [];
const statusCounts = {};
const riskCounts = { critical: 0, high: 0, medium: 0, low: 0 };
let documentationPassedCount = 0;
let legacyVerified = 0;
let evidenceCompleteVerified = 0;

const documentationHeadings = [
  "## Purpose and scope",
  "## Safety, authorisation and stop conditions",
  "## Evidence to capture before changes",
  "## Diagnostic path",
  "## Procedure",
  "## Rollback and recovery",
  "## Verification checklist",
  "## Escalation package",
  "## Documentation assurance"
];

const legacyEnterpriseHeadings = [
  "## Diagnostic Steps",
  "## Remediation Steps",
  "## Rollback Steps",
  "## Verification Steps",
  "## Escalation Path"
];

function completeEvidence(data) {
  const e = data.verification_evidence || {};
  const booleans = [
    "diagnostic_tested",
    "remediation_tested",
    "rollback_confirmed",
    "escalation_confirmed",
    "time_validated"
  ];
  return booleans.every((key) => e[key] === true) &&
    typeof e.owner_signoff === "string" &&
    e.owner_signoff.trim().length > 1 &&
    /^\d{4}-\d{2}-\d{2}$/.test(String(data.last_tested || "")) &&
    Array.isArray(data.tested_platforms) &&
    data.tested_platforms.length > 0;
}

function requireHeadings(file, content, headings) {
  let previous = -1;
  for (const heading of headings) {
    const at = content.indexOf(heading);
    if (at < 0) {
      errors.push(`${file}: missing required section '${heading}'`);
    } else if (at <= previous) {
      errors.push(`${file}: required sections are not in the expected order`);
    }
    previous = Math.max(previous, at);
  }
}

for (const name of files) {
  const file = path.join("_procedures", name);
  const parsed = matter(fs.readFileSync(file, "utf8"));
  const d = parsed.data;
  const risk = String(d.severity || "").toLowerCase();

  if (!validRisks.has(risk)) errors.push(`${file}: missing or invalid explicit severity`);
  else riskCounts[risk]++;

  if (d.risk_model !== "impact-v1") errors.push(`${file}: risk_model must be impact-v1`);
  if (!String(d.risk_basis || "").trim()) errors.push(`${file}: missing risk_basis`);
  if (d.verification_priority !== priority[risk]) {
    errors.push(`${file}: verification_priority does not match severity`);
  }

  const status = d.content_status || "missing";
  statusCounts[status] = (statusCounts[status] || 0) + 1;

  const docPassed =
    d.documentation_review === "passed" &&
    d.quality_gate === "passed" &&
    d.generated_baseline === false;

  if (docPassed) {
    documentationPassedCount++;
    if (d.live_validation_required !== true && !completeEvidence(d)) {
      errors.push(`${file}: documentation-approved content without live evidence must retain live_validation_required: true`);
    }
    if (!Array.isArray(d.source_references) || d.source_references.length === 0) {
      errors.push(`${file}: documentation-approved procedure requires source_references`);
    }
    requireHeadings(file, parsed.content, documentationHeadings);
  }

  if (
    status === "under_review" &&
    ![
      "documentation_verified_pending_live_validation",
      "evidence_complete_pending_promotion",
      "awaiting_live_validation"
    ].includes(d.verification_state)
  ) {
    errors.push(`${file}: under_review procedure requires a recognised verification_state`);
  }

  if (status === "verified") {
    for (const key of ["support_tier", "estimated_time", "owner_team"]) {
      if (!String(d[key] || "").trim()) {
        errors.push(`${file}: verified procedure missing ${key}`);
      }
    }

    if (docPassed) {
      // The full documentation pass is the current runbook standard.
      if (
        ![
          "documentation_verified_live_evidence_incomplete",
          "documentation_verified_live_validated"
        ].includes(d.verification_state)
      ) {
        warnings.push(`${file}: verified documentation pass has no explicit live-evidence state`);
      }
    } else {
      if (d.runbook_template !== "enterprise-v1") {
        errors.push(`${file}: legacy verified procedure must use enterprise-v1`);
      }
      requireHeadings(file, parsed.content, legacyEnterpriseHeadings);
    }

    if (completeEvidence(d) || d.verification_evidence_state === "complete") {
      evidenceCompleteVerified++;
    } else {
      legacyVerified++;
      warnings.push(`${file}: verified status is inherited but recorded live-test/owner-signoff evidence is incomplete`);
    }
  }
}

if (files.length !== 421) errors.push(`Expected 421 procedures; found ${files.length}`);
if (documentationPassedCount !== 421) {
  errors.push(`Expected documentation_review: passed on all 421 procedures; found ${documentationPassedCount}`);
}

if (warnings.length) console.warn(warnings.join("\n"));
if (errors.length) {
  console.error(errors.join("\n"));
  process.exit(1);
}

console.log(
  `Production readiness validation passed: ${files.length} procedures; documentation=${documentationPassedCount}/${files.length}; risks ${JSON.stringify(riskCounts)}; statuses ${JSON.stringify(statusCounts)}.`
);
console.log(
  `Verified evidence states: complete=${evidenceCompleteVerified}, inherited-pending-live-revalidation=${legacyVerified}.`
);
