const fs = require("fs");
const path = require("path");
const matter = require("gray-matter");
const yaml = require("js-yaml");

const MODE = process.argv.includes("--apply") ? "apply" : process.argv.includes("--promote") ? "promote" : "report";
const DIR = "_procedures";
const VALID_RISKS = new Set(["critical", "high", "medium", "low"]);
const PRIORITY = { critical: "P0", high: "P1", medium: "P2", low: "P3" };
const TODAY = new Date().toISOString().slice(0, 10);

function documentationPassed(data) {
  return data.documentation_review === "passed" &&
    data.quality_gate === "passed" &&
    data.generated_baseline === false &&
    data.risk_model === "impact-v1" &&
    VALID_RISKS.has(String(data.severity || "").toLowerCase());
}

function hasCompleteEvidence(data) {
  const e = data.verification_evidence || {};
  const booleans = [
    "diagnostic_tested",
    "remediation_tested",
    "rollback_confirmed",
    "escalation_confirmed",
    "time_validated"
  ];
  return booleans.every((key) => e[key] === true) &&
    typeof e.owner_signoff === "string" &&
    e.owner_signoff.trim().length > 1 &&
    /^\d{4}-\d{2}-\d{2}$/.test(String(data.last_tested || "")) &&
    Array.isArray(data.tested_platforms) &&
    data.tested_platforms.length > 0 &&
    data.owner_team &&
    data.support_tier &&
    data.estimated_time;
}

function preserveOrNormaliseRisk(data) {
  const risk = String(data.severity || "").toLowerCase();
  if (!VALID_RISKS.has(risk)) {
    throw new Error(`Invalid or missing risk '${data.severity}' on ${data.slug || data.title}`);
  }
  data.severity = risk;
  data.risk_level = risk;
  data.risk_model = "impact-v1";
  data.verification_priority = PRIORITY[risk];
  if (!String(data.risk_basis || "").trim()) {
    data.risk_basis = `${risk} risk under the repository impact model; verification priority ${PRIORITY[risk]}.`;
  }
}

function serialize(data, content) {
  const front = yaml.dump(data, { lineWidth: 120, noRefs: true, sortKeys: false }).trim();
  return `---\n${front}\n---\n${content.replace(/^\n+/, "")}`;
}

const files = fs.readdirSync(DIR).filter((name) => name.endsWith(".md")).sort();
const rows = [];
const riskCounts = { critical: 0, high: 0, medium: 0, low: 0 };
const statusCounts = {};
let evidenceCompleteVerified = 0;
let promoted = 0;

for (const name of files) {
  const file = path.join(DIR, name);
  const parsed = matter(fs.readFileSync(file, "utf8"));
  const data = parsed.data;
  const slug = data.slug || path.basename(name, ".md");

  preserveOrNormaliseRisk(data);

  const evidenceComplete = hasCompleteEvidence(data);
  const docPassed = documentationPassed(data);

  if (data.content_status === "under_review") {
    data.verification_state = evidenceComplete
      ? "evidence_complete_pending_promotion"
      : docPassed
        ? "documentation_verified_pending_live_validation"
        : "awaiting_live_validation";
  }

  if (data.content_status === "verified") {
    if (evidenceComplete) {
      data.verification_evidence_state = "complete";
      data.verification_state = "documentation_verified_live_validated";
      evidenceCompleteVerified++;
    } else if (docPassed) {
      data.verification_evidence_state = "legacy_verified_pending_revalidation";
      data.verification_state = "documentation_verified_live_evidence_incomplete";
      data.live_validation_required = true;
    }
  }

  if (
    MODE === "promote" &&
    data.content_status === "under_review" &&
    docPassed &&
    evidenceComplete
  ) {
    data.content_status = "verified";
    data.quality_gate = "passed";
    data.generated_baseline = false;
    data.verification_evidence_state = "complete";
    data.verification_state = "documentation_verified_live_validated";
    data.live_validation_required = false;
    data.live_validation_note = "Live validation evidence and technical-owner sign-off recorded for the current review cycle.";
    data.reviewed_by = data.verification_evidence.owner_signoff;
    data.last_reviewed = TODAY;
    promoted++;
    evidenceCompleteVerified++;
  }

  riskCounts[data.severity]++;
  statusCounts[data.content_status || "missing"] =
    (statusCounts[data.content_status || "missing"] || 0) + 1;

  const e = data.verification_evidence || {};
  rows.push({
    priority: data.verification_priority,
    slug,
    title: data.title || "",
    category: data.category || "",
    risk: data.severity,
    status: data.content_status || "",
    documentation_review: data.documentation_review || "",
    verification_state: data.verification_state || data.verification_evidence_state || "",
    support_tier: data.support_tier || "",
    estimated_time: data.estimated_time || "",
    owner_team: data.owner_team || "",
    diagnostic_tested: e.diagnostic_tested === true,
    remediation_tested: e.remediation_tested === true,
    rollback_confirmed: e.rollback_confirmed === true,
    escalation_confirmed: e.escalation_confirmed === true,
    time_validated: e.time_validated === true,
    owner_signoff: e.owner_signoff || "",
    last_tested: data.last_tested || ""
  });

  if (MODE === "apply" || MODE === "promote") {
    fs.writeFileSync(file, serialize(data, parsed.content));
  }
}

rows.sort((a, b) => {
  const p = { P0: 0, P1: 1, P2: 2, P3: 3 };
  return p[a.priority] - p[b.priority] ||
    a.category.localeCompare(b.category) ||
    a.title.localeCompare(b.title);
});

fs.mkdirSync("reports", { recursive: true });
fs.mkdirSync("_data", { recursive: true });

const csvHeaders = Object.keys(rows[0] || {});
const csvEscape = (value) => {
  const text = String(value ?? "");
  return /[",\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
};

fs.writeFileSync(
  "reports/verification-queue.csv",
  [csvHeaders.join(","), ...rows.map((row) => csvHeaders.map((h) => csvEscape(row[h])).join(","))].join("\n") + "\n"
);

const queueByPriority = {
  P0: rows.filter((r) => r.priority === "P0" && r.status !== "verified"),
  P1: rows.filter((r) => r.priority === "P1" && r.status !== "verified"),
  P2: rows.filter((r) => r.priority === "P2" && r.status !== "verified"),
  P3: rows.filter((r) => r.priority === "P3" && r.status !== "verified")
};

const report = {
  schemaVersion: 2,
  generatedAt: new Date().toISOString(),
  totalProcedures: files.length,
  riskModel: "impact-v1",
  riskCounts,
  statusCounts,
  verificationQueueCounts: Object.fromEntries(
    Object.entries(queueByPriority).map(([k, v]) => [k, v.length])
  ),
  evidenceCompleteVerified,
  documentationPassed: rows.filter((r) => r.documentation_review === "passed").length,
  targetVerified80Percent: Math.ceil(files.length * 0.8),
  newlyPromotedThisRun: promoted,
  note: "Documentation approval is separate from live operational verification. Under-review content is promoted only when all live-test, rollback, escalation, time-validation and owner-signoff evidence is complete."
};

fs.writeFileSync("reports/risk-classification.json", JSON.stringify({ ...report, procedures: rows }, null, 2));
fs.writeFileSync("reports/verification-queue.json", JSON.stringify({ ...report, batches: queueByPriority }, null, 2));
fs.writeFileSync("_data/verification-dashboard.json", JSON.stringify(report, null, 2));

console.log(`Production-readiness ${MODE}: ${files.length} procedures.`);
console.log(`Documentation pass: ${report.documentationPassed}/${files.length}.`);
console.log(`Risk counts: ${JSON.stringify(riskCounts)}.`);
console.log(`Statuses: ${JSON.stringify(statusCounts)}.`);
console.log(`Verification queue: ${JSON.stringify(report.verificationQueueCounts)}.`);
console.log(`Evidence-complete verified: ${evidenceCompleteVerified}; 80% target: ${report.targetVerified80Percent}.`);
if (MODE === "promote") console.log(`Promoted ${promoted} evidence-complete procedures.`);
