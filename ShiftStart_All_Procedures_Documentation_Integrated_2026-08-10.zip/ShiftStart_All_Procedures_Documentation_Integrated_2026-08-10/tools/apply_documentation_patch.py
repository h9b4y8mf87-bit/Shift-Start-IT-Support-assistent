#!/usr/bin/env python3
from pathlib import Path
import argparse, shutil, subprocess, sys, datetime

SNAPSHOT = "710e7731d63a7276d9f4e96cd2fb7c234208ac85"
PACKAGE = Path(__file__).resolve().parents[1]
SOURCE = PACKAGE / "_procedures"
VERIFIER = PACKAGE / "tools" / "verify_procedure_documentation.py"

def git_head(repo):
    try:
        return subprocess.check_output(["git","-C",str(repo),"rev-parse","HEAD"], text=True, stderr=subprocess.DEVNULL).strip()
    except Exception:
        return None

def main():
    ap=argparse.ArgumentParser(description="Apply the ShiftStart full procedure documentation remediation package.")
    ap.add_argument("repo", help="Path to the checked-out ShiftStart repository")
    ap.add_argument("--allow-head-mismatch", action="store_true", help="Apply even when repository HEAD differs from the audited snapshot")
    args=ap.parse_args(); repo=Path(args.repo).resolve(); target=repo/"_procedures"
    if not repo.exists() or not target.exists():
        raise SystemExit("Repository path or _procedures directory not found.")
    head=git_head(repo)
    if head and head != SNAPSHOT and not args.allow_head_mismatch:
        raise SystemExit(f"HEAD {head} differs from audited snapshot {SNAPSHOT}. Review/rebase first or use --allow-head-mismatch after inspecting the difference.")
    package_files=sorted(SOURCE.glob("*.md"))
    if len(package_files) != 421:
        raise SystemExit(f"Package integrity error: expected 421 procedure files, found {len(package_files)}")
    stamp=datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    backup=repo/".shiftstart-backups"/stamp/"_procedures"
    shutil.copytree(target, backup)
    for src in package_files:
        shutil.copy2(src, target/src.name)
    current={p.name for p in target.glob("*.md")}; expected={p.name for p in package_files}
    extra=current-expected
    if extra:
        print(f"NOTE: {len(extra)} extra procedure file(s) exist in the target checkout and were left untouched.")
    rc=subprocess.call([sys.executable,str(VERIFIER),str(target)])
    if rc:
        print(f"Verification failed. Backup is at: {backup}", file=sys.stderr); return rc
    print(f"Applied 421 procedure files. Backup: {backup}")
    print("Documentation gate passed. Review git diff and perform live technical-owner validation before changing production verification statuses.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
