#!/usr/bin/env python3
"""ShiftStart procedure documentation gate.

This verifies the *documentation/technical-content* gate. It intentionally does
not promote content_status to verified and cannot replace environment-specific
live testing, owner sign-off, change approval, or evidence collection.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import re, sys, collections
try:
    import yaml
except Exception:
    print('ERROR: PyYAML is required: python -m pip install pyyaml', file=sys.stderr)
    raise

REQUIRED_META = [
    'title','slug','category','risk_level','severity','support_tier','owner_team',
    'approval_required','content_status','generated_baseline','source_references',
    'quality_gate','documentation_review','documentation_reviewed_on',
    'live_validation_required','live_validation_note','verification_state'
]
REQUIRED_HEADING_GROUPS = [
    ('Purpose and scope', ['Purpose and scope']),
    ('Safety/stop controls', ['Safety','Before you start','Stop conditions','Stop and escalate conditions']),
    ('Evidence', ['Evidence','Before you start']),
    ('Diagnostics/decision path', ['Diagnostic','Evidence priorities','Choose the correct action','Approved recovery sources','Before you start']),
    ('Procedure', ['Procedure']),
    ('Rollback/recovery/irreversibility', ['Rollback','Stop conditions','Stop and escalate conditions']),
    ('Verification checklist', ['Verification checklist']),
    ('Escalation', ['Escalation','Stop conditions','Stop and escalate conditions']),
    ('Documentation assurance', ['Documentation assurance'])
]
FORBIDDEN_GENERIC = [
    'Confirm the report and reproduce safely',
    'Determine scope and priority',
    'Apply the primary approved remediation',
    'Apply secondary remediation only when justified',
    'Protect data and establish a rollback point',
    'The step completes with evidence that can be compared with the next decision point.'
]

DEEP = {
    'perform-an-approved-remote-wipe.md': ['Retire','BYOD','legal hold','Wipe','exact device'],
    'recover-a-device-requesting-a-bitlocker-recovery-key.md': ['48-digit','Recovery Key ID','Get-BitLockerVolume','escrow','secret'],
    'collect-security-incident-evidence.md': ['provenance','SHA-256','Get-FileHash','restricted'],
    'add-or-remove-security-group-membership.md': ['Add-ADGroupMember','Remove-ADGroupMember','-WhatIf','immutable','source of authority'],
}

def read_doc(path: Path):
    txt = path.read_text(encoding='utf-8')
    if not txt.startswith('---\n') or '\n---\n' not in txt[4:]:
        raise ValueError('invalid YAML front matter')
    end = txt.find('\n---\n',4)
    meta = yaml.safe_load(txt[4:end]) or {}
    body = txt[end+5:]
    return meta, body, txt

def contains_all(text: str, terms):
    low=text.lower()
    return all(t.lower() in low for t in terms)

def mode_flags(meta, body):
    title=str(meta.get('title','')).lower(); cat=str(meta.get('category','')).lower(); text=(title+' '+body[:500]).lower()
    return {
        'incident': ('security & compliance' in cat and any(k in title for k in ['respond','comprom','ransom','malicious','phish','lost or stolen','malware','suspicious'])) or 'incident response' in text,
        'evidence': any(k in title for k in ['evidence','chain of custody','forensic']),
        'legal': any(k in title for k in ['legal hold','retention request']),
        'destructive': any(k in title for k in ['wipe','reimage','factory reset','secure erase','erase a','retire a device','decommission','dispose','reset a managed']),
        'firmware': any(k in title for k in ['bios','firmware']),
        'recovery_secret': 'bitlocker' in title and 'recovery' in title,
        'access_change': ('identity & access' in cat and any(k in title for k in ['add or remove','grant','remove access','provision','role','group membership','licence','guest access','reset','password','mfa','conditional access','service account','single sign-on','smart-card','hello','certificate'])),
        'recovery': ('data protection' in cat and any(k in title for k in ['restore','recover','migrate'])),
        'infrastructure': any(k in cat for k in ['servers & core infrastructure','network & connectivity']) and any(k in title for k in ['restart','dhcp','dns','gateway','firewall','switch','router','site internet','scope','service issue','server']),
    }

def check(path: Path):
    errors=[]
    try:
        meta, body, txt = read_doc(path)
    except Exception as e:
        return [f'parse: {e}'], None
    title=str(meta.get('title',path.stem)); risk=str(meta.get('risk_level','')).lower()
    for k in REQUIRED_META:
        if k not in meta:
            errors.append(f'metadata missing: {k}')
    if meta.get('generated_baseline') is not False:
        errors.append('generated_baseline must be false')
    if meta.get('quality_gate') != 'passed':
        errors.append('quality_gate must be passed')
    if meta.get('documentation_review') != 'passed':
        errors.append('documentation_review must be passed')
    if meta.get('live_validation_required') is not True:
        errors.append('live_validation_required must be true')
    refs=meta.get('source_references') or []
    if not isinstance(refs,list) or not refs:
        errors.append('source_references must contain at least one source')
    for label, alternatives in REQUIRED_HEADING_GROUPS:
        if not any(re.search(r'^## .*'+re.escape(h), body, re.I|re.M) for h in alternatives):
            errors.append(f'missing section matching: {label}')
    for phrase in FORBIDDEN_GENERIC:
        if phrase.lower() in txt.lower():
            errors.append(f'generic baseline phrase remains: {phrase}')
    # Meaningful expected outcomes: each numbered procedure step should be followed by Expected result before next step/section.
    proc = re.search(r'^## Procedure\s*\n(.*?)(?=^## )', body, re.S|re.M)
    if not proc:
        errors.append('Procedure section could not be parsed')
    else:
        section=proc.group(1)
        steps=list(re.finditer(r'^(\d+)\. \*\*(.+?)\*\*',section,re.M))
        if len(steps) < 5:
            errors.append(f'procedure has too few execution steps: {len(steps)}')
        for i,m in enumerate(steps):
            end=steps[i+1].start() if i+1<len(steps) else len(section)
            chunk=section[m.start():end]
            if 'Expected result:' not in chunk and '<strong>Expected result:' not in chunk:
                errors.append(f'step {m.group(1)} lacks expected result')
    words=len(re.findall(r"\b[\w'-]+\b", body))
    if words < 650:
        errors.append(f'body too short for enterprise runbook gate: {words} words')
    if title.lower() not in body.lower():
        errors.append('title not referenced in body')
    if risk in ('high','critical'):
        low=body.lower()
        for term in ['stop','escalat','approval']:
            if term not in low: errors.append(f'{risk} procedure missing {term} control')
    flags=mode_flags(meta,body); low=body.lower()
    if flags['incident']:
        if not any(p in low for p in ['do not reproduce','no reproduction','do not conduct normal reproduction']): errors.append('incident runbook lacks non-reproduction control')
        for term in ['preserv','contain','security operations']:
            if term not in low: errors.append(f'incident runbook missing {term}')
    if flags['evidence']:
        for term in ['provenance','sha-256','custody','restricted']:
            if term not in low: errors.append(f'evidence runbook missing {term}')
    if flags['legal']:
        for term in ['legal','do not delete','retention','preserv']:
            if term not in low: errors.append(f'legal/retention runbook missing {term}')
    if flags['destructive']:
        for term in ['irrevers','backup','legal','exact']:
            if term not in low: errors.append(f'destructive runbook missing {term}')
    if flags['firmware']:
        for term in ['oem','power','encryption','do not interrupt']:
            if term not in low: errors.append(f'firmware runbook missing {term}')
    if flags['recovery_secret']:
        for term in ['recovery key id','escrow','secret','do not']:
            if term not in low: errors.append(f'recovery-secret runbook missing {term}')
    if flags['access_change']:
        for term in ['least privilege','approval','before-state','after-state']:
            if term not in low: errors.append(f'access-change runbook missing {term}')
    if flags['recovery']:
        for term in ['alternate','overwrite','owner','recover']:
            if term not in low: errors.append(f'data-recovery runbook missing {term}')
    if flags['infrastructure']:
        for term in ['rollback','impact','change','before-state']:
            if term not in low: errors.append(f'infrastructure runbook missing {term}')
    if path.name in DEEP:
        for term in DEEP[path.name]:
            if term.lower() not in low: errors.append(f'deep-control missing: {term}')
    # Cross-topic artifacts caught in semantic audit.
    if str(meta.get('category')) != 'Business Applications & Browsers' and 'Capture URL, transaction, user, timestamp, correlation ID, browser/client version and exact response.' in body:
        errors.append('cross-topic web-application diagnostic found outside business-application category')
    return errors, meta

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('procedure_dir', nargs='?', default=str(Path(__file__).resolve().parents[1]/'_procedures'))
    args=ap.parse_args(); root=Path(args.procedure_dir)
    files=sorted(root.glob('*.md'))
    failures=[]; slugs={}; titles={}; stats=collections.Counter()
    if len(files)!=421:
        failures.append((root,[f'expected 421 procedure files, found {len(files)}']))
    for f in files:
        errs, meta=check(f)
        if meta:
            slug=str(meta.get('slug','')); title=str(meta.get('title',''))
            if slug in slugs: errs.append(f'duplicate slug with {slugs[slug].name}')
            else: slugs[slug]=f
            if title in titles: errs.append(f'duplicate title with {titles[title].name}')
            else: titles[title]=f
            stats['content_status:'+str(meta.get('content_status'))]+=1
            stats['risk:'+str(meta.get('risk_level'))]+=1
            stats['category:'+str(meta.get('category'))]+=1
        if errs: failures.append((f,errs))
    print(f'ShiftStart documentation gate: {len(files)-len([x for x in failures if x[0] != root])}/{len(files)} procedure files passing')
    print(f'Files: {len(files)} | unique slugs: {len(slugs)} | unique titles: {len(titles)}')
    print('Status counts:', {k.split(':',1)[1]:v for k,v in stats.items() if k.startswith('content_status:')})
    print('Risk counts:', {k.split(':',1)[1]:v for k,v in stats.items() if k.startswith('risk:')})
    if failures:
        print('\nFAILURES:')
        for f,errs in failures:
            print(f'- {f}')
            for e in errs: print(f'    * {e}')
        return 1
    print('\nPASS: all 421 procedures satisfy the documentation/technical-content gate.')
    print('NOTE: this does not constitute production live validation or technical-owner sign-off.')
    return 0

if __name__=='__main__':
    raise SystemExit(main())
