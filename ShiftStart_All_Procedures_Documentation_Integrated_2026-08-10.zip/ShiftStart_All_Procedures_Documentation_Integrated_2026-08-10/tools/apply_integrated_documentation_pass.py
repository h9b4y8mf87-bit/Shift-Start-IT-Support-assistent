#!/usr/bin/env python3
from pathlib import Path
import argparse
import shutil
import subprocess
import sys
import datetime

PACKAGE = Path(__file__).resolve().parents[1]
DOC_APPLIER = PACKAGE / "tools" / "apply_documentation_patch.py"
COMPAT = PACKAGE / "compatibility"

def copy_with_backup(repo, relative, backup_root):
    src = COMPAT / relative
    dst = repo / relative
    if dst.exists():
        backup = backup_root / relative
        backup.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(dst, backup)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    print(f"Updated compatibility: {relative}")

def main():
    ap = argparse.ArgumentParser(
        description="Apply the 421-procedure documentation pass and reconcile it with ShiftStart production-readiness governance."
    )
    ap.add_argument("repo", nargs="?", default=".", help="Path to ShiftStart checkout (default: current directory)")
    ap.add_argument("--allow-head-mismatch", action="store_true")
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    if not (repo / "_procedures").exists():
        raise SystemExit("ShiftStart _procedures directory not found.")

    doc_cmd = [sys.executable, str(DOC_APPLIER), str(repo)]
    if args.allow_head_mismatch:
        doc_cmd.append("--allow-head-mismatch")

    rc = subprocess.call(doc_cmd)
    if rc:
        return rc

    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    backup_root = repo / ".shiftstart-backups" / stamp / "documentation-readiness-compatibility"

    for relative in [
        Path("scripts/production-readiness.js"),
        Path("scripts/validate-readiness.js"),
        Path("_data/verification-policy.yml")
    ]:
        copy_with_backup(repo, relative, backup_root)

    # Preserve the documentation audit package in the repo's reports directory.
    reports = repo / "reports" / "documentation-pass-2026-08-10"
    reports.mkdir(parents=True, exist_ok=True)
    for name in [
        "DOCUMENTATION-VERIFICATION-REPORT.md",
        "verification_manifest.csv",
        "QA-SUMMARY.json",
        "SOURCE-LIBRARY.md",
        "VERIFICATION-RESULT.txt",
        "SHA256SUMS.txt"
    ]:
        src = PACKAGE / name
        if src.exists():
            shutil.copy2(src, reports / name)

    verifier = PACKAGE / "tools" / "verify_procedure_documentation.py"
    rc = subprocess.call([sys.executable, str(verifier), str(repo / "_procedures")])
    if rc:
        print("Documentation verifier failed after integration.", file=sys.stderr)
        return rc

    for script in [
        repo / "scripts" / "production-readiness.js",
        repo / "scripts" / "validate-readiness.js"
    ]:
        rc = subprocess.call(["node", "--check", str(script)])
        if rc:
            return rc

    print("")
    print("Integrated documentation + readiness layer applied successfully.")
    print("421 procedure files passed the documentation gate.")
    print("Risk classifications from the audited documentation pass are preserved.")
    print("No under-review procedure was promoted.")
    print("")
    print("Next commands:")
    print("  npm install --no-audit --no-fund")
    print("  npm run check")
    print("")
    print("Do NOT run readiness:promote until real live-validation evidence and owner sign-off have been recorded.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
