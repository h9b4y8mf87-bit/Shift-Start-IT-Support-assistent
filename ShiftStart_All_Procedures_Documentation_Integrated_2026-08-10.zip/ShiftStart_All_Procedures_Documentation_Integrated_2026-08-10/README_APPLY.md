# Apply the ShiftStart procedure remediation package

This package contains **421 replacement procedure Markdown files** audited from GitHub Pages build artifact `9051302904` at commit `710e7731d63a7276d9f4e96cd2fb7c234208ac85`.

## What the package guarantees

- 421/421 files pass the included **documentation/technical-content** verifier.
- Generic inherited runbook language that was not safe/specific enough for all topics has been replaced or remediated.
- High-risk modes receive explicit safety, authorization, evidence, rollback/irreversibility, verification and escalation controls.
- Existing `content_status`, `reviewed_by` and `last_tested` evidence is **not fabricated**. Documentation approval and live operational validation are deliberately separated.

## Recommended application method

1. Check out the repository at the audited commit, or inspect/reconcile changes made since that commit.
2. Install the verifier dependency: `python -m pip install -r requirements.txt`.
3. Run: `python tools/apply_documentation_patch.py /path/to/Shift-Start-IT-Support-assistent`.
4. Review the generated `git diff` before committing.
5. Run the site's normal Jekyll/content-audit workflow.
6. Have the owning technical team live-test high-risk procedures in a controlled environment and record reviewer/test evidence before promoting `content_status` to production `verified`.

If the repository has moved beyond `710e7731d63a7276d9f4e96cd2fb7c234208ac85`, the apply script stops by default so newer edits are not silently overwritten. Reconcile the changes first; use `--allow-head-mismatch` only after reviewing the difference.

## Independent verification

Run:

```bash
python tools/verify_procedure_documentation.py _procedures
```

Expected result: `421/421 procedure files passing` followed by the explicit note that the result is a documentation gate, not live operational sign-off.
