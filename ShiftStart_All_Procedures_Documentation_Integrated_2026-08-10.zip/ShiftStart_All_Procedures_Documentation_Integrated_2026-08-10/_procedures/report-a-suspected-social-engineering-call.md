---
title: Report a suspected social-engineering call
slug: report-a-suspected-social-engineering-call
description: Enterprise runbook to report a suspected social-engineering call without skipping evidence, verification, rollback
  or escalation requirements.
content_type: procedure
category: Security & Compliance
service: Security & Compliance
severity: medium
support_tier: L1-L3
owner_team: Security Operations or Incident Response
platforms:
- EDR
- SIEM
- Identity
- Email security
risk_level: medium
estimated_time: 15-45 minutes
tags:
- a
- call
- engineering
- l1-l3
- report
- security-and-compliance
- social
- suspected
error_codes: []
tldr: 'Treat report a suspected social-engineering call as an incident-response workflow: preserve evidence, scope impact,
  contain through Security Operations, remediate only when authorized, and verify safe recovery before reconnecting or closing.'
related_symptoms:
- report-a-suspected-social-engineering-call
- a-security-or-compliance-concern-is-reported
symptom_weights:
  report-a-suspected-social-engineering-call: 10
  a-security-or-compliance-concern-is-reported: 3
related_causes: []
related_commands: []
next_steps: []
escalation: Escalate to Security Operations or Incident Response with scope, timestamps, evidence, actions, approvals, rollback
  state and failed verification criteria when the runbook reaches a stop condition or requires authority outside L1-L3.
last_reviewed: '2026-08-10'
review_cycle_days: 90
required_role: technician
approval_required: Operate only under the incident/case owner or Security Operations process. Destructive or containment actions
  require the authority defined in the incident-response plan.
content_status: under_review
generated_baseline: false
reviewed_by: ''
last_tested: ''
tested_platforms: []
source_references:
- https://csrc.nist.gov/pubs/sp/800/61/r3/final
- https://csrc.nist.gov/pubs/sp/800/86/final
- https://learn.microsoft.com/en-us/defender-endpoint/respond-machine-alerts
change_record: 'Full-catalogue documentation remediation: replaced generic baseline flow with risk-aware, procedure-specific
  diagnostics, safety controls, remediation, rollback, verification and escalation guidance.'
quality_gate: passed
documentation_review: passed
documentation_reviewed_on: '2026-08-10'
live_validation_required: true
live_validation_note: Technical-owner live validation and environment-specific sign-off remain required; no live-test evidence
  is fabricated by this documentation pass.
permalink: /procedures/report-a-suspected-social-engineering-call/
layout: article
risk_model: impact-v1
risk_basis: medium risk under the repository impact model; verification priority P2.
verification_priority: P2
verification_state: documentation_verified_pending_live_validation
---
## Purpose and scope

Enterprise runbook to report a suspected social-engineering call without skipping evidence, verification, rollback or escalation requirements.

Use this runbook for security and compliance response under incident-response authority with evidence preservation and controlled containment. It is a support procedure, not authority to bypass change management, security policy, privacy/records obligations or the owning team's operational controls.

## Safety, authorisation and stop conditions

**Approval requirement:** Operate only under the incident/case owner or Security Operations process. Destructive or containment actions require the authority defined in the incident-response plan.

- Verify the exact user, device, service, tenant/site or resource before making changes; use immutable identifiers where available.
- Work within the assigned support tier and use named administrative accounts or approved privileged-access elevation.
- Capture the current state before any change so the action and rollback can be reconstructed.
- Do not request or record passwords, MFA codes, recovery secrets, private keys, access tokens or other credentials in the ticket.
- Do not ask the user to reproduce suspicious activity, reopen a malicious file/link or reconnect an isolated device.
- Preserve required evidence before cleanup; containment, eradication and recovery are separate authorized phases.
- Use out-of-band or approved incident communications if normal channels may be monitored or compromised.

## Evidence to capture before changes

- incident/case ID and security owner
- affected identities/assets and immutable IDs
- alert source, timestamps and timezone
- EDR/SIEM/email/identity/network evidence references
- actions already taken and custody/provenance details
- case/incident ID, incident owner and collection/containment authorization
- evidence provenance, hashes and custody handoffs where applicable

## Diagnostic path

- do not ask users to reproduce suspicious or malicious activity
- preserve volatile/time-sensitive evidence when authorized before cleanup
- correlate EDR, identity, email, network and endpoint telemetry
- scope affected systems/accounts before eradication or recovery

### Read-only or low-risk diagnostic commands

Use the owning platform's read-only health, audit, log or inventory views first. Do not introduce a configuration change merely to gather a baseline.

## Procedure

1. **Activate the incident path.** Confirm the case/incident owner, affected assets/accounts and severity. Use the approved incident-response communications and decision authority.

   **Expected result:** Activate the incident path produces a recorded, observable result for **Report a suspected social-engineering call** that is consistent with the approved scope and can be compared with the before-state.

2. **Preserve and scope.** Capture alert IDs, timestamps, affected identities/devices and volatile/time-sensitive evidence as directed. Do not conduct normal reproduction testing.

   **Expected result:** The affected identities, devices, services and time window are bounded sufficiently for Security Operations to make a containment decision.

3. **Contain.** Use the approved Security Operations containment action appropriate to the confirmed scope. Record who authorized it and when.

   **Expected result:** Approved containment is active on the confirmed scope and its timestamp, authorizer and observed effect are recorded.

4. **Investigate before cleanup.** Correlate endpoint, identity, email, network and service telemetry to determine initial access, spread, persistence and data impact.

   **Expected result:** Evidence narrows the fault to a specific layer, dependency, policy, component or control before remediation is attempted.

5. **Eradicate only when authorized.** Remove malicious persistence, revoke compromised access and rebuild/repair affected assets only after the incident lead confirms required evidence is preserved.

   **Expected result:** Eradicate only when authorized produces a recorded, observable result for **Report a suspected social-engineering call** that is consistent with the approved scope and can be compared with the before-state.

6. **Recover safely.** Restore service from a known-good state, reapply required security controls and prevent a contained device/account from returning to production until Security Operations approves it.

   **Expected result:** Recover safely produces a recorded, observable result for **Report a suspected social-engineering call** that is consistent with the approved scope and can be compared with the before-state.

7. **Verify the result.** Repeat the original business test using the normal user path and confirm: The exact task addressed by **Report a suspected social-engineering call** succeeds end-to-end, the affected service remains stable, and no security, data-integrity or management control has been weakened.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

8. **Monitor for recurrence.** Check the relevant logs, management/service health or monitoring after the change. If the fault returns, do not repeat increasingly destructive fixes; preserve the new evidence and escalate.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

9. **Document and close or hand off.** Record before/after state, exact actions, timestamps, approvals, commands/portal paths used, verification result, rollback state and any follow-up owner.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

## Approved remediation principles

- contain through approved Security Operations controls
- do not delete/quarantine/reimage/reconnect or change credentials solely for evidence collection unless the incident lead directs it
- separate containment, eradication and recovery decisions and record each authorization

## Rollback and recovery

- Containment changes are released only by Security Operations/incident command after risk is mitigated.
- Do not reconnect, restore deleted evidence or undo security controls merely to return quickly to the prior state.
- If an action unexpectedly expands impact, notify the incident lead immediately and preserve the action history.

## Verification checklist

- [ ] Exact user/device/service/resource and scope were verified.
- [ ] Required authorization and support-tier boundaries were satisfied.
- [ ] Before-state evidence was captured.
- [ ] Diagnostics identified or narrowed the failing dependency before material changes.
- [ ] Only supported, least-disruptive actions were used.
- [ ] Security Operations confirms the required containment/remediation state
- [ ] evidence remains available and attributable
- [ ] reconnection/closure is explicitly authorized
- [ ] Security, encryption, management, retention and access controls remain in the intended state.
- [ ] Rollback state and escalation evidence are documented.

## Escalation package

- Escalate to Security Operations or Incident Response with the exact user or service impact, timestamps and timezone, affected assets, screenshots or error text, diagnostic results, logs, recent changes, remediation attempted, rollback status and a clear statement of what remains broken.
- Escalate to **Security Operations or Incident Response** when the issue is outside the assigned tier, requires an unapproved privileged/destructive/production change, affects multiple users/sites/services, or remains unresolved after the targeted diagnostics.
- Include exact scope, timestamps/timezone, before/after evidence, relevant logs/error codes, commands or portal paths used, change/approval IDs, attempted remediation, rollback state and the failed verification criterion.

## Documentation assurance

This procedure has passed the ShiftStart documentation/technical-content quality gate. Production operational verification remains subject to live validation on the organization's actual platform, permissions, versions and change controls, plus technical-owner sign-off where required.
