---
title: Triage an office or site-wide outage
slug: triage-an-office-or-site-wide-outage
description: Enterprise runbook to triage an office or site-wide outage without skipping evidence, verification, rollback
  or escalation requirements.
content_type: procedure
category: Service Desk & ITSM
service: Service Desk & ITSM
severity: critical
support_tier: L1-L3
owner_team: Service Desk Manager or Incident Management
platforms:
- ITSM
risk_level: critical
estimated_time: 15-45 minutes
tags:
- an
- l1-l3
- office
- or
- outage
- service-desk-and-itsm
- site
- triage
- wide
error_codes: []
tldr: For triage an office or site-wide outage, verify scope, capture before-state, use targeted read-only diagnostics to
  prove the failing dependency, apply the smallest supported correction, verify end-to-end, and escalate before destructive
  or security-weakening changes.
related_symptoms:
- an-office-or-site-wide-outage
- support-request-requires-triage
- multiple-users-or-services-may-be-affected
symptom_weights:
  an-office-or-site-wide-outage: 10
  support-request-requires-triage: 3
  multiple-users-or-services-may-be-affected: 3
related_causes: []
related_commands: []
next_steps: []
escalation: Escalate to Service Desk Manager or Incident Management with scope, timestamps, evidence, actions, approvals,
  rollback state and failed verification criteria when the runbook reaches a stop condition or requires authority outside
  L1-L3.
last_reviewed: '2026-08-10'
review_cycle_days: 90
required_role: technician
approval_required: Follow the organization's ITSM authorization, identity-verification, escalation and communication policy
  for the requested service action.
content_status: under_review
generated_baseline: false
reviewed_by: ''
last_tested: ''
tested_platforms: []
source_references:
- https://csrc.nist.gov/pubs/sp/800/61/r3/final
- Local ITSM policy, SLA matrix, escalation matrix and change-management standard
change_record: 'Full-catalogue documentation remediation: replaced generic baseline flow with risk-aware, procedure-specific
  diagnostics, safety controls, remediation, rollback, verification and escalation guidance.'
quality_gate: passed
documentation_review: passed
documentation_reviewed_on: '2026-08-10'
live_validation_required: true
live_validation_note: Technical-owner live validation and environment-specific sign-off remain required; no live-test evidence
  is fabricated by this documentation pass.
permalink: /procedures/triage-an-office-or-site-wide-outage/
layout: article
risk_model: impact-v1
risk_basis: critical risk under the repository impact model; verification priority P0.
verification_priority: P0
verification_state: documentation_verified_pending_live_validation
---
## Purpose and scope

Enterprise runbook to triage an office or site-wide outage without skipping evidence, verification, rollback or escalation requirements.

Use this runbook for service-management work with accurate prioritisation, secure identity handling, complete evidence and accountable handoff. It is a support procedure, not authority to bypass change management, security policy, privacy/records obligations or the owning team's operational controls.

## Safety, authorisation and stop conditions

**Approval requirement:** Follow the organization's ITSM authorization, identity-verification, escalation and communication policy for the requested service action.

- Verify the exact user, device, service, tenant/site or resource before making changes; use immutable identifiers where available.
- Work within the assigned support tier and use named administrative accounts or approved privileged-access elevation.
- Capture the current state before any change so the action and rollback can be reconstructed.
- Do not request or record passwords, MFA codes, recovery secrets, private keys, access tokens or other credentials in the ticket.
- Prefer read-only and reversible diagnostics before reset, reinstall, profile removal, service restart or configuration changes.
- Stop if the issue becomes security-sensitive, data-destructive, production-wide, physically unsafe or outside your authority.

## Evidence to capture before changes

- requester/caller identity and contact method
- business service, impact, urgency and scope
- timestamps, SLA target and ownership
- troubleshooting/actions already completed
- linked incident/change/problem/vendor/security records

## Diagnostic path

- classify impact and urgency from observable business effect rather than job title alone
- identify security, major-incident, change-related and vendor dependencies early
- keep factual notes separated from assumptions
- use approved secure channels for remote support and sensitive information

### Read-only or low-risk diagnostic commands

Use the owning platform's read-only health, audit, log or inventory views first. Do not introduce a configuration change merely to gather a baseline.

## Procedure

1. **Confirm scope and capture the exact symptom.** Identify the affected user/device/service and reproduce **Triage an office or site-wide outage** only when reproduction is safe and non-destructive. Record exact error text, time and scope.

   **Expected result:** Requester, target asset/service, scope, authority and business impact are unambiguously identified and recorded before any material change.

2. **Capture before-state.** Record the relevant configuration, version, management/security state and recent changes before modifying anything.

   **Expected result:** A timestamped before-state is saved with the configuration, membership, health or data evidence needed to compare and, where possible, roll back.

3. **Run the targeted diagnostic path.** Use the scenario-specific checks below to identify the first failing dependency; compare a known-good path when available.

   **Expected result:** Evidence narrows the fault to a specific layer, dependency, policy, component or control before remediation is attempted.

4. **Prove the fault domain.** Do not change multiple layers at once. Decide whether the confirmed cause is local configuration, hardware, identity, network, service, policy or upstream infrastructure.

   **Expected result:** Evidence narrows the fault to a specific layer, dependency, policy, component or control before remediation is attempted.

5. **Apply the smallest supported correction.** Use the owning platform's supported repair/configuration path for the proven cause and keep security/management controls enabled.

   **Expected result:** The smallest supported correction that addresses the proven cause is applied, with no unnecessary destructive or security-weakening side effect.

6. **Use a secondary action only when justified.** If the first correction fails, collect the new evidence and use the next documented supported action. Escalate rather than progressing to reset/reinstall/destructive changes without justification.

   **Expected result:** A second action is taken only when new evidence justifies it; otherwise the case is escalated rather than progressing to destructive trial-and-error.

7. **Verify the result.** Repeat the original business test using the normal user path and confirm: The exact task addressed by **Triage an office or site-wide outage** succeeds end-to-end, the affected service remains stable, and no security, data-integrity or management control has been weakened.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

8. **Monitor for recurrence.** Check the relevant logs, management/service health or monitoring after the change. If the fault returns, do not repeat increasingly destructive fixes; preserve the new evidence and escalate.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

9. **Document and close or hand off.** Record before/after state, exact actions, timestamps, approvals, commands/portal paths used, verification result, rollback state and any follow-up owner.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

## Approved remediation principles

- route to the correct resolver group with sufficient evidence
- communicate status at the agreed cadence
- do not close until restoration or request fulfillment is verified by evidence/user/business criteria

## Rollback and recovery

- If the change causes new impact, stop further changes, restore the captured before-state using the supported rollback path, and record the rollback time/result.
- Do not 'roll back' by weakening authentication, encryption, endpoint protection, certificate validation, firewall/NAC or compliance controls.
- If rollback is impossible or would destroy evidence/data, leave the system in the safest stable state and escalate with the captured evidence.

## Verification checklist

- [ ] Exact user/device/service/resource and scope were verified.
- [ ] Required authorization and support-tier boundaries were satisfied.
- [ ] Before-state evidence was captured.
- [ ] Diagnostics identified or narrowed the failing dependency before material changes.
- [ ] Only supported, least-disruptive actions were used.
- [ ] ownership and next action are unambiguous
- [ ] SLA/escalation obligations are met
- [ ] ticket history can be reconstructed by another technician
- [ ] Security, encryption, management, retention and access controls remain in the intended state.
- [ ] Rollback state and escalation evidence are documented.

## Escalation package

- Escalate to Service Desk Manager or Incident Management with the exact user or service impact, timestamps and timezone, affected assets, screenshots or error text, diagnostic results, logs, recent changes, remediation attempted, rollback status and a clear statement of what remains broken.
- Escalate to **Service Desk Manager or Incident Management** when the issue is outside the assigned tier, requires an unapproved privileged/destructive/production change, affects multiple users/sites/services, or remains unresolved after the targeted diagnostics.
- Include exact scope, timestamps/timezone, before/after evidence, relevant logs/error codes, commands or portal paths used, change/approval IDs, attempted remediation, rollback state and the failed verification criterion.

## Documentation assurance

This procedure has passed the ShiftStart documentation/technical-content quality gate. Production operational verification remains subject to live validation on the organization's actual platform, permissions, versions and change controls, plus technical-owner sign-off where required.
