---
title: Collect security incident evidence
slug: collect-security-incident-evidence
description: Enterprise runbook to collect security incident evidence without skipping evidence, verification, rollback or
  escalation requirements.
content_type: procedure
category: Security & Compliance
service: Security & Compliance
severity: high
support_tier: L1-L3
owner_team: Security Operations or Incident Response
platforms:
- EDR
- SIEM
- Identity
- Email security
risk_level: high
estimated_time: 15-45 minutes
tags:
- collect
- evidence
- incident
- l1-l3
- security
- security-and-compliance
error_codes: []
tldr: For collect security incident evidence, collect only authorized evidence with minimal source alteration, record provenance
  and integrity, store it in restricted evidence storage, and hand it to the incident owner without mixing collection with
  cleanup.
related_symptoms:
- need-to-collect-security-incident-evidence
- a-security-or-compliance-concern-is-reported
symptom_weights:
  need-to-collect-security-incident-evidence: 10
  a-security-or-compliance-concern-is-reported: 3
related_causes: []
related_commands: []
next_steps: []
escalation: Escalate to Security Operations or Incident Response with scope, timestamps, evidence, actions, approvals, rollback
  state and failed verification criteria when the runbook reaches a stop condition or requires authority outside L1-L3.
last_reviewed: '2026-08-10'
review_cycle_days: 90
required_role: technician
approval_required: Operate only under the incident/case owner or Security Operations process. Destructive or containment actions
  require the authority defined in the incident-response plan.
content_status: under_review
generated_baseline: false
reviewed_by: ''
last_tested: ''
tested_platforms: []
source_references:
- https://csrc.nist.gov/pubs/sp/800/61/r3/final
- https://csrc.nist.gov/pubs/sp/800/86/final
- https://learn.microsoft.com/en-us/defender-endpoint/respond-machine-alerts
change_record: 'Full-catalogue documentation remediation: replaced generic baseline flow with risk-aware, procedure-specific
  diagnostics, safety controls, remediation, rollback, verification and escalation guidance.'
quality_gate: passed
documentation_review: passed
documentation_reviewed_on: '2026-08-10'
live_validation_required: true
live_validation_note: Technical-owner live validation and environment-specific sign-off remain required; no live-test evidence
  is fabricated by this documentation pass.
permalink: /procedures/collect-security-incident-evidence/
layout: article
risk_model: impact-v1
risk_basis: high risk under the repository impact model; verification priority P1.
verification_priority: P1
verification_state: documentation_verified_pending_live_validation
---
## Purpose and scope
Use this procedure to **preserve and collect digital evidence for a cybersecurity incident** in a managed enterprise environment.

The objective is to collect relevant information while minimising unnecessary changes to source systems, preserving provenance and integrity, and maintaining a documented handling trail and chain of custody where required. This is an operational support procedure, not legal advice and not a substitute for organisation-specific forensic, privacy, labour, legal, regulatory or law-enforcement requirements.

## Before you start
- Confirm the incident/case/ticket number, Incident Response or Security Operations owner, approved scope and your authority to collect evidence.
- Record the collector's name/account, source system/device/account, date/time and timezone.
- Determine whether Legal, Privacy, HR, Compliance or law enforcement has imposed special preservation, retention or chain-of-custody requirements.
- Use organisation-approved evidence-collection tools and destinations.
- Minimise interaction with the source system beyond what is required for authorised collection.
- **Do not ask the user to reproduce the suspicious activity.**
- Do not open suspicious attachments/links, execute malware, reconnect an isolated host, delete/quarantine artefacts, clear logs, reboot/shut down a source, run cleanup tools or change credentials solely as part of evidence collection unless the Incident Response plan explicitly directs that action.

## Evidence priorities
Collection order depends on the incident and Security/IR direction. Time-sensitive or volatile evidence can disappear quickly, so capture it first **when authorised and technically appropriate**. Examples include:
- active processes and services;
- logged-on users and sessions;
- active network connections;
- memory using an approved acquisition tool;
- EDR/SIEM alerts and live-response artefacts;
- volatile cloud/session information.

Then collect relevant less-volatile sources such as:
- operating-system, application and security logs;
- EDR telemetry;
- identity/sign-in/audit logs;
- email headers and message-trace data;
- firewall, proxy, DNS, VPN and network logs;
- suspicious files, scripts, persistence artefacts and configuration;
- cloud audit/activity logs;
- approved disk/image exports where required.

Do not collect unrelated personal or business data merely because it is accessible.

## Procedure
1. **Establish the evidence record.** Record the case ID, incident owner, collector, source, requested evidence, approved collection scope, date/time/timezone and destination repository.

   **Expected result:** Establish the evidence record produces a recorded, observable result for **Collect security incident evidence** that is consistent with the approved scope and can be compared with the before-state.

2. **Preserve the source.** Follow IR direction for containment and preservation. Avoid actions that unnecessarily change timestamps, logs, files, memory, sessions or other source state.

   <div class="expected"><strong>Expected result:</strong> The source is identified and its state is preserved to the greatest practical extent consistent with containment and safety.</div>

3. **Capture time-sensitive evidence first where required.** Use approved tools for volatile data such as live processes, active connections, sessions or memory only if this falls within your role and the incident plan.

   <div class="expected"><strong>Expected result:</strong> Relevant volatile evidence is captured before it naturally changes or is lost, without improvising unapproved forensic actions.</div>

4. **Export authoritative platform evidence.** Use supported export/download functions from EDR, SIEM, identity, email, endpoint and network systems. Preserve the original timestamps and available metadata.

   **Expected result:** Export authoritative platform evidence produces a recorded, observable result for **Collect security incident evidence** that is consistent with the approved scope and can be compared with the before-state.

5. **Collect suspicious artefacts without executing them.** Where permitted, acquire files or other artefacts using an approved method. Do not double-click, preview, run or modify suspicious content on a normal workstation.

   **Expected result:** Collect suspicious artefacts without executing them produces a recorded, observable result for **Collect security incident evidence** that is consistent with the approved scope and can be compared with the before-state.

6. **Record provenance for every evidence item.** At minimum, capture:
   - case/incident ID;
   - evidence item identifier;
   - source system/account/device and source path/query;
   - collection method/tool and relevant version where required;
   - collector;
   - collection date/time/timezone;
   - destination;
   - any transformation/export performed; and
   - who received or subsequently handled the item where chain-of-custody is required.

   **Expected result:** Record provenance for every evidence item produces a recorded, observable result for **Collect security incident evidence** that is consistent with the approved scope and can be compared with the before-state.

7. **Record integrity information where supported.** For files, images or exports that should remain unchanged, calculate and record a cryptographic hash such as SHA-256 after acquisition using the approved workstation/tool.

{% capture hash_file %}
Get-FileHash -Algorithm SHA256 -Path 'C:\Path\To\EvidenceFile.ext'
{% endcapture %}
{% include command.html shell="powershell" label="Calculate SHA-256 for an authorised evidence file" command=hash_file %}

   <div class="expected"><strong>Expected result:</strong> The evidence record contains sufficient provenance and integrity information to identify the collected item and detect later unintended change where hashing is applicable.</div>

8. **Store evidence securely.** Move/copy the collected evidence to the organisation's approved restricted evidence repository. Apply the required access controls and retention classification. Do not use personal cloud storage, ordinary shared folders or removable media unless explicitly authorised.

   **Expected result:** Store evidence securely produces a recorded, observable result for **Collect security incident evidence** that is consistent with the approved scope and can be compared with the before-state.

9. **Verify the collection.** Confirm required files/exports are present, readable by authorised investigators and associated with the correct case. Where hashes were recorded, verify them after transfer if the workflow requires it.

   **Expected result:** The original user or business task for **Collect security incident evidence** succeeds end-to-end, required controls remain enabled, and the observed result is recorded.

10. **Hand off to the incident owner.** Tell Security/IR what was collected, what could not be collected, any source changes that occurred, and any preservation risks or collection errors. Do not start eradication or return systems to service unless that action is separately authorised.

   **Expected result:** The ticket or handoff contains scope, timestamps, evidence, approvals, actions, verification, rollback state and the responsible next owner.

## Stop and escalate conditions
Stop collection and escalate when:
- the requested evidence is outside the approved incident scope;
- legal hold, regulatory, privacy or law-enforcement requirements are unclear;
- the source may be physically unsafe, destructive activity is ongoing or collection could materially worsen the incident;
- ransomware, privileged-account compromise, suspected data exfiltration or other high-impact compromise is involved and the IR owner has not directed collection;
- the only available collection method would alter or destroy important evidence;
- an evidence repository, acquisition tool or required forensic capability is unavailable;
- collection requires credentials/privileges you are not authorised to use; or
- you discover evidence unrelated to the authorised scope that may require separate handling.

## Evidence required for handoff
Provide Security Operations/Incident Response with:
- incident/case ID and business impact;
- source assets/accounts and identifiers;
- collection start/end timestamps and timezone;
- collector identity;
- evidence inventory;
- source locations and collection methods/tools;
- cryptographic hashes where applicable;
- secure repository/destination;
- any gaps, errors or source alterations;
- containment state; and
- any Legal/Privacy/Compliance constraints communicated to you.

## Verification checklist
- [ ] Incident scope and collection authority were confirmed.
- [ ] The user was not asked to reproduce suspicious activity.
- [ ] Source alteration was minimised and any unavoidable change was documented.
- [ ] Volatile/time-sensitive evidence was considered and collected only when authorised.
- [ ] Relevant platform logs/telemetry/artefacts were collected from approved sources.
- [ ] Provenance and handling information were recorded.
- [ ] Integrity hashes were recorded where applicable.
- [ ] Evidence was stored in the approved restricted repository.
- [ ] Security/IR received the evidence inventory and any collection gaps.
- [ ] No cleanup, eradication or return-to-service action was performed merely as part of evidence collection.

## Documentation control addendum

For **Collect security incident evidence**, confirm incident/case ownership and authorization before collection. Security Operations approval and case scope govern what may be collected, where it may be stored and who may receive it.

## Documentation assurance

This procedure has passed the ShiftStart documentation/technical-content quality gate. Production operational verification remains subject to live validation on the organization's actual platform, permissions, versions and change controls, plus technical-owner sign-off where required.
