---
title: Update BIOS or device firmware safely
slug: update-bios-or-device-firmware-safely
description: Enterprise runbook to update bios or device firmware safely without skipping evidence, verification, rollback
  or escalation requirements.
content_type: procedure
category: Windows Endpoints
service: Windows Endpoints
severity: medium
support_tier: L1-L2
owner_team: Endpoint Engineering
platforms:
- Windows 10
- Windows 11
risk_level: medium
estimated_time: 15-45 minutes
tags:
- bios
- device
- firmware
- l1-l2
- or
- safely
- update
- windows-endpoints
error_codes: []
tldr: For update bios or device firmware safely, verify exact model and signed OEM package, confirm power and encryption-recovery
  prerequisites, capture rollback options, apply without interruption, and verify firmware plus device health after reboot.
related_symptoms:
- need-to-update-bios-or-device-firmware-safely
- windows-device-is-not-working-correctly
- a-windows-error-or-performance-issue-is-reported
symptom_weights:
  need-to-update-bios-or-device-firmware-safely: 10
  windows-device-is-not-working-correctly: 3
  a-windows-error-or-performance-issue-is-reported: 3
related_causes: []
related_commands: []
next_steps: []
escalation: Escalate to Endpoint Engineering with scope, timestamps, evidence, actions, approvals, rollback state and failed
  verification criteria when the runbook reaches a stop condition or requires authority outside L1-L2.
last_reviewed: '2026-08-10'
review_cycle_days: 90
required_role: technician
approval_required: Change approval is required for production/corporate firmware updates where policy requires it. Use only
  the exact OEM-supported package for the verified model and power state.
content_status: under_review
generated_baseline: false
reviewed_by: ''
last_tested: ''
tested_platforms: []
source_references:
- https://learn.microsoft.com/en-us/troubleshoot/windows-client/welcome-windows-client
- https://learn.microsoft.com/en-us/windows/client-management/
change_record: 'Full-catalogue documentation remediation: replaced generic baseline flow with risk-aware, procedure-specific
  diagnostics, safety controls, remediation, rollback, verification and escalation guidance.'
quality_gate: passed
documentation_review: passed
documentation_reviewed_on: '2026-08-10'
live_validation_required: true
live_validation_note: Technical-owner live validation and environment-specific sign-off remain required; no live-test evidence
  is fabricated by this documentation pass.
permalink: /procedures/update-bios-or-device-firmware-safely/
layout: article
risk_model: impact-v1
risk_basis: medium risk under the repository impact model; verification priority P2.
verification_priority: P2
verification_state: documentation_verified_pending_live_validation
---
## Purpose and scope

Enterprise runbook to update bios or device firmware safely without skipping evidence, verification, rollback or escalation requirements.

Use this runbook for managed Windows endpoints using supported diagnostic and recovery paths while preserving user data, encryption and endpoint-management controls. It is a support procedure, not authority to bypass change management, security policy, privacy/records obligations or the owning team's operational controls.

## Safety, authorisation and stop conditions

**Approval requirement:** Change approval is required for production/corporate firmware updates where policy requires it. Use only the exact OEM-supported package for the verified model and power state.

- Verify the exact user, device, service, tenant/site or resource before making changes; use immutable identifiers where available.
- Work within the assigned support tier and use named administrative accounts or approved privileged-access elevation.
- Capture the current state before any change so the action and rollback can be reconstructed.
- Do not request or record passwords, MFA codes, recovery secrets, private keys, access tokens or other credentials in the ticket.
- Use only the exact OEM-supported and signed firmware/BIOS package for the verified model and hardware revision.
- Confirm stable power and encryption-recovery readiness before flashing; never interrupt a firmware update once the OEM process begins.
- Stop for battery/power instability, model mismatch, unsupported downgrade, failed signature/integrity checks or missing recovery information.

## Evidence to capture before changes

- device name, asset tag and Windows build
- affected user and exact error
- management, encryption and security state
- recent update/driver/application/policy change
- relevant Event Viewer/Reliability Monitor/device diagnostic evidence

## Diagnostic path

- separate hardware, OS, user-profile, application, driver and management-policy causes
- use supported Windows diagnostics and event logs before reset/reimage
- preserve unsynced/local data and BitLocker recovery information before recovery actions
- do not disable Defender, UAC, Secure Boot or encryption as a workaround
- Verify exact manufacturer, model, current firmware/BIOS version, target version and applicable release notes.
- Confirm stable AC power and any encryption/BitLocker preparation explicitly required by the OEM before flashing.

### Read-only or low-risk diagnostic commands

**PowerShell — supported Windows baseline**

```text
Get-ComputerInfo | Select-Object WindowsProductName,WindowsVersion,OsBuildNumber
Get-WinEvent -LogName System -MaxEvents 50 | Where-Object LevelDisplayName -in 'Critical','Error'
```

Replace placeholders with the approved target. Commands are diagnostic examples; use only where the platform, role and environment support them.

## Procedure

1. **Identify exact hardware and target firmware.** Record manufacturer, model, serial/asset tag, current version, target version, release notes and the approved source package.

   **Expected result:** Manufacturer, model, current firmware, target firmware and the approved OEM package match the exact device.

2. **Confirm prerequisites.** Check AC power, battery threshold, dock/peripheral requirements, encryption/recovery-key readiness and any OEM instructions about BitLocker/FileVault/Secure Boot.

   **Expected result:** Power, backup/recovery, encryption and vendor prerequisites are satisfied, with no unresolved condition that makes the change unsafe.

3. **Capture rollback/recovery options.** Determine whether rollback is supported and how to recover from a failed flash. If rollback is unsupported, record the increased risk and approval.

   **Expected result:** A viable rollback or recovery path is documented; where rollback is impossible, the irreversibility and approval are explicitly recorded.

4. **Run pre-update diagnostics.** Confirm the symptom or security requirement actually justifies the firmware change and that the device is otherwise stable.

   **Expected result:** Evidence narrows the fault to a specific layer, dependency, policy, component or control before remediation is attempted.

5. **Apply the OEM-supported update.** Launch the signed package/tool, verify model/version one final time and do not interrupt power or force a restart during flashing.

   **Expected result:** The smallest supported correction that addresses the proven cause is applied, with no unnecessary destructive or security-weakening side effect.

6. **Validate after reboot.** Confirm firmware version, hardware health, boot, encryption, management and the original device function.

   **Expected result:** The device boots normally and firmware version, hardware health, encryption, management state and the original function all validate.

7. **Verify the result.** Repeat the original business test using the normal user path and confirm: The exact task addressed by **Update BIOS or device firmware safely** succeeds end-to-end, the affected service remains stable, and no security, data-integrity or management control has been weakened.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

8. **Monitor for recurrence.** Check the relevant logs, management/service health or monitoring after the change. If the fault returns, do not repeat increasingly destructive fixes; preserve the new evidence and escalate.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

9. **Document and close or hand off.** Record before/after state, exact actions, timestamps, approvals, commands/portal paths used, verification result, rollback state and any follow-up owner.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

## Approved remediation principles

- Use only the exact OEM-signed package for the verified model. Confirm power, prerequisite BIOS settings and encryption recovery readiness, then do not interrupt the flash; verify version and device health afterward.
- apply the smallest supported repair first
- use approved driver/application/Windows recovery sources
- treat reimage, firmware and encryption changes as separately authorized high-impact actions

## Rollback and recovery

- Use firmware rollback only when the OEM explicitly supports it for the exact model/version.
- If the device will not boot after flashing, use the OEM recovery path or hardware escalation; do not repeatedly flash unrelated versions.

## Verification checklist

- [ ] Exact user/device/service/resource and scope were verified.
- [ ] Required authorization and support-tier boundaries were satisfied.
- [ ] Before-state evidence was captured.
- [ ] Diagnostics identified or narrowed the failing dependency before material changes.
- [ ] Only supported, least-disruptive actions were used.
- [ ] the original Windows task succeeds
- [ ] device remains encrypted, protected and managed
- [ ] no new critical event or compliance failure is introduced
- [ ] Security, encryption, management, retention and access controls remain in the intended state.
- [ ] Rollback state and escalation evidence are documented.

## Escalation package

- Escalate to Endpoint Engineering with the exact user or service impact, timestamps and timezone, affected assets, screenshots or error text, diagnostic results, logs, recent changes, remediation attempted, rollback status and a clear statement of what remains broken.
- Escalate to **Endpoint Engineering** when the issue is outside the assigned tier, requires an unapproved privileged/destructive/production change, affects multiple users/sites/services, or remains unresolved after the targeted diagnostics.
- Include exact scope, timestamps/timezone, before/after evidence, relevant logs/error codes, commands or portal paths used, change/approval IDs, attempted remediation, rollback state and the failed verification criterion.

## Documentation assurance

This procedure has passed the ShiftStart documentation/technical-content quality gate. Production operational verification remains subject to live validation on the organization's actual platform, permissions, versions and change controls, plus technical-owner sign-off where required.
