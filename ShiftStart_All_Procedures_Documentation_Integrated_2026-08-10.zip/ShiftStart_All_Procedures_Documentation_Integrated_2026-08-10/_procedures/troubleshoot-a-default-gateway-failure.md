---
title: Troubleshoot a default gateway failure
slug: troubleshoot-a-default-gateway-failure
description: Enterprise runbook to troubleshoot a default gateway failure without skipping evidence, verification, rollback
  or escalation requirements.
content_type: procedure
category: Network & Connectivity
service: Network & Connectivity
severity: high
support_tier: L1-L2
owner_team: Network Operations
platforms:
- LAN
- Wi-Fi
- VPN
- DNS
- DHCP
risk_level: high
estimated_time: 15-45 minutes
tags:
- a
- default
- failure
- gateway
- l1-l2
- network-and-connectivity
- troubleshoot
error_codes: []
tldr: For troubleshoot a default gateway failure, establish impact and change/incident ownership, capture before-state, prove
  the failing layer, use the lowest-blast-radius action with rollback ready, and verify dependencies plus a real business
  transaction.
related_symptoms:
- a-default-gateway-failure
- network-or-internet-access-is-unavailable
- connection-is-slow-or-intermittent
symptom_weights:
  a-default-gateway-failure: 10
  network-or-internet-access-is-unavailable: 3
  connection-is-slow-or-intermittent: 3
related_causes: []
related_commands: []
next_steps: []
escalation: Escalate to Network Operations with scope, timestamps, evidence, actions, approvals, rollback state and failed
  verification criteria when the runbook reaches a stop condition or requires authority outside L1-L2.
last_reviewed: '2026-08-10'
review_cycle_days: 90
required_role: technician
approval_required: Follow the change/major-incident process for any production-impacting configuration, restart, failover,
  routing, firewall, VLAN, gateway or capacity action.
content_status: under_review
generated_baseline: false
reviewed_by: ''
last_tested: ''
tested_platforms: []
source_references:
- https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/networking-overview
- https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting
change_record: 'Full-catalogue documentation remediation: replaced generic baseline flow with risk-aware, procedure-specific
  diagnostics, safety controls, remediation, rollback, verification and escalation guidance.'
quality_gate: passed
documentation_review: passed
documentation_reviewed_on: '2026-08-10'
live_validation_required: true
live_validation_note: Technical-owner live validation and environment-specific sign-off remain required; no live-test evidence
  is fabricated by this documentation pass.
permalink: /procedures/troubleshoot-a-default-gateway-failure/
layout: article
risk_model: impact-v1
risk_basis: high risk under the repository impact model; verification priority P1.
verification_priority: P1
verification_state: documentation_verified_pending_live_validation
---
## Purpose and scope

Enterprise runbook to troubleshoot a default gateway failure without skipping evidence, verification, rollback or escalation requirements.

Use this runbook for endpoint and site connectivity using layered diagnostics without weakening firewalls, NAC, 802.1X, proxy or zero-trust controls. It is a support procedure, not authority to bypass change management, security policy, privacy/records obligations or the owning team's operational controls.

## Safety, authorisation and stop conditions

**Approval requirement:** Follow the change/major-incident process for any production-impacting configuration, restart, failover, routing, firewall, VLAN, gateway or capacity action.

- Verify the exact user, device, service, tenant/site or resource before making changes; use immutable identifiers where available.
- Work within the assigned support tier and use named administrative accounts or approved privileged-access elevation.
- Capture the current state before any change so the action and rollback can be reconstructed.
- Do not request or record passwords, MFA codes, recovery secrets, private keys, access tokens or other credentials in the ticket.
- Assess dependency, redundancy, active users/transactions and blast radius before production-impacting changes.
- Use the change or major-incident process for restart, failover, network/security-policy or capacity actions.
- Preserve diagnostics needed for root cause before resetting/restarting an infrastructure component.

## Evidence to capture before changes

- affected user/device/site and network medium
- IP configuration, gateway, DNS and adapter state
- exact destination/service/port and timestamps
- scope across endpoints/sites
- recent switch, VLAN, DHCP, DNS, VPN, firewall or policy changes

## Diagnostic path

- Check adapter/link, address, mask, gateway, DNS, lease, route and authentication in order. Compare another device on the same port, SSID or VLAN.
- work from link/adapter to IP/DHCP, gateway, DNS, route/security path and finally application port
- compare working and failing endpoints on the same network
- use TCP/application tests where ICMP behavior is inconclusive
- do not disable firewall, certificate validation, NAC or web filtering as an unapproved test

### Read-only or low-risk diagnostic commands

**Windows — addressing and adapter state**

```text
ipconfig /all
Get-NetAdapter | Sort-Object Status,Name | Format-Table -Auto
```

**Windows — DNS/TCP test**

```text
Resolve-DnsName <fqdn>
Test-NetConnection <host> -Port <port>
```

Replace placeholders with the approved target. Commands are diagnostic examples; use only where the platform, role and environment support them.

## Procedure

1. **Establish impact and change/incident owner.** Confirm affected service, users/sites, dependencies, redundancy/failover, business priority and the authorized change or major-incident record.

   **Expected result:** Requester, target asset/service, scope, authority and business impact are unambiguously identified and recorded before any material change.

2. **Capture stable before-state.** Record health, metrics, logs, recent changes, configuration snapshots/exports and current routing/service state as applicable.

   **Expected result:** A timestamped before-state is saved with the configuration, membership, health or data evidence needed to compare and, where possible, roll back.

3. **Diagnose the first failing layer.** Check adapter/link, address, mask, gateway, DNS, lease, route and authentication in order. Compare another device on the same port, SSID or VLAN.

   **Expected result:** Evidence narrows the fault to a specific layer, dependency, policy, component or control before remediation is attempted.

4. **Choose the lowest-blast-radius action.** Renew or correct local configuration only after capturing it; reconnect with approved credentials/profile. Escalate port, scope, VLAN, DNS or infrastructure evidence when multiple devices are affected.

   **Expected result:** Choose the lowest-blast-radius action produces a recorded, observable result for **Troubleshoot a default gateway failure** that is consistent with the approved scope and can be compared with the before-state.

5. **Execute with rollback/failover ready.** Announce the action to the incident/change owner, make one controlled change, record the exact timestamp and stop if impact expands.

   **Expected result:** One controlled, approved change is applied at the proven fault domain while rollback/failover remains available and impact does not expand.

6. **Validate dependencies and service.** Check component health, replication/routes/listeners/metrics as applicable and run a real business transaction from the correct client/location.

   **Expected result:** Validate dependencies and service produces a recorded, observable result for **Troubleshoot a default gateway failure** that is consistent with the approved scope and can be compared with the before-state.

7. **Verify the result.** Repeat the original business test using the normal user path and confirm: The device receives the correct network configuration and reaches required destinations.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

8. **Monitor for recurrence.** Check the relevant logs, management/service health or monitoring after the change. If the fault returns, do not repeat increasingly destructive fixes; preserve the new evidence and escalate.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

9. **Document and close or hand off.** Record before/after state, exact actions, timestamps, approvals, commands/portal paths used, verification result, rollback state and any follow-up owner.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

## Approved remediation principles

- Renew or correct local configuration only after capturing it; reconnect with approved credentials/profile. Escalate port, scope, VLAN, DNS or infrastructure evidence when multiple devices are affected.
- correct the lowest layer that is proven faulty
- treat VLAN, switch-port, firewall, routing, DHCP/DNS service and VPN gateway changes as controlled network changes
- avoid release/renew, adapter reset or remote-route changes when they can strand the remote session unless an alternate path exists

## Rollback and recovery

- Use the pre-defined configuration/failover rollback if service or blast radius worsens.
- If rollback risks wider outage or data inconsistency, stop and let the change/incident owner choose the recovery path.

## Verification checklist

- [ ] Exact user/device/service/resource and scope were verified.
- [ ] Required authorization and support-tier boundaries were satisfied.
- [ ] Before-state evidence was captured.
- [ ] Diagnostics identified or narrowed the failing dependency before material changes.
- [ ] Only supported, least-disruptive actions were used.
- [ ] The device receives the correct network configuration and reaches required destinations.
- [ ] addressing, DNS and route are correct
- [ ] required destination/port is reachable
- [ ] the business application works without a security-control bypass
- [ ] Security, encryption, management, retention and access controls remain in the intended state.
- [ ] Rollback state and escalation evidence are documented.

## Escalation package

- Escalate to Network Operations with the exact user or service impact, timestamps and timezone, affected assets, screenshots or error text, diagnostic results, logs, recent changes, remediation attempted, rollback status and a clear statement of what remains broken.
- Escalate to **Network Operations** when the issue is outside the assigned tier, requires an unapproved privileged/destructive/production change, affects multiple users/sites/services, or remains unresolved after the targeted diagnostics.
- Include exact scope, timestamps/timezone, before/after evidence, relevant logs/error codes, commands or portal paths used, change/approval IDs, attempted remediation, rollback state and the failed verification criterion.

## Documentation assurance

This procedure has passed the ShiftStart documentation/technical-content quality gate. Production operational verification remains subject to live validation on the organization's actual platform, permissions, versions and change controls, plus technical-owner sign-off where required.
