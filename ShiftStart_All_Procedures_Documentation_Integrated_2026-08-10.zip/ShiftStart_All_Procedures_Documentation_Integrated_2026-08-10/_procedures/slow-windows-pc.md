---
title: Resolve an unusually slow Windows PC
slug: slow-windows-pc
description: Identify CPU, memory, disk, startup, update and storage-pressure causes before applying a targeted change.
content_type: procedure
category: Windows Endpoints
service: Windows Endpoints
severity: medium
support_tier: L1
owner_team: Service Desk
platforms: []
risk_level: medium
estimated_time: 20-30 mins
tags:
- performance
- windows
- disk
- memory
error_codes:
- 100%
- disk
- Not
- responding
tldr: For resolve an unusually slow windows pc, verify scope, capture before-state, use targeted read-only diagnostics to
  prove the failing dependency, apply the smallest supported correction, verify end-to-end, and escalate before destructive
  or security-weakening changes.
related_symptoms:
- slow-computer
symptom_weights: {}
related_causes: []
related_commands: []
next_steps: []
escalation: Escalate to Service Desk with scope, timestamps, evidence, actions, approvals, rollback state and failed verification
  criteria when the runbook reaches a stop condition or requires authority outside L1.
last_reviewed: '2026-08-10'
review_cycle_days: 90
required_role: technician
approval_required: Use normal support authorization. Any admin, security-policy, data-destructive or production-impacting
  action requires the organization’s applicable approval/change process.
content_status: verified
generated_baseline: false
reviewed_by: ShiftStart technical review
last_tested: ''
tested_platforms: []
source_references:
- https://learn.microsoft.com/en-us/troubleshoot/windows-client/welcome-windows-client
- https://learn.microsoft.com/en-us/windows/client-management/
change_record: 'Full-catalogue documentation remediation: replaced generic baseline flow with risk-aware, procedure-specific
  diagnostics, safety controls, remediation, rollback, verification and escalation guidance.'
quality_gate: passed
documentation_review: passed
documentation_reviewed_on: '2026-08-10'
live_validation_required: true
live_validation_note: Technical-owner live validation and environment-specific sign-off remain required; no live-test evidence
  is fabricated by this documentation pass.
permalink: /procedures/slow-windows-pc/
layout: article
risk_model: impact-v1
risk_basis: medium risk under the repository impact model; verification priority P2.
verification_priority: P2
verification_state: documentation_verified_live_evidence_incomplete
---
## Purpose and scope

Identify CPU, memory, disk, startup, update and storage-pressure causes before applying a targeted change.

Use this runbook for managed Windows endpoints using supported diagnostic and recovery paths while preserving user data, encryption and endpoint-management controls. It is a support procedure, not authority to bypass change management, security policy, privacy/records obligations or the owning team's operational controls.

## Safety, authorisation and stop conditions

**Approval requirement:** Use normal support authorization. Any admin, security-policy, data-destructive or production-impacting action requires the organization’s applicable approval/change process.

- Verify the exact user, device, service, tenant/site or resource before making changes; use immutable identifiers where available.
- Work within the assigned support tier and use named administrative accounts or approved privileged-access elevation.
- Capture the current state before any change so the action and rollback can be reconstructed.
- Do not request or record passwords, MFA codes, recovery secrets, private keys, access tokens or other credentials in the ticket.
- Prefer read-only and reversible diagnostics before reset, reinstall, profile removal, service restart or configuration changes.
- Stop if the issue becomes security-sensitive, data-destructive, production-wide, physically unsafe or outside your authority.

## Evidence to capture before changes

- device name, asset tag and Windows build
- affected user and exact error
- management, encryption and security state
- recent update/driver/application/policy change
- relevant Event Viewer/Reliability Monitor/device diagnostic evidence

## Diagnostic path

- separate hardware, OS, user-profile, application, driver and management-policy causes
- use supported Windows diagnostics and event logs before reset/reimage
- preserve unsynced/local data and BitLocker recovery information before recovery actions
- do not disable Defender, UAC, Secure Boot or encryption as a workaround

### Read-only or low-risk diagnostic commands

**PowerShell — supported Windows baseline**

```text
Get-ComputerInfo | Select-Object WindowsProductName,WindowsVersion,OsBuildNumber
Get-WinEvent -LogName System -MaxEvents 50 | Where-Object LevelDisplayName -in 'Critical','Error'
```

Replace placeholders with the approved target. Commands are diagnostic examples; use only where the platform, role and environment support them.

## Procedure

1. **Confirm scope and capture the exact symptom.** Identify the affected user/device/service and reproduce **Resolve an unusually slow Windows PC** only when reproduction is safe and non-destructive. Record exact error text, time and scope.

   **Expected result:** Requester, target asset/service, scope, authority and business impact are unambiguously identified and recorded before any material change.

2. **Capture before-state.** Record the relevant configuration, version, management/security state and recent changes before modifying anything.

   **Expected result:** A timestamped before-state is saved with the configuration, membership, health or data evidence needed to compare and, where possible, roll back.

3. **Run the targeted diagnostic path.** Use the scenario-specific checks below to identify the first failing dependency; compare a known-good path when available.

   **Expected result:** Evidence narrows the fault to a specific layer, dependency, policy, component or control before remediation is attempted.

4. **Prove the fault domain.** Do not change multiple layers at once. Decide whether the confirmed cause is local configuration, hardware, identity, network, service, policy or upstream infrastructure.

   **Expected result:** Evidence narrows the fault to a specific layer, dependency, policy, component or control before remediation is attempted.

5. **Apply the smallest supported correction.** Use the owning platform's supported repair/configuration path for the proven cause and keep security/management controls enabled.

   **Expected result:** The smallest supported correction that addresses the proven cause is applied, with no unnecessary destructive or security-weakening side effect.

6. **Use a secondary action only when justified.** If the first correction fails, collect the new evidence and use the next documented supported action. Escalate rather than progressing to reset/reinstall/destructive changes without justification.

   **Expected result:** A second action is taken only when new evidence justifies it; otherwise the case is escalated rather than progressing to destructive trial-and-error.

7. **Verify the result.** Repeat the original business test using the normal user path and confirm: The exact task addressed by **Resolve an unusually slow Windows PC** succeeds end-to-end, the affected service remains stable, and no security, data-integrity or management control has been weakened.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

8. **Monitor for recurrence.** Check the relevant logs, management/service health or monitoring after the change. If the fault returns, do not repeat increasingly destructive fixes; preserve the new evidence and escalate.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

9. **Document and close or hand off.** Record before/after state, exact actions, timestamps, approvals, commands/portal paths used, verification result, rollback state and any follow-up owner.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

## Approved remediation principles

- apply the smallest supported repair first
- use approved driver/application/Windows recovery sources
- treat reimage, firmware and encryption changes as separately authorized high-impact actions

## Rollback and recovery

- If the change causes new impact, stop further changes, restore the captured before-state using the supported rollback path, and record the rollback time/result.
- Do not 'roll back' by weakening authentication, encryption, endpoint protection, certificate validation, firewall/NAC or compliance controls.
- If rollback is impossible or would destroy evidence/data, leave the system in the safest stable state and escalate with the captured evidence.

## Verification checklist

- [ ] Exact user/device/service/resource and scope were verified.
- [ ] Required authorization and support-tier boundaries were satisfied.
- [ ] Before-state evidence was captured.
- [ ] Diagnostics identified or narrowed the failing dependency before material changes.
- [ ] Only supported, least-disruptive actions were used.
- [ ] the original Windows task succeeds
- [ ] device remains encrypted, protected and managed
- [ ] no new critical event or compliance failure is introduced
- [ ] Security, encryption, management, retention and access controls remain in the intended state.
- [ ] Rollback state and escalation evidence are documented.

## Escalation package

- Escalate to Endpoint Engineering if storage health is degraded, malware is suspected, resource pressure remains unexplained, or the device is still unusable. Include timestamps, top-process data, free space, storage-health state, relevant event errors and whether the issue follows the user or device.
- Escalate to **Service Desk** when the issue is outside the assigned tier, requires an unapproved privileged/destructive/production change, affects multiple users/sites/services, or remains unresolved after the targeted diagnostics.
- Include exact scope, timestamps/timezone, before/after evidence, relevant logs/error codes, commands or portal paths used, change/approval IDs, attempted remediation, rollback state and the failed verification criterion.

## Documentation assurance

This procedure has passed the ShiftStart documentation/technical-content quality gate. Production operational verification remains subject to live validation on the organization's actual platform, permissions, versions and change controls, plus technical-owner sign-off where required.
