---
title: Recover a Mac requesting a FileVault recovery key
slug: recover-a-mac-requesting-a-filevault-recovery-key
description: Enterprise runbook to recover a mac requesting a filevault recovery key without skipping evidence, verification,
  rollback or escalation requirements.
content_type: procedure
category: macOS Endpoints
service: macOS Endpoints
severity: high
support_tier: L1-L2
owner_team: Apple Platform or Endpoint Engineering
platforms:
- macOS
risk_level: high
estimated_time: 15-45 minutes
tags:
- a
- filevault
- key
- l1-l2
- mac
- macos-endpoints
- recover
- recovery
- requesting
error_codes: []
tldr: For recover a mac requesting a filevault recovery key, strongly verify the requester and device, match the displayed
  recovery identifier to approved escrow, disclose the secret securely without recording it, restore access, then verify encryption
  and investigate the trigger.
related_symptoms:
- a-mac-requesting-a-filevault-recovery-key
- mac-is-not-working-correctly
- a-macos-error-or-access-issue-is-reported
symptom_weights:
  a-mac-requesting-a-filevault-recovery-key: 10
  mac-is-not-working-correctly: 3
  a-macos-error-or-access-issue-is-reported: 3
related_causes: []
related_commands: []
next_steps: []
escalation: Escalate to Apple Platform or Endpoint Engineering with scope, timestamps, evidence, actions, approvals, rollback
  state and failed verification criteria when the runbook reaches a stop condition or requires authority outside L1-L2.
last_reviewed: '2026-08-10'
review_cycle_days: 90
required_role: technician
approval_required: Verify the requester and exact managed device before retrieving or disclosing a recovery secret. Use only
  approved escrow and secure disclosure channels.
content_status: under_review
generated_baseline: false
reviewed_by: ''
last_tested: ''
tested_platforms: []
source_references:
- https://support.apple.com/guide/deployment/welcome/web
change_record: 'Full-catalogue documentation remediation: replaced generic baseline flow with risk-aware, procedure-specific
  diagnostics, safety controls, remediation, rollback, verification and escalation guidance.'
quality_gate: passed
documentation_review: passed
documentation_reviewed_on: '2026-08-10'
live_validation_required: true
live_validation_note: Technical-owner live validation and environment-specific sign-off remain required; no live-test evidence
  is fabricated by this documentation pass.
permalink: /procedures/recover-a-mac-requesting-a-filevault-recovery-key/
layout: article
risk_model: impact-v1
risk_basis: high risk under the repository impact model; verification priority P1.
verification_priority: P1
verification_state: documentation_verified_pending_live_validation
---
## Purpose and scope

Enterprise runbook to recover a mac requesting a filevault recovery key without skipping evidence, verification, rollback or escalation requirements.

Use this runbook for managed macOS endpoints using Apple-supported management, privacy and recovery paths while preserving user data and FileVault controls. It is a support procedure, not authority to bypass change management, security policy, privacy/records obligations or the owning team's operational controls.

## Safety, authorisation and stop conditions

**Approval requirement:** Verify the requester and exact managed device before retrieving or disclosing a recovery secret. Use only approved escrow and secure disclosure channels.

- Verify the exact user, device, service, tenant/site or resource before making changes; use immutable identifiers where available.
- Work within the assigned support tier and use named administrative accounts or approved privileged-access elevation.
- Capture the current state before any change so the action and rollback can be reconstructed.
- Do not request or record passwords, MFA codes, recovery secrets, private keys, access tokens or other credentials in the ticket.
- Verify the requester and exact managed device before accessing escrowed recovery material.
- Match a non-secret recovery identifier to the escrowed secret; never place the recovery password/key in tickets, screenshots or routine email/chat.
- Stop for identity mismatch, missing escrow, repeated recovery events or suspected tampering/compromise.

## Evidence to capture before changes

- Mac serial/asset ID and macOS version
- user and exact error
- MDM enrollment/compliance state
- FileVault, certificate/profile and privacy-permission state
- recent update/profile/application changes
- backup/recovery assurance and legal/security hold status

## Diagnostic path

- Verify device ownership, asset identity and recovery-key escrow before disclosing any key. Investigate why recovery was triggered, including firmware, boot, TPM or policy changes.
- separate local user, privacy permission, profile/MDM, certificate, network and hardware causes
- check enrollment/profile state before removing management
- preserve Keychain and user data before repair/reset
- do not disable FileVault or privacy/security controls as a workaround

### Read-only or low-risk diagnostic commands

**macOS — FileVault state**

```text
fdesetup status
```

Replace placeholders with the approved target. Commands are diagnostic examples; use only where the platform, role and environment support them.

## Procedure

1. **Verify identity and device.** Use the approved identity-verification method and cross-check device name/asset/serial plus the non-secret recovery identifier displayed by the device.

   **Expected result:** The original user or business task for **Recover a Mac requesting a FileVault recovery key** succeeds end-to-end, required controls remain enabled, and the observed result is recorded.

2. **Locate the exact escrow record.** Use only approved escrow such as the organization's MDM/directory/recovery service. Match the displayed recovery identifier before accessing the secret.

   **Expected result:** Locate the exact escrow record produces a recorded, observable result for **Recover a Mac requesting a FileVault recovery key** that is consistent with the approved scope and can be compared with the before-state.

3. **Disclose securely.** Provide the recovery secret only through the approved secure channel to the authorized person. Do not copy it into ticket notes, screenshots or normal messaging.

   **Expected result:** The ticket or handoff contains scope, timestamps, evidence, approvals, actions, verification, rollback state and the responsible next owner.

4. **Recover access.** Verify device ownership, asset identity and recovery-key escrow before disclosing any key. Investigate why recovery was triggered, including firmware, boot, TPM or policy changes.

   **Expected result:** Recover access produces a recorded, observable result for **Recover a Mac requesting a FileVault recovery key** that is consistent with the approved scope and can be compared with the before-state.

5. **Verify encryption and boot state.** Use the approved recovery process and suspend/resume protection only when authorised. Confirm encryption returns to protected state after recovery.

   **Expected result:** The original user or business task for **Recover a Mac requesting a FileVault recovery key** succeeds end-to-end, required controls remain enabled, and the observed result is recorded.

6. **Investigate the trigger.** Check firmware/TPM/Secure Boot, hardware, policy or account changes that caused recovery. Re-escrow/rotate the recovery secret when platform/policy requires it.

   **Expected result:** Evidence narrows the fault to a specific layer, dependency, policy, component or control before remediation is attempted.

7. **Verify the result.** Repeat the original business test using the normal user path and confirm: The device boots normally and encryption is fully protected and escrowed.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

8. **Monitor for recurrence.** Check the relevant logs, management/service health or monitoring after the change. If the fault returns, do not repeat increasingly destructive fixes; preserve the new evidence and escalate.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

9. **Document and close or hand off.** Record before/after state, exact actions, timestamps, approvals, commands/portal paths used, verification result, rollback state and any follow-up owner.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

## Approved remediation principles

- Verify device ownership and approved escrow before revealing a FileVault recovery key. Record only non-secret identifiers and rotate/re-escrow according to MDM policy after successful recovery.
- Preserve recovery/access assurance before changing encryption or Keychain. Use Apple-supported recovery/Keychain repair paths and verify MDM/FileVault escrow afterward.
- Use the approved recovery process and suspend/resume protection only when authorised. Confirm encryption returns to protected state after recovery.
- use Apple-supported settings, profiles and recovery tools
- change privacy or MDM settings only through the authoritative approved mechanism
- escalate erase/re-enrollment/recovery-key operations when ownership or recovery assurance is uncertain

## Rollback and recovery

- Do not disable encryption as rollback. If recovery fails, preserve the current encrypted state and escalate with the non-secret Recovery Key ID/device identifiers.
- Rotate/re-escrow recovery material after use when the platform and policy support or require it.

## Verification checklist

- [ ] Exact user/device/service/resource and scope were verified.
- [ ] Required authorization and support-tier boundaries were satisfied.
- [ ] Before-state evidence was captured.
- [ ] Diagnostics identified or narrowed the failing dependency before material changes.
- [ ] Only supported, least-disruptive actions were used.
- [ ] The device boots normally and encryption is fully protected and escrowed.
- [ ] the original macOS task succeeds
- [ ] FileVault, MDM and security posture remain expected
- [ ] no user data or Keychain access is unintentionally lost
- [ ] Security, encryption, management, retention and access controls remain in the intended state.
- [ ] Rollback state and escalation evidence are documented.

## Escalation package

- Escalate to Apple Platform or Endpoint Engineering with the exact user or service impact, timestamps and timezone, affected assets, screenshots or error text, diagnostic results, logs, recent changes, remediation attempted, rollback status and a clear statement of what remains broken.
- Escalate to **Apple Platform or Endpoint Engineering** when the issue is outside the assigned tier, requires an unapproved privileged/destructive/production change, affects multiple users/sites/services, or remains unresolved after the targeted diagnostics.
- Include exact scope, timestamps/timezone, before/after evidence, relevant logs/error codes, commands or portal paths used, change/approval IDs, attempted remediation, rollback state and the failed verification criterion.

## Documentation assurance

This procedure has passed the ShiftStart documentation/technical-content quality gate. Production operational verification remains subject to live validation on the organization's actual platform, permissions, versions and change controls, plus technical-owner sign-off where required.
