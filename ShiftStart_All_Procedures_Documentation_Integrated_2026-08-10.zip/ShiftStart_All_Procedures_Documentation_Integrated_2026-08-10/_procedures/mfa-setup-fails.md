---
title: Resolve MFA setup or approval failure
slug: mfa-setup-fails
description: Resolve MFA registration loops, missing prompts, time drift and stale authentication methods safely.
content_type: procedure
category: Identity & Access Management
service: Identity & Access Management
severity: high
support_tier: L2
owner_team: Identity & Access Management
platforms: []
risk_level: high
estimated_time: 10-20 mins
tags:
- mfa
- authenticator
- identity
- security
error_codes:
- registration
- failed
- request
- denied
- code
- invalid
tldr: For resolve mfa setup or approval failure, verify identity, approval, source of authority and before-state; make only
  the least-privilege approved change, allow convergence/token refresh, and verify effective access plus audit evidence.
related_symptoms:
- cannot-sign-in
symptom_weights: {}
related_causes: []
related_commands: []
next_steps: []
escalation: Escalate to Identity & Access Management with scope, timestamps, evidence, actions, approvals, rollback state
  and failed verification criteria when the runbook reaches a stop condition or requires authority outside L2.
last_reviewed: '2026-08-10'
review_cycle_days: 90
required_role: technician
approval_required: A valid access/service request and appropriate resource-owner or delegated approval is required for any
  access change. Privileged access follows the privileged-access workflow.
content_status: verified
generated_baseline: false
reviewed_by: ShiftStart technical review
last_tested: ''
tested_platforms: []
source_references:
- https://learn.microsoft.com/en-us/entra/identity/conditional-access/troubleshoot-conditional-access
- https://learn.microsoft.com/en-us/entra/identity/authentication/howto-mfa-userdevicesettings
- https://learn.microsoft.com/en-us/entra/identity/users/
change_record: 'Full-catalogue documentation remediation: replaced generic baseline flow with risk-aware, procedure-specific
  diagnostics, safety controls, remediation, rollback, verification and escalation guidance.'
quality_gate: passed
documentation_review: passed
documentation_reviewed_on: '2026-08-10'
live_validation_required: true
live_validation_note: Technical-owner live validation and environment-specific sign-off remain required; no live-test evidence
  is fabricated by this documentation pass.
permalink: /procedures/mfa-setup-fails/
layout: article
risk_model: impact-v1
risk_basis: high risk under the repository impact model; verification priority P1.
verification_priority: P1
verification_state: documentation_verified_live_evidence_incomplete
---
## Purpose and scope

Resolve MFA registration loops, missing prompts, time drift and stale authentication methods safely.

Use this runbook for identity, authentication and access changes with strong requester verification, least privilege and an auditable source of authority. It is a support procedure, not authority to bypass change management, security policy, privacy/records obligations or the owning team's operational controls.

## Safety, authorisation and stop conditions

**Approval requirement:** A valid access/service request and appropriate resource-owner or delegated approval is required for any access change. Privileged access follows the privileged-access workflow.

- Verify the exact user, device, service, tenant/site or resource before making changes; use immutable identifiers where available.
- Work within the assigned support tier and use named administrative accounts or approved privileged-access elevation.
- Capture the current state before any change so the action and rollback can be reconstructed.
- Do not request or record passwords, MFA codes, recovery secrets, private keys, access tokens or other credentials in the ticket.
- Confirm approval, resource owner, source of authority and requested least privilege before changing access.
- Use immutable object IDs for ambiguous names and capture before/after state.
- Stop for privileged, dynamic, synchronized, break-glass or governance-controlled access unless the correct privileged workflow is being used.

## Evidence to capture before changes

- requester identity-verification method
- immutable user/device/group/application identifiers
- approval/change record and resource owner
- before-state sign-in/access/group/role status
- relevant sign-in, audit, Conditional Access or synchronization evidence
- approval record, resource owner and before/after effective privilege

## Diagnostic path

- confirm whether the issue is identity proofing, credential, MFA, Conditional Access, directory sync, group/role or application authorization
- use immutable object IDs where duplicate names are possible
- check the authoritative directory and governance mechanism before changing membership or roles
- treat unexpected sign-in or compromise indicators as a security incident, not a routine reset
- Confirm identity, account state, device/time state and exact sign-in error before resetting credentials or factors.
- Review authoritative sign-in/audit logs when available; repeated or anomalous failures may require Security Operations.

### Read-only or low-risk diagnostic commands

Use the owning platform's read-only health, audit, log or inventory views first. Do not introduce a configuration change merely to gather a baseline.

## Procedure

1. **Verify requester, target and approval.** Resolve the user/service principal/device/group/application by immutable identifiers and confirm the approved access outcome and resource owner.

   **Expected result:** Requester, target asset/service, scope, authority and business impact are unambiguously identified and recorded before any material change.

2. **Identify source of authority and governance.** Determine whether the object is cloud-only, on-premises, synchronized, dynamic, privileged/PIM-controlled or managed through an access package/workflow.

   **Expected result:** The authoritative system and any synchronization, dynamic-membership or privileged-governance control are identified so the change is made in the correct place.

3. **Capture before-state.** Record current account status, relevant membership/role/license/authentication state and effective access.

   **Expected result:** A timestamped before-state is saved with the configuration, membership, health or data evidence needed to compare and, where possible, roll back.

4. **Diagnose the access path.** Use sign-in/audit logs and application/resource authorization evidence to identify the first failing identity or authorization control.

   **Expected result:** Evidence narrows the fault to a specific layer, dependency, policy, component or control before remediation is attempted.

5. **Apply the narrow approved change.** Verify identity strongly before changing authentication methods. Remove/replace only the lost or obsolete factor, require secure re-registration, and review recent sign-ins if loss or compromise is possible.

   **Expected result:** Only the approved least-privilege change is applied to the exact target in the authoritative system, with no unrelated privilege change.

6. **Refresh/converge safely.** Allow directory synchronization, token refresh or application authorization caches to converge. Avoid repeated membership/role changes while propagation is still in progress.

   **Expected result:** Synchronization, token, policy or application state converges to the intended configuration without repeated compensating changes.

7. **Capture after-state and effective privilege.** Verify the intended access works and the identity does not receive broader privilege than approved.

   **Expected result:** The after-state matches the approved outcome and shows no unrelated access, configuration or service change.

8. **Verify the result.** Repeat the original business test using the normal user path and confirm: The exact task addressed by **Resolve MFA setup or approval failure** succeeds end-to-end, the affected service remains stable, and no security, data-integrity or management control has been weakened.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

9. **Monitor for recurrence.** Check the relevant logs, management/service health or monitoring after the change. If the fault returns, do not repeat increasingly destructive fixes; preserve the new evidence and escalate.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

10. **Document and close or hand off.** Record before/after state, exact actions, timestamps, approvals, commands/portal paths used, verification result, rollback state and any follow-up owner.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

## Approved remediation principles

- Verify identity strongly before changing authentication methods. Remove/replace only the lost or obsolete factor, require secure re-registration, and review recent sign-ins if loss or compromise is possible.
- make only the approved least-privilege change in the authoritative system
- never request, record or transmit a user's password, MFA code, recovery secret or private key
- use PIM/access-governance workflows for privileged or role-assignable access

## Rollback and recovery

- Reverse only the exact access change when the captured before-state and approval support restoration.
- For suspected unauthorized privileged access, do not silently restore state; invoke the security incident process and preserve audit evidence.

## Verification checklist

- [ ] Exact user/device/service/resource and scope were verified.
- [ ] Required authorization and support-tier boundaries were satisfied.
- [ ] Before-state evidence was captured.
- [ ] Diagnostics identified or narrowed the failing dependency before material changes.
- [ ] Only supported, least-disruptive actions were used.
- [ ] intended sign-in or access succeeds
- [ ] effective privilege matches the approved scope
- [ ] audit logs record the authorized change
- [ ] Security, encryption, management, retention and access controls remain in the intended state.
- [ ] Rollback state and escalation evidence are documented.

## Escalation package

- Escalate to Identity & Access Management if identity cannot be verified, registration remains blocked, Conditional Access prevents setup, or no secure method is available. Include user ID, tenant/application, registration stage, device OS, exact error and timestamp. Never include one-time codes or authentication secrets.
- Escalate to **Identity & Access Management** when the issue is outside the assigned tier, requires an unapproved privileged/destructive/production change, affects multiple users/sites/services, or remains unresolved after the targeted diagnostics.
- Include exact scope, timestamps/timezone, before/after evidence, relevant logs/error codes, commands or portal paths used, change/approval IDs, attempted remediation, rollback state and the failed verification criterion.

## Documentation assurance

This procedure has passed the ShiftStart documentation/technical-content quality gate. Production operational verification remains subject to live validation on the organization's actual platform, permissions, versions and change controls, plus technical-owner sign-off where required.
