---
title: Troubleshoot a stopped Windows Server service
slug: troubleshoot-a-stopped-windows-server-service
description: Enterprise runbook to troubleshoot a stopped windows server service without skipping evidence, verification,
  rollback or escalation requirements.
content_type: procedure
category: Servers & Core Infrastructure
service: Servers & Core Infrastructure
severity: high
support_tier: L2-L3
owner_team: Server or Infrastructure Operations
platforms:
- Windows Server
- AD DS
- DNS
- DHCP
risk_level: high
estimated_time: 15-45 minutes
tags:
- a
- l2-l3
- server
- servers-and-core-infrastructure
- service
- stopped
- troubleshoot
- windows
error_codes: []
tldr: For troubleshoot a stopped windows server service, verify scope, capture before-state, use targeted read-only diagnostics
  to prove the failing dependency, apply the smallest supported correction, verify end-to-end, and escalate before destructive
  or security-weakening changes.
related_symptoms:
- a-stopped-windows-server-service
- a-server-or-infrastructure-service-is-degraded
symptom_weights:
  a-stopped-windows-server-service: 10
  a-server-or-infrastructure-service-is-degraded: 3
related_causes: []
related_commands: []
next_steps: []
escalation: Escalate to Server or Infrastructure Operations with scope, timestamps, evidence, actions, approvals, rollback
  state and failed verification criteria when the runbook reaches a stop condition or requires authority outside L2-L3.
last_reviewed: '2026-08-10'
review_cycle_days: 90
required_role: technician
approval_required: Use normal support authorization. Any admin, security-policy, data-destructive or production-impacting
  action requires the organization’s applicable approval/change process.
content_status: under_review
generated_baseline: false
reviewed_by: ''
last_tested: ''
tested_platforms: []
source_references:
- https://learn.microsoft.com/en-us/troubleshoot/windows-server/
- https://learn.microsoft.com/en-us/troubleshoot/windows-server/networking/dns-server-troubleshooting
change_record: 'Full-catalogue documentation remediation: replaced generic baseline flow with risk-aware, procedure-specific
  diagnostics, safety controls, remediation, rollback, verification and escalation guidance.'
quality_gate: passed
documentation_review: passed
documentation_reviewed_on: '2026-08-10'
live_validation_required: true
live_validation_note: Technical-owner live validation and environment-specific sign-off remain required; no live-test evidence
  is fabricated by this documentation pass.
permalink: /procedures/troubleshoot-a-stopped-windows-server-service/
layout: article
risk_model: impact-v1
risk_basis: high risk under the repository impact model; verification priority P1.
verification_priority: P1
verification_state: documentation_verified_pending_live_validation
---
## Purpose and scope

Enterprise runbook to troubleshoot a stopped windows server service without skipping evidence, verification, rollback or escalation requirements.

Use this runbook for server and core-infrastructure services with dependency, redundancy, change-control and service-restoration safeguards. It is a support procedure, not authority to bypass change management, security policy, privacy/records obligations or the owning team's operational controls.

## Safety, authorisation and stop conditions

**Approval requirement:** Use normal support authorization. Any admin, security-policy, data-destructive or production-impacting action requires the organization’s applicable approval/change process.

- Verify the exact user, device, service, tenant/site or resource before making changes; use immutable identifiers where available.
- Work within the assigned support tier and use named administrative accounts or approved privileged-access elevation.
- Capture the current state before any change so the action and rollback can be reconstructed.
- Do not request or record passwords, MFA codes, recovery secrets, private keys, access tokens or other credentials in the ticket.
- Prefer read-only and reversible diagnostics before reset, reinstall, profile removal, service restart or configuration changes.
- Stop if the issue becomes security-sensitive, data-destructive, production-wide, physically unsafe or outside your authority.

## Evidence to capture before changes

- server/service/role and environment
- business owners/dependencies and redundancy state
- monitoring metrics and relevant event/service logs
- recent change/patch/configuration history
- maintenance/change record and outage impact

## Diagnostic path

- Check service dependencies, account credentials, start type, executable path and recent configuration. Read the exact service and system logs at the failure time.
- check monitoring and dependencies before restarting services or servers
- separate capacity, network, identity, certificate, application and OS/service causes
- use role-specific diagnostics such as AD/DNS/DHCP replication or service health
- preserve logs and volatile evidence before disruptive recovery

### Read-only or low-risk diagnostic commands

**PowerShell — service and recent system errors**

```text
Get-Service | Where-Object Status -eq 'Stopped'
Get-WinEvent -LogName System -MaxEvents 100 | Where-Object LevelDisplayName -in 'Critical','Error'
```

Replace placeholders with the approved target. Commands are diagnostic examples; use only where the platform, role and environment support them.

## Procedure

1. **Confirm scope and capture the exact symptom.** Identify the affected user/device/service and reproduce **Troubleshoot a stopped Windows Server service** only when reproduction is safe and non-destructive. Record exact error text, time and scope.

   **Expected result:** Requester, target asset/service, scope, authority and business impact are unambiguously identified and recorded before any material change.

2. **Capture before-state.** Record the relevant configuration, version, management/security state and recent changes before modifying anything.

   **Expected result:** A timestamped before-state is saved with the configuration, membership, health or data evidence needed to compare and, where possible, roll back.

3. **Run the targeted diagnostic path.** Check service dependencies, account credentials, start type, executable path and recent configuration. Read the exact service and system logs at the failure time.

   **Expected result:** Evidence narrows the fault to a specific layer, dependency, policy, component or control before remediation is attempted.

4. **Prove the fault domain.** Do not change multiple layers at once. Decide whether the confirmed cause is local configuration, hardware, identity, network, service, policy or upstream infrastructure.

   **Expected result:** Evidence narrows the fault to a specific layer, dependency, policy, component or control before remediation is attempted.

5. **Apply the smallest supported correction.** Capture service state, dependency and recent logs before restart. Correct dependency/configuration failure first; restart only the affected service when safe and verify it remains stable.

   **Expected result:** One controlled, approved change is applied at the proven fault domain while rollback/failover remains available and impact does not expand.

6. **Use a secondary action only when justified.** If the first correction fails, collect the new evidence and use the next documented supported action. Escalate rather than progressing to reset/reinstall/destructive changes without justification.

   **Expected result:** A second action is taken only when new evidence justifies it; otherwise the case is escalated rather than progressing to destructive trial-and-error.

7. **Verify the result.** Repeat the original business test using the normal user path and confirm: The service remains running and its dependent transaction succeeds.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

8. **Monitor for recurrence.** Check the relevant logs, management/service health or monitoring after the change. If the fault returns, do not repeat increasingly destructive fixes; preserve the new evidence and escalate.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

9. **Document and close or hand off.** Record before/after state, exact actions, timestamps, approvals, commands/portal paths used, verification result, rollback state and any follow-up owner.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

## Approved remediation principles

- Capture service state, dependency and recent logs before restart. Correct dependency/configuration failure first; restart only the affected service when safe and verify it remains stable.
- Correct the confirmed dependency or configuration and start the service once. Do not repeatedly restart a failing production service without understanding impact.
- apply the smallest service/configuration correction first
- restart/failover/reboot only with impact assessment, owner/change approval and rollback/failover plan
- do not make production firewall, DNS, DHCP, certificate or directory changes outside the authoritative tool/process

## Rollback and recovery

- If the change causes new impact, stop further changes, restore the captured before-state using the supported rollback path, and record the rollback time/result.
- Do not 'roll back' by weakening authentication, encryption, endpoint protection, certificate validation, firewall/NAC or compliance controls.
- If rollback is impossible or would destroy evidence/data, leave the system in the safest stable state and escalate with the captured evidence.

## Verification checklist

- [ ] Exact user/device/service/resource and scope were verified.
- [ ] Required authorization and support-tier boundaries were satisfied.
- [ ] Before-state evidence was captured.
- [ ] Diagnostics identified or narrowed the failing dependency before material changes.
- [ ] Only supported, least-disruptive actions were used.
- [ ] The service remains running and its dependent transaction succeeds.
- [ ] service and dependencies are healthy
- [ ] monitoring/replication/listeners show expected state
- [ ] a real business transaction succeeds from an appropriate client
- [ ] Security, encryption, management, retention and access controls remain in the intended state.
- [ ] Rollback state and escalation evidence are documented.

## Escalation package

- Escalate to Server or Infrastructure Operations with the exact user or service impact, timestamps and timezone, affected assets, screenshots or error text, diagnostic results, logs, recent changes, remediation attempted, rollback status and a clear statement of what remains broken.
- Escalate to **Server or Infrastructure Operations** when the issue is outside the assigned tier, requires an unapproved privileged/destructive/production change, affects multiple users/sites/services, or remains unresolved after the targeted diagnostics.
- Include exact scope, timestamps/timezone, before/after evidence, relevant logs/error codes, commands or portal paths used, change/approval IDs, attempted remediation, rollback state and the failed verification criterion.

## Documentation assurance

This procedure has passed the ShiftStart documentation/technical-content quality gate. Production operational verification remains subject to live validation on the organization's actual platform, permissions, versions and change controls, plus technical-owner sign-off where required.
