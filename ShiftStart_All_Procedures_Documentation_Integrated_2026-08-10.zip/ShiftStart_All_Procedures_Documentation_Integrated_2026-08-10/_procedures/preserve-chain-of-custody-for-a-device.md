---
title: Preserve chain of custody for a device
slug: preserve-chain-of-custody-for-a-device
description: Enterprise runbook to preserve chain of custody for a device without skipping evidence, verification, rollback
  or escalation requirements.
content_type: procedure
category: Security & Compliance
service: Security & Compliance
severity: medium
support_tier: L1-L3
owner_team: Security Operations or Incident Response
platforms:
- EDR
- SIEM
- Identity
- Email security
risk_level: medium
estimated_time: 15-45 minutes
tags:
- a
- chain
- custody
- device
- for
- l1-l3
- of
- preserve
- security-and-compliance
error_codes: []
tldr: For preserve chain of custody for a device, collect only authorized evidence with minimal source alteration, record
  provenance and integrity, store it in restricted evidence storage, and hand it to the incident owner without mixing collection
  with cleanup.
related_symptoms:
- preserve-chain-of-custody-for-a-device
- a-security-or-compliance-concern-is-reported
symptom_weights:
  preserve-chain-of-custody-for-a-device: 10
  a-security-or-compliance-concern-is-reported: 3
related_causes: []
related_commands: []
next_steps: []
escalation: Escalate to Security Operations or Incident Response with scope, timestamps, evidence, actions, approvals, rollback
  state and failed verification criteria when the runbook reaches a stop condition or requires authority outside L1-L3.
last_reviewed: '2026-08-10'
review_cycle_days: 90
required_role: technician
approval_required: Operate only under the incident/case owner or Security Operations process. Destructive or containment actions
  require the authority defined in the incident-response plan.
content_status: under_review
generated_baseline: false
reviewed_by: ''
last_tested: ''
tested_platforms: []
source_references:
- https://csrc.nist.gov/pubs/sp/800/61/r3/final
- https://csrc.nist.gov/pubs/sp/800/86/final
- https://learn.microsoft.com/en-us/defender-endpoint/respond-machine-alerts
change_record: 'Full-catalogue documentation remediation: replaced generic baseline flow with risk-aware, procedure-specific
  diagnostics, safety controls, remediation, rollback, verification and escalation guidance.'
quality_gate: passed
documentation_review: passed
documentation_reviewed_on: '2026-08-10'
live_validation_required: true
live_validation_note: Technical-owner live validation and environment-specific sign-off remain required; no live-test evidence
  is fabricated by this documentation pass.
permalink: /procedures/preserve-chain-of-custody-for-a-device/
layout: article
risk_model: impact-v1
risk_basis: medium risk under the repository impact model; verification priority P2.
verification_priority: P2
verification_state: documentation_verified_pending_live_validation
---
## Purpose and scope

Enterprise runbook to preserve chain of custody for a device without skipping evidence, verification, rollback or escalation requirements.

Use this runbook for security and compliance response under incident-response authority with evidence preservation and controlled containment. It is a support procedure, not authority to bypass change management, security policy, privacy/records obligations or the owning team's operational controls.

## Safety, authorisation and stop conditions

**Approval requirement:** Operate only under the incident/case owner or Security Operations process. Destructive or containment actions require the authority defined in the incident-response plan.

- Verify the exact user, device, service, tenant/site or resource before making changes; use immutable identifiers where available.
- Work within the assigned support tier and use named administrative accounts or approved privileged-access elevation.
- Capture the current state before any change so the action and rollback can be reconstructed.
- Do not request or record passwords, MFA codes, recovery secrets, private keys, access tokens or other credentials in the ticket.
- Minimize changes to the source system; do not reboot, clean, quarantine, delete or alter evidence solely to make collection easier.
- Collect only within the approved case scope and maintain provenance, timestamps, integrity and controlled handoff.

## Evidence to capture before changes

- incident/case ID and security owner
- affected identities/assets and immutable IDs
- alert source, timestamps and timezone
- EDR/SIEM/email/identity/network evidence references
- actions already taken and custody/provenance details
- case/incident ID, incident owner and collection/containment authorization
- evidence provenance, hashes and custody handoffs where applicable

## Diagnostic path

- do not ask users to reproduce suspicious or malicious activity
- preserve volatile/time-sensitive evidence when authorized before cleanup
- correlate EDR, identity, email, network and endpoint telemetry
- scope affected systems/accounts before eradication or recovery

### Read-only or low-risk diagnostic commands

**PowerShell — hash a collected evidence file**

```text
Get-FileHash -Algorithm SHA256 -Path 'C:\Path\To\EvidenceFile.ext'
```

Replace placeholders with the approved target. Commands are diagnostic examples; use only where the platform, role and environment support them.

## Procedure

1. **Confirm case scope and authority.** Record the incident/case ID, incident owner, collection objective, systems/data in scope and any Legal/Privacy constraints.

   **Expected result:** The affected identities, devices, services and time window are bounded sufficiently for Security Operations to make a containment decision.

2. **Plan collection order.** Prioritize volatile or short-retention evidence when authorized, then persistent logs/files/telemetry. Avoid actions that overwrite timestamps or logs.

   **Expected result:** Plan collection order produces a recorded, observable result for **Preserve chain of custody for a device** that is consistent with the approved scope and can be compared with the before-state.

3. **Collect from approved sources.** Collect only the evidence sources required by the case using approved tools and read-only/export methods where possible.

   **Expected result:** Collect from approved sources produces a recorded, observable result for **Preserve chain of custody for a device** that is consistent with the approved scope and can be compared with the before-state.

4. **Record provenance and integrity.** For each item record source, collector, start/end time, timezone, tool/method and destination. Calculate and record a SHA-256 hash for exported files/images when appropriate.

   **Expected result:** Record provenance and integrity produces a recorded, observable result for **Preserve chain of custody for a device** that is consistent with the approved scope and can be compared with the before-state.

5. **Store and hand off securely.** Place evidence in the approved restricted repository, preserve original filenames/metadata where required, and record each custody transfer.

   **Expected result:** The ticket or handoff contains scope, timestamps, evidence, approvals, actions, verification, rollback state and the responsible next owner.

6. **Do not remediate inside this procedure.** Containment, eradication, credential changes, reimage or cleanup require a separate authorized incident-response action unless the incident lead explicitly combines them.

   **Expected result:** Do not remediate inside this procedure produces a recorded, observable result for **Preserve chain of custody for a device** that is consistent with the approved scope and can be compared with the before-state.

7. **Verify the result.** Repeat the original business test using the normal user path and confirm: The exact task addressed by **Preserve chain of custody for a device** succeeds end-to-end, the affected service remains stable, and no security, data-integrity or management control has been weakened.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

8. **Monitor for recurrence.** Check the relevant logs, management/service health or monitoring after the change. If the fault returns, do not repeat increasingly destructive fixes; preserve the new evidence and escalate.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

9. **Document and close or hand off.** Record before/after state, exact actions, timestamps, approvals, commands/portal paths used, verification result, rollback state and any follow-up owner.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

## Approved remediation principles

- Collect only authorized evidence, record provenance and timestamps, calculate integrity hashes where applicable, store in restricted evidence storage and document every handoff.
- contain through approved Security Operations controls
- do not delete/quarantine/reimage/reconnect or change credentials solely for evidence collection unless the incident lead directs it
- separate containment, eradication and recovery decisions and record each authorization

## Rollback and recovery

- Evidence collection should be non-destructive. If collection altered source state, document exactly what changed and notify the incident owner.
- Never overwrite the original evidence item with a processed copy.
- If integrity/provenance cannot be established, quarantine that evidence from authoritative use and recollect if possible.

## Verification checklist

- [ ] Exact user/device/service/resource and scope were verified.
- [ ] Required authorization and support-tier boundaries were satisfied.
- [ ] Before-state evidence was captured.
- [ ] Diagnostics identified or narrowed the failing dependency before material changes.
- [ ] Only supported, least-disruptive actions were used.
- [ ] Security Operations confirms the required containment/remediation state
- [ ] evidence remains available and attributable
- [ ] reconnection/closure is explicitly authorized
- [ ] Security, encryption, management, retention and access controls remain in the intended state.
- [ ] Rollback state and escalation evidence are documented.

## Escalation package

- Escalate to Security Operations or Incident Response with the exact user or service impact, timestamps and timezone, affected assets, screenshots or error text, diagnostic results, logs, recent changes, remediation attempted, rollback status and a clear statement of what remains broken.
- Escalate to **Security Operations or Incident Response** when the issue is outside the assigned tier, requires an unapproved privileged/destructive/production change, affects multiple users/sites/services, or remains unresolved after the targeted diagnostics.
- Include exact scope, timestamps/timezone, before/after evidence, relevant logs/error codes, commands or portal paths used, change/approval IDs, attempted remediation, rollback state and the failed verification criterion.

## Documentation assurance

This procedure has passed the ShiftStart documentation/technical-content quality gate. Production operational verification remains subject to live validation on the organization's actual platform, permissions, versions and change controls, plus technical-owner sign-off where required.
