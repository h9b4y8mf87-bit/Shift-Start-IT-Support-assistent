---
title: Perform an approved remote wipe
slug: perform-an-approved-remote-wipe
description: Enterprise runbook to perform an approved remote wipe without skipping evidence, verification, rollback or escalation
  requirements.
content_type: procedure
category: Mobile Devices & MDM
service: Mobile Devices & MDM
severity: high
support_tier: L1-L2
owner_team: Mobility or Endpoint Engineering
platforms:
- iOS
- iPadOS
- Android
- MDM
risk_level: high
estimated_time: 15-45 minutes
tags:
- an
- approved
- l1-l2
- mobile-devices-and-mdm
- perform
- remote
- wipe
error_codes: []
tldr: For perform an approved remote wipe, verify the exact asset and approval, confirm backup/hold/recovery requirements,
  choose the correct supported destructive action, execute once, and independently verify completion before lifecycle handoff.
related_symptoms:
- need-to-an-approved-remote-wipe
- corporate-access-on-a-mobile-device-is-not-working
- mobile-device-is-not-compliant
symptom_weights:
  need-to-an-approved-remote-wipe: 10
  corporate-access-on-a-mobile-device-is-not-working: 3
  mobile-device-is-not-compliant: 3
related_causes: []
related_commands: []
next_steps: []
escalation: Escalate to Mobility or Endpoint Engineering with scope, timestamps, evidence, actions, approvals, rollback state
  and failed verification criteria when the runbook reaches a stop condition or requires authority outside L1-L2.
last_reviewed: '2026-08-10'
review_cycle_days: 90
required_role: technician
approval_required: Explicit approval for the exact device, data scope and destructive action is required. Confirm backup,
  recovery and legal/security hold status before execution.
content_status: under_review
generated_baseline: false
reviewed_by: ''
last_tested: ''
tested_platforms: []
source_references:
- https://learn.microsoft.com/en-us/intune/device-management/
- https://support.apple.com/guide/deployment/welcome/web
- https://csrc.nist.gov/pubs/sp/800/88/r2/final
- https://learn.microsoft.com/en-us/intune/device-management/actions/retire
- https://learn.microsoft.com/en-us/intune/device-management/actions/delete
- https://learn.microsoft.com/en-us/intune/remote-actions/device-wipe
change_record: 'Full-catalogue documentation remediation: replaced generic baseline flow with risk-aware, procedure-specific
  diagnostics, safety controls, remediation, rollback, verification and escalation guidance.'
quality_gate: passed
documentation_review: passed
documentation_reviewed_on: '2026-08-10'
live_validation_required: true
live_validation_note: Technical-owner live validation and environment-specific sign-off remain required; no live-test evidence
  is fabricated by this documentation pass.
permalink: /procedures/perform-an-approved-remote-wipe/
layout: article
risk_model: impact-v1
risk_basis: high risk under the repository impact model; verification priority P1.
verification_priority: P1
verification_state: documentation_verified_pending_live_validation
---
## Purpose and scope
Use this procedure only when an **authorised full remote wipe** of a managed device is required. A wipe is a destructive action and can reset a device to factory settings and remove data, apps, settings and management configuration depending on platform and selected options.

If the goal is only to remove organisational management and company data from a personally owned/BYOD device, use the approved **Retire/selective corporate-data removal** process instead of a full wipe where supported by policy.

## Before you start
- Verify the requester's identity using the organisation's approved identity-verification process.
- Confirm the exact target device using at least two identifiers where available: asset tag, serial number, device name, MDM/Intune device ID, assigned user or IMEI.
- Confirm whether the device is corporate-owned or personally owned/BYOD.
- Obtain and record the required ticket, manager, change or security approval **before** issuing the wipe.
- Confirm whether required business data is backed up or intentionally disposable under policy.
- Check for a security investigation, legal hold, eDiscovery/retention requirement or other reason the device must be preserved as evidence.
- Confirm the device has adequate power and network connectivity where possible. A remote action normally requires the device to check in with the management service.
- Never ask for or record passwords, MFA/OTP codes, recovery passwords/keys, API tokens or other secrets in the support ticket.

## Choose the correct action
### Use **Wipe** when
- a full reset is explicitly authorised;
- a corporate-owned device is being securely reset, repurposed, retired, recovered from a lost/stolen state, or otherwise requires destructive erasure under policy; and
- the expected data-loss and recovery implications are understood.

### Use **Retire** or the organisation's selective corporate-data removal process when
- the device is personally owned/BYOD and personal data should remain intact; or
- only organisational apps, profiles, settings and management data must be removed.

Do not treat **Delete** as interchangeable with Wipe or Retire. In Microsoft Intune, Delete behaviour differs by platform/enrolment type and may trigger Retire or Wipe. Follow the applicable device-lifecycle procedure.

## Procedure
1. **Open the approved MDM console.** For Microsoft Intune, go to **Devices > All devices** and open the target device.

   **Expected result:** Open the approved MDM console produces a recorded, observable result for **Perform an approved remote wipe** that is consistent with the approved scope and can be compared with the before-state.

2. **Cross-check the target.** Match the MDM record to the approved request using the assigned user plus another reliable device identifier. Stop if there is any mismatch.

   **Expected result:** Cross-check the target produces a recorded, observable result for **Perform an approved remote wipe** that is consistent with the approved scope and can be compared with the before-state.

3. **Review device state.** Record ownership, platform, management/enrolment state, last check-in, compliance state and any pending remote actions. Confirm that the platform supports the intended action.

   **Expected result:** Review device state produces a recorded, observable result for **Perform an approved remote wipe** that is consistent with the approved scope and can be compared with the before-state.

4. **Reconfirm approval immediately before the destructive action.** Ensure the ticket/change record clearly identifies the device and authorises a full wipe.

   **Expected result:** Reconfirm approval immediately before the destructive action produces a recorded, observable result for **Perform an approved remote wipe** that is consistent with the approved scope and can be compared with the before-state.

5. **Select Wipe.** Review every platform-specific wipe option before confirming it. Do not enable advanced wipe options unless the approved use case and recovery plan specifically require them.

   <div class="expected"><strong>Expected result:</strong> The console displays the correct device and the selected action matches the approved destructive-wipe requirement.</div>

6. **Confirm and submit the action.** Record the submission time and timezone. Where the management platform requires additional administrative approval, do not bypass it.

   <div class="expected"><strong>Expected result:</strong> The MDM service accepts the remote action and records it against the intended device.</div>

7. **Monitor the action status.** Check the device action/audit status and, where possible, confirm that the target device received the command. Do not repeatedly issue duplicate wipe commands merely because the device is offline or slow to check in.

   **Expected result:** Relevant health, logs or monitoring remain stable through the defined observation period and no recurrence or new side effect is detected.

8. **Verify the outcome.** Depending on the device lifecycle, confirm one of the following:
   - the device has reset to the expected out-of-box/factory state;
   - the device is no longer exposing organisational data; or
   - the authorised custodian confirms the expected reset state after physical recovery.

   **Expected result:** The original user or business task for **Perform an approved remote wipe** succeeds end-to-end, required controls remain enabled, and the observed result is recorded.

9. **Perform lifecycle follow-up only when required.** Autopilot, Apple Automated Device Enrollment, Android Enterprise, Microsoft Entra or other inventory records may require separate retention/removal actions. Follow the applicable asset-lifecycle procedure rather than automatically deleting provisioning or identity records after every wipe.

   **Expected result:** Perform lifecycle follow-up only when required produces a recorded, observable result for **Perform an approved remote wipe** that is consistent with the approved scope and can be compared with the before-state.

10. **Document and close.** Record the device identifiers, requester verification method, approval/change reference, action selected, material wipe options, submission timestamp/timezone, status/result, verification performed and any follow-up owner.

   **Expected result:** The ticket or handoff contains scope, timestamps, evidence, approvals, actions, verification, rollback state and the responsible next owner.

## Stop conditions
Stop and escalate before issuing the wipe if:
- device identity, ownership or assigned user cannot be confidently verified;
- explicit approval is missing;
- the device may contain evidence for a cybersecurity investigation or is under legal/retention hold;
- BYOD ownership makes a full wipe inappropriate or uncertain;
- required backup/recovery obligations have not been addressed;
- the requested option could create an unrecoverable device state and no authorised recovery plan exists; or
- the technician does not have the required role or authority.

## Escalation evidence
Provide Mobility/Endpoint Engineering or Security with:
- ticket/change/approval reference;
- exact device identifiers and ownership;
- MDM platform and device state/last check-in;
- requested action and options;
- timestamps and timezone;
- action status/audit result; and
- any legal-hold, incident-response, backup or recovery concern.

## Verification checklist
- [ ] Requester identity was verified.
- [ ] Exact device and ownership were confirmed.
- [ ] Required destructive-action approval was recorded.
- [ ] Backup, legal-hold and security-investigation concerns were checked.
- [ ] Wipe rather than Retire/selective wipe was the correct action.
- [ ] Platform-specific wipe options were reviewed before confirmation.
- [ ] Remote action status and final device state were checked.
- [ ] Ticket contains identifiers, approval, timestamps, action and result but no secrets.

## Documentation control addendum

For **Perform an approved remote wipe**, treat the action as potentially irreversible. Verify the **exact asset** using multiple identifiers, confirm destructive-action approval, backup/recovery assurance and hold status, and stop before confirmation if any target detail is uncertain.

## Documentation assurance

This procedure has passed the ShiftStart documentation/technical-content quality gate. Production operational verification remains subject to live validation on the organization's actual platform, permissions, versions and change controls, plus technical-owner sign-off where required.
