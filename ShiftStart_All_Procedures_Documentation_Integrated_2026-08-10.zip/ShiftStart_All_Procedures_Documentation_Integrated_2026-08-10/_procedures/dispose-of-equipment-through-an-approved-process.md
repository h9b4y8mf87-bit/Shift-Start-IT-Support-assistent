---
title: Dispose of equipment through an approved process
slug: dispose-of-equipment-through-an-approved-process
description: Enterprise runbook to dispose of equipment through an approved process without skipping evidence, verification,
  rollback or escalation requirements.
content_type: procedure
category: Lifecycle & Asset Management
service: Lifecycle & Asset Management
severity: medium
support_tier: L1-L2
owner_team: Workplace Technology or Asset Management
platforms:
- Asset management
- Endpoint management
risk_level: medium
estimated_time: 15-45 minutes
tags:
- an
- approved
- dispose
- equipment
- l1-l2
- lifecycle-and-asset-management
- of
- process
- through
error_codes: []
tldr: For dispose of equipment through an approved process, verify the exact asset and approval, confirm backup/hold/recovery
  requirements, choose the correct supported destructive action, execute once, and independently verify completion before
  lifecycle handoff.
related_symptoms:
- dispose-of-equipment-through-an-approved-process
- a-device-software-or-asset-lifecycle-request-is-required
symptom_weights:
  dispose-of-equipment-through-an-approved-process: 10
  a-device-software-or-asset-lifecycle-request-is-required: 3
related_causes: []
related_commands: []
next_steps: []
escalation: Escalate to Workplace Technology or Asset Management with scope, timestamps, evidence, actions, approvals, rollback
  state and failed verification criteria when the runbook reaches a stop condition or requires authority outside L1-L2.
last_reviewed: '2026-08-10'
review_cycle_days: 90
required_role: technician
approval_required: Explicit approval for the exact device, data scope and destructive action is required. Confirm backup,
  recovery and legal/security hold status before execution.
content_status: under_review
generated_baseline: false
reviewed_by: ''
last_tested: ''
tested_platforms: []
source_references:
- https://csrc.nist.gov/pubs/sp/800/88/r2/final
- https://learn.microsoft.com/en-us/intune/device-management/
change_record: 'Full-catalogue documentation remediation: replaced generic baseline flow with risk-aware, procedure-specific
  diagnostics, safety controls, remediation, rollback, verification and escalation guidance.'
quality_gate: passed
documentation_review: passed
documentation_reviewed_on: '2026-08-10'
live_validation_required: true
live_validation_note: Technical-owner live validation and environment-specific sign-off remain required; no live-test evidence
  is fabricated by this documentation pass.
permalink: /procedures/dispose-of-equipment-through-an-approved-process/
layout: article
risk_model: impact-v1
risk_basis: medium risk under the repository impact model; verification priority P2.
verification_priority: P2
verification_state: documentation_verified_pending_live_validation
---
## Purpose and scope

Enterprise runbook to dispose of equipment through an approved process without skipping evidence, verification, rollback or escalation requirements.

Use this runbook for asset lifecycle work with accurate custody, inventory, data-protection and sanitization controls. It is a support procedure, not authority to bypass change management, security policy, privacy/records obligations or the owning team's operational controls.

## Safety, authorisation and stop conditions

**Approval requirement:** Explicit approval for the exact device, data scope and destructive action is required. Confirm backup, recovery and legal/security hold status before execution.

- Verify the exact user, device, service, tenant/site or resource before making changes; use immutable identifiers where available.
- Work within the assigned support tier and use named administrative accounts or approved privileged-access elevation.
- Capture the current state before any change so the action and rollback can be reconstructed.
- Do not request or record passwords, MFA codes, recovery secrets, private keys, access tokens or other credentials in the ticket.
- Treat wipe, reimage, sanitization and disposal as potentially irreversible. Verify the exact asset at least twice before confirmation.
- Confirm backup/recovery, encryption-key and legal/security-hold requirements before the destructive action.
- Stop if ownership, approval, target identity, backup assurance or recovery requirements are uncertain.

## Evidence to capture before changes

- asset tag, serial and assigned custodian
- inventory/MDM/encryption state
- handover/return/change approval
- backup and data-ownership status
- accessories, physical condition and chain-of-custody record
- backup/recovery assurance and legal/security hold status

## Diagnostic path

- Validate request, identity, location, role, asset, accessories, standard build and approvals. Record chain of custody and existing assignment before movement or replacement.
- reconcile physical identity with inventory and management records
- check encryption, backup and legal/security hold before reassignment or disposal
- validate hardware health before handover
- use the organization's approved sanitization method for the media type

### Read-only or low-risk diagnostic commands

Use the owning platform's read-only health, audit, log or inventory views first. Do not introduce a configuration change merely to gather a baseline.

## Procedure

1. **Validate target and destructive approval.** Cross-check asset/device identity using at least two identifiers and confirm the exact approved action, owner, ticket/change record and business reason.

   **Expected result:** Validate target and destructive approval produces a recorded, observable result for **Dispose of equipment through an approved process** that is consistent with the approved scope and can be compared with the before-state.

2. **Confirm recoverability and holds.** Verify backup/sync/recovery keys as applicable and check Legal, security investigation, eDiscovery and records-management holds.

   **Expected result:** Confirm recoverability and holds produces a recorded, observable result for **Dispose of equipment through an approved process** that is consistent with the approved scope and can be compared with the before-state.

3. **Select the correct destructive method.** Validate request, identity, location, role, asset, accessories, standard build and approvals. Record chain of custody and existing assignment before movement or replacement.

   **Expected result:** Select the correct destructive method produces a recorded, observable result for **Dispose of equipment through an approved process** that is consistent with the approved scope and can be compared with the before-state.

4. **Record pre-action state.** Capture last check-in, encryption/management state, data-protection status and any platform-specific options that affect retained data or provisioning state.

   **Expected result:** Record pre-action state produces a recorded, observable result for **Dispose of equipment through an approved process** that is consistent with the approved scope and can be compared with the before-state.

5. **Execute once through the authoritative platform.** Execute the lifecycle checklist and update inventory/licence records at each handoff. Route missing, damaged or non-standard items to the accountable owner.

   **Expected result:** The smallest supported correction that addresses the proven cause is applied, with no unnecessary destructive or security-weakening side effect.

6. **Verify completion independently.** Confirm the device/media reaches the expected post-action state and that management/inventory/sanitization evidence reflects completion.

   **Expected result:** The original user or business task for **Dispose of equipment through an approved process** succeeds end-to-end, required controls remain enabled, and the observed result is recorded.

7. **Complete lifecycle follow-up.** Reassign, dispose, recover or reprovision the asset only after the destructive action is verified and custody records are updated.

   **Expected result:** Complete lifecycle follow-up produces a recorded, observable result for **Dispose of equipment through an approved process** that is consistent with the approved scope and can be compared with the before-state.

8. **Verify the result.** Repeat the original business test using the normal user path and confirm: Physical assets, management records, access and user acknowledgement match.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

9. **Monitor for recurrence.** Check the relevant logs, management/service health or monitoring after the change. If the fault returns, do not repeat increasingly destructive fixes; preserve the new evidence and escalate.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

10. **Document and close or hand off.** Record before/after state, exact actions, timestamps, approvals, commands/portal paths used, verification result, rollback state and any follow-up owner.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

## Approved remediation principles

- Execute the lifecycle checklist and update inventory/licence records at each handoff. Route missing, damaged or non-standard items to the accountable owner.
- update custody and inventory at each handoff
- do not reuse or dispose of storage until sanitization is completed and validated
- preserve certificates/records required by policy

## Rollback and recovery

- A completed wipe/sanitization/reimage may be irreversible. The rollback is recovery from the confirmed backup or approved reprovisioning source, not reversal of the destructive action.
- If the wrong target was selected or status is ambiguous, stop issuing additional actions and escalate immediately.

## Verification checklist

- [ ] Exact user/device/service/resource and scope were verified.
- [ ] Required authorization and support-tier boundaries were satisfied.
- [ ] Before-state evidence was captured.
- [ ] Diagnostics identified or narrowed the failing dependency before material changes.
- [ ] Only supported, least-disruptive actions were used.
- [ ] Physical assets, management records, access and user acknowledgement match.
- [ ] inventory and physical asset match
- [ ] required configuration and encryption are present
- [ ] custody/sanitization/handover evidence is complete
- [ ] Security, encryption, management, retention and access controls remain in the intended state.
- [ ] Rollback state and escalation evidence are documented.

## Escalation package

- Escalate to Workplace Technology or Asset Management with the exact user or service impact, timestamps and timezone, affected assets, screenshots or error text, diagnostic results, logs, recent changes, remediation attempted, rollback status and a clear statement of what remains broken.
- Escalate to **Workplace Technology or Asset Management** when the issue is outside the assigned tier, requires an unapproved privileged/destructive/production change, affects multiple users/sites/services, or remains unresolved after the targeted diagnostics.
- Include exact scope, timestamps/timezone, before/after evidence, relevant logs/error codes, commands or portal paths used, change/approval IDs, attempted remediation, rollback state and the failed verification criterion.

## Documentation assurance

This procedure has passed the ShiftStart documentation/technical-content quality gate. Production operational verification remains subject to live validation on the organization's actual platform, permissions, versions and change controls, plus technical-owner sign-off where required.
