---
title: Recover a device requesting a BitLocker recovery key
slug: recover-a-device-requesting-a-bitlocker-recovery-key
description: Enterprise runbook to recover a device requesting a bitlocker recovery key without skipping evidence, verification,
  rollback or escalation requirements.
content_type: procedure
category: Windows Endpoints
service: Windows Endpoints
severity: high
support_tier: L1-L2
owner_team: Endpoint Engineering
platforms:
- Windows 10
- Windows 11
risk_level: high
estimated_time: 15-45 minutes
tags:
- a
- bitlocker
- device
- key
- l1-l2
- recover
- recovery
- requesting
- windows-endpoints
error_codes: []
tldr: For recover a device requesting a bitlocker recovery key, strongly verify the requester and device, match the displayed
  recovery identifier to approved escrow, disclose the secret securely without recording it, restore access, then verify encryption
  and investigate the trigger.
related_symptoms:
- a-device-requesting-a-bitlocker-recovery-key
- windows-device-is-not-working-correctly
- a-windows-error-or-performance-issue-is-reported
symptom_weights:
  a-device-requesting-a-bitlocker-recovery-key: 10
  windows-device-is-not-working-correctly: 3
  a-windows-error-or-performance-issue-is-reported: 3
related_causes: []
related_commands: []
next_steps: []
escalation: Escalate to Endpoint Engineering with scope, timestamps, evidence, actions, approvals, rollback state and failed
  verification criteria when the runbook reaches a stop condition or requires authority outside L1-L2.
last_reviewed: '2026-08-10'
review_cycle_days: 90
required_role: technician
approval_required: Verify the requester and exact managed device before retrieving or disclosing a recovery secret. Use only
  approved escrow and secure disclosure channels.
content_status: under_review
generated_baseline: false
reviewed_by: ''
last_tested: ''
tested_platforms: []
source_references:
- https://learn.microsoft.com/en-us/troubleshoot/windows-client/welcome-windows-client
- https://learn.microsoft.com/en-us/windows/client-management/
- https://learn.microsoft.com/en-us/windows/security/operating-system-security/data-protection/bitlocker/recovery-overview
- https://learn.microsoft.com/en-us/windows/security/operating-system-security/data-protection/bitlocker/recovery-process
change_record: 'Full-catalogue documentation remediation: replaced generic baseline flow with risk-aware, procedure-specific
  diagnostics, safety controls, remediation, rollback, verification and escalation guidance.'
quality_gate: passed
documentation_review: passed
documentation_reviewed_on: '2026-08-10'
live_validation_required: true
live_validation_note: Technical-owner live validation and environment-specific sign-off remain required; no live-test evidence
  is fabricated by this documentation pass.
permalink: /procedures/recover-a-device-requesting-a-bitlocker-recovery-key/
layout: article
risk_model: impact-v1
risk_basis: high risk under the repository impact model; verification priority P1.
verification_priority: P1
verification_state: documentation_verified_pending_live_validation
---
## Purpose and scope
Use this procedure when an authorised Windows 10 or Windows 11 device starts at the **BitLocker recovery** screen and requests a recovery password.

The BitLocker recovery password is a **48-digit secret** that can unlock the encrypted volume. Treat it as sensitive security information. This procedure is for legitimate device recovery only; it does not bypass BitLocker or replace organisational identity, privileged-access or encryption policy.

## Before you start
- Verify the requester using the organisation's approved identity-verification process.
- Confirm the exact device using at least two identifiers where available: asset tag, serial number, device name, Microsoft Entra device record or assigned user.
- Ask the user to read the **Recovery Key ID** shown on the BitLocker recovery screen. Do not confuse the Key ID with the 48-digit recovery password.
- Confirm that you are authorised to view/disclose recovery information for that device. Record the approved recovery disclosure or support authority in the ticket without recording the recovery password.
- Do **not** disable TPM, clear the TPM, change BIOS/UEFI settings, disable Secure Boot, change storage-controller mode, reimage the device or alter boot security merely to bypass the recovery screen.
- Do not paste the 48-digit recovery password into a ticket, email, ordinary chat transcript, screenshot or knowledge article.

## Approved recovery sources
Use the organisation's configured escrow source. Depending on management design, this can include:
- Microsoft Entra ID;
- Microsoft Intune;
- Active Directory Domain Services (AD DS); or
- another organisation-approved BitLocker recovery service.

For supported self-service scenarios, an authorised user may also retrieve the password from the organisation's Microsoft Entra/Company Portal experience when policy permits.

## Procedure
1. **Confirm the recovery screen.** Verify that the device is displaying BitLocker recovery and record the displayed **Recovery Key ID**, device identity, date/time and timezone. Do not record the 48-digit password.

   **Expected result:** Confirm the recovery screen produces a recorded, observable result for **Recover a device requesting a BitLocker recovery key** that is consistent with the approved scope and can be compared with the before-state.

2. **Check for a known security or hardware event.** Ask whether the device recently had firmware/BIOS updates, TPM or motherboard service, Secure Boot/boot-order changes, storage changes, docking changes, operating-system servicing or other hardware/firmware maintenance. If the circumstances suggest tampering or compromise, stop and contact Security/Endpoint Engineering before disclosure.

   **Expected result:** Check for a known security or hardware event produces a recorded, observable result for **Recover a device requesting a BitLocker recovery key** that is consistent with the approved scope and can be compared with the before-state.

3. **Open the approved recovery escrow.** Use your named support/admin account and the least-privileged role that permits recovery-password access.

   **Expected result:** Open the approved recovery escrow produces a recorded, observable result for **Recover a device requesting a BitLocker recovery key** that is consistent with the approved scope and can be compared with the before-state.

4. **Match the recovery record.** Locate the correct device and match the **Recovery Key ID** displayed on the locked device to the corresponding escrowed recovery password. Never choose a password based only on user name or device name when an ID match is available.

   <div class="expected"><strong>Expected result:</strong> The device identity and displayed Recovery Key ID match one authorised escrow record.</div>

5. **Stop if there is no exact match.** Do not guess, reuse a password from another protector/device, or attempt unsupported bypasses. Escalate with the device identifiers and Recovery Key ID.

   **Expected result:** Stop if there is no exact match produces a recorded, observable result for **Recover a device requesting a BitLocker recovery key** that is consistent with the approved scope and can be compared with the before-state.

6. **Provide the recovery password securely.** Follow the organisation's approved secure disclosure method after identity and device verification. Prefer the user entering it directly at the device. Avoid persistent channels and never add the password to the incident ticket.

   **Expected result:** Provide the recovery password securely produces a recorded, observable result for **Recover a device requesting a BitLocker recovery key** that is consistent with the approved scope and can be compared with the before-state.

7. **Enter the 48-digit password at the BitLocker screen.** If accepted, allow Windows to boot normally. If the password is rejected, re-check the Key ID and source before any further attempt.

   <div class="expected"><strong>Expected result:</strong> The correct recovery password unlocks the operating-system volume and Windows starts.</div>

8. **Verify BitLocker state after sign-in.** Confirm the operating-system drive remains encrypted and protected.

{% capture bitlocker_status %}
Get-BitLockerVolume -MountPoint 'C:' | Select-Object MountPoint,VolumeStatus,ProtectionStatus,EncryptionPercentage
{% endcapture %}
{% include command.html shell="powershell" label="Check BitLocker protection state" command=bitlocker_status %}

   <div class="expected"><strong>Expected result:</strong> The OS volume reports encryption enabled and protection in the expected organisational state.</div>

9. **Investigate the recovery trigger.** Review firmware/TPM status, recent firmware or Windows updates, hardware service/change records, boot configuration changes and relevant event logs. A one-time legitimate change can explain recovery; repeated or unexplained recovery requires escalation.

   **Expected result:** Evidence narrows the fault to a specific layer, dependency, policy, component or control before remediation is attempted.

10. **Confirm escrow health.** Verify that an authorised recovery password for the active protector is escrowed according to policy. If policy or the management platform rotates the recovery password after use/disclosure, verify that the new recovery information is successfully escrowed before closure.

   **Expected result:** Confirm escrow health produces a recorded, observable result for **Recover a device requesting a BitLocker recovery key** that is consistent with the approved scope and can be compared with the before-state.

11. **Document and close.** Record:
   - requester verification performed;
   - device identifiers;
   - Recovery Key ID only;
   - escrow source used;
   - date/time/timezone;
   - whether recovery succeeded;
   - BitLocker protection state after recovery;
   - likely recovery trigger; and
   - escalation/follow-up required.

   **Never record the 48-digit recovery password.**

   **Expected result:** The ticket or handoff contains scope, timestamps, evidence, approvals, actions, verification, rollback state and the responsible next owner.

## Stop conditions
Stop and escalate if:
- requester identity or device ownership cannot be verified;
- you are not authorised to view/disclose recovery information;
- no escrowed record matches the displayed Recovery Key ID;
- the matched recovery password fails;
- the device repeatedly returns to BitLocker recovery;
- there are signs of tampering, compromise, unexpected firmware/TPM changes or hardware replacement;
- the TPM appears unavailable or unhealthy after recovery; or
- recovery would conflict with a security investigation, legal hold or other organisational control.

## Evidence required for escalation
Provide Endpoint Engineering/Security with:
- ticket and business impact;
- device name, asset tag and serial number where available;
- **Recovery Key ID, not the recovery password**;
- escrow source checked and match/no-match result;
- date/time/timezone;
- firmware/TPM/hardware changes reported;
- exact recovery-screen error/result;
- post-boot BitLocker status, if recovery succeeded; and
- whether the issue is recurring.

## Verification checklist
- [ ] Requester identity and exact device were verified.
- [ ] Recovery Key ID was recorded and matched to an approved escrow record.
- [ ] The 48-digit recovery password was not stored in the ticket or other persistent support record.
- [ ] Windows booted successfully, or the failure was escalated.
- [ ] BitLocker encryption/protection state was checked after recovery.
- [ ] Likely recovery trigger was investigated.
- [ ] Recovery escrow/rotation requirements were confirmed where applicable.

## Documentation control addendum

For **Recover a device requesting a BitLocker recovery key**, use the approved identity-verification and recovery-key release process. Authorization to access escrowed recovery material must be established before the secret is viewed or disclosed.

## Documentation assurance

This procedure has passed the ShiftStart documentation/technical-content quality gate. Production operational verification remains subject to live validation on the organization's actual platform, permissions, versions and change controls, plus technical-owner sign-off where required.
