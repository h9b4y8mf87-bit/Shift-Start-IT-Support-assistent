---
title: Troubleshoot a failing storage device
slug: troubleshoot-a-failing-storage-device
description: Enterprise runbook to troubleshoot a failing storage device without skipping evidence, verification, rollback
  or escalation requirements.
content_type: procedure
category: Hardware & Peripherals
service: Hardware & Peripherals
severity: medium
support_tier: L1-L2
owner_team: Workplace Hardware or Vendor Support
platforms:
- Corporate hardware
risk_level: medium
estimated_time: 15-45 minutes
tags:
- a
- device
- failing
- hardware-and-peripherals
- l1-l2
- storage
- troubleshoot
error_codes: []
tldr: For troubleshoot a failing storage device, verify scope, capture before-state, use targeted read-only diagnostics to
  prove the failing dependency, apply the smallest supported correction, verify end-to-end, and escalate before destructive
  or security-weakening changes.
related_symptoms:
- a-failing-storage-device
- hardware-or-peripheral-is-not-functioning
symptom_weights:
  a-failing-storage-device: 10
  hardware-or-peripheral-is-not-functioning: 3
related_causes: []
related_commands: []
next_steps: []
escalation: Escalate to Workplace Hardware or Vendor Support with scope, timestamps, evidence, actions, approvals, rollback
  state and failed verification criteria when the runbook reaches a stop condition or requires authority outside L1-L2.
last_reviewed: '2026-08-10'
review_cycle_days: 90
required_role: technician
approval_required: Use normal support authorization. Any admin, security-policy, data-destructive or production-impacting
  action requires the organization’s applicable approval/change process.
content_status: under_review
generated_baseline: false
reviewed_by: ''
last_tested: ''
tested_platforms: []
source_references:
- https://learn.microsoft.com/en-us/troubleshoot/windows-client/welcome-windows-client
change_record: 'Full-catalogue documentation remediation: replaced generic baseline flow with risk-aware, procedure-specific
  diagnostics, safety controls, remediation, rollback, verification and escalation guidance.'
quality_gate: passed
documentation_review: passed
documentation_reviewed_on: '2026-08-10'
live_validation_required: true
live_validation_note: Technical-owner live validation and environment-specific sign-off remain required; no live-test evidence
  is fabricated by this documentation pass.
permalink: /procedures/troubleshoot-a-failing-storage-device/
layout: article
risk_model: impact-v1
risk_basis: medium risk under the repository impact model; verification priority P2.
verification_priority: P2
verification_state: documentation_verified_pending_live_validation
---
## Purpose and scope

Enterprise runbook to troubleshoot a failing storage device without skipping evidence, verification, rollback or escalation requirements.

Use this runbook for corporate hardware and peripherals using non-destructive diagnostics, ESD/electrical safety and warranty controls. It is a support procedure, not authority to bypass change management, security policy, privacy/records obligations or the owning team's operational controls.

## Safety, authorisation and stop conditions

**Approval requirement:** Use normal support authorization. Any admin, security-policy, data-destructive or production-impacting action requires the organization’s applicable approval/change process.

- Verify the exact user, device, service, tenant/site or resource before making changes; use immutable identifiers where available.
- Work within the assigned support tier and use named administrative accounts or approved privileged-access elevation.
- Capture the current state before any change so the action and rollback can be reconstructed.
- Do not request or record passwords, MFA codes, recovery secrets, private keys, access tokens or other credentials in the ticket.
- Prefer read-only and reversible diagnostics before reset, reinstall, profile removal, service restart or configuration changes.
- Stop if the issue becomes security-sensitive, data-destructive, production-wide, physically unsafe or outside your authority.

## Evidence to capture before changes

- asset tag, serial/model and warranty state
- physical condition, LEDs/beeps and exact symptom
- power source, dock/cable/peripheral identifiers
- recent drop/liquid/repair/firmware history
- built-in diagnostic result and business impact

## Diagnostic path

- remove external variables using known-good approved cables/peripherals where safe
- run vendor/OEM diagnostics appropriate to the exact model
- inspect power, thermal and physical-safety indicators before software changes
- do not open sealed/warranty equipment unless role and procedure permit it

### Read-only or low-risk diagnostic commands

Use the owning platform's read-only health, audit, log or inventory views first. Do not introduce a configuration change merely to gather a baseline.

## Procedure

1. **Confirm scope and capture the exact symptom.** Identify the affected user/device/service and reproduce **Troubleshoot a failing storage device** only when reproduction is safe and non-destructive. Record exact error text, time and scope.

   **Expected result:** Requester, target asset/service, scope, authority and business impact are unambiguously identified and recorded before any material change.

2. **Capture before-state.** Record the relevant configuration, version, management/security state and recent changes before modifying anything.

   **Expected result:** A timestamped before-state is saved with the configuration, membership, health or data evidence needed to compare and, where possible, roll back.

3. **Run the targeted diagnostic path.** Use the scenario-specific checks below to identify the first failing dependency; compare a known-good path when available.

   **Expected result:** Evidence narrows the fault to a specific layer, dependency, policy, component or control before remediation is attempted.

4. **Prove the fault domain.** Do not change multiple layers at once. Decide whether the confirmed cause is local configuration, hardware, identity, network, service, policy or upstream infrastructure.

   **Expected result:** Evidence narrows the fault to a specific layer, dependency, policy, component or control before remediation is attempted.

5. **Apply the smallest supported correction.** Minimize writes and power cycles. Capture health evidence, stop normal use when failure is credible, and use approved imaging/recovery or specialist escalation instead of repair tools that may worsen media failure.

   **Expected result:** The smallest supported correction that addresses the proven cause is applied, with no unnecessary destructive or security-weakening side effect.

6. **Use a secondary action only when justified.** If the first correction fails, collect the new evidence and use the next documented supported action. Escalate rather than progressing to reset/reinstall/destructive changes without justification.

   **Expected result:** A second action is taken only when new evidence justifies it; otherwise the case is escalated rather than progressing to destructive trial-and-error.

7. **Verify the result.** Repeat the original business test using the normal user path and confirm: The exact task addressed by **Troubleshoot a failing storage device** succeeds end-to-end, the affected service remains stable, and no security, data-integrity or management control has been weakened.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

8. **Monitor for recurrence.** Check the relevant logs, management/service health or monitoring after the change. If the fault returns, do not repeat increasingly destructive fixes; preserve the new evidence and escalate.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

9. **Document and close or hand off.** Record before/after state, exact actions, timestamps, approvals, commands/portal paths used, verification result, rollback state and any follow-up owner.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

## Approved remediation principles

- Minimize writes and power cycles. Capture health evidence, stop normal use when failure is credible, and use approved imaging/recovery or specialist escalation instead of repair tools that may worsen media failure.
- replace one field-replaceable component only when authorized and model-compatible
- use ESD precautions and remove power where the service manual requires it
- isolate swollen, leaking, overheated or liquid-damaged equipment from normal use

## Rollback and recovery

- If the change causes new impact, stop further changes, restore the captured before-state using the supported rollback path, and record the rollback time/result.
- Do not 'roll back' by weakening authentication, encryption, endpoint protection, certificate validation, firewall/NAC or compliance controls.
- If rollback is impossible or would destroy evidence/data, leave the system in the safest stable state and escalate with the captured evidence.

## Verification checklist

- [ ] Exact user/device/service/resource and scope were verified.
- [ ] Required authorization and support-tier boundaries were satisfied.
- [ ] Before-state evidence was captured.
- [ ] Diagnostics identified or narrowed the failing dependency before material changes.
- [ ] Only supported, least-disruptive actions were used.
- [ ] device passes diagnostics
- [ ] original hardware function works repeatedly
- [ ] asset/warranty records reflect any replacement
- [ ] Security, encryption, management, retention and access controls remain in the intended state.
- [ ] Rollback state and escalation evidence are documented.

## Escalation package

- Escalate to Workplace Hardware or Vendor Support with the exact user or service impact, timestamps and timezone, affected assets, screenshots or error text, diagnostic results, logs, recent changes, remediation attempted, rollback status and a clear statement of what remains broken.
- Escalate to **Workplace Hardware or Vendor Support** when the issue is outside the assigned tier, requires an unapproved privileged/destructive/production change, affects multiple users/sites/services, or remains unresolved after the targeted diagnostics.
- Include exact scope, timestamps/timezone, before/after evidence, relevant logs/error codes, commands or portal paths used, change/approval IDs, attempted remediation, rollback state and the failed verification criterion.

## Documentation assurance

This procedure has passed the ShiftStart documentation/technical-content quality gate. Production operational verification remains subject to live validation on the organization's actual platform, permissions, versions and change controls, plus technical-owner sign-off where required.
