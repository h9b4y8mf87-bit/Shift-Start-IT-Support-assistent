---
title: Migrate an authenticator to a replacement phone
slug: migrate-an-authenticator-to-a-replacement-phone
description: Enterprise runbook to migrate an authenticator to a replacement phone without skipping evidence, verification,
  rollback or escalation requirements.
content_type: procedure
category: Mobile Devices & MDM
service: Mobile Devices & MDM
severity: medium
support_tier: L1-L2
owner_team: Mobility or Endpoint Engineering
platforms:
- iOS
- iPadOS
- Android
- MDM
risk_level: medium
estimated_time: 15-45 minutes
tags:
- a
- an
- authenticator
- l1-l2
- migrate
- mobile-devices-and-mdm
- phone
- replacement
- to
error_codes: []
tldr: For migrate an authenticator to a replacement phone, validate owner, recovery point and target, preserve the current
  state, recover non-destructively first, verify content and metadata, and overwrite/merge only with explicit approval.
related_symptoms:
- migrate-an-authenticator-to-a-replacement-phone
- corporate-access-on-a-mobile-device-is-not-working
- mobile-device-is-not-compliant
symptom_weights:
  migrate-an-authenticator-to-a-replacement-phone: 10
  corporate-access-on-a-mobile-device-is-not-working: 3
  mobile-device-is-not-compliant: 3
related_causes: []
related_commands: []
next_steps: []
escalation: Escalate to Mobility or Endpoint Engineering with scope, timestamps, evidence, actions, approvals, rollback state
  and failed verification criteria when the runbook reaches a stop condition or requires authority outside L1-L2.
last_reviewed: '2026-08-10'
review_cycle_days: 90
required_role: technician
approval_required: The data owner or authorized requester must approve the recovery scope, source/recovery point and any overwrite.
  Legal/security holds take precedence.
content_status: under_review
generated_baseline: false
reviewed_by: ''
last_tested: ''
tested_platforms: []
source_references:
- https://learn.microsoft.com/en-us/intune/device-management/
- https://support.apple.com/guide/deployment/welcome/web
change_record: 'Full-catalogue documentation remediation: replaced generic baseline flow with risk-aware, procedure-specific
  diagnostics, safety controls, remediation, rollback, verification and escalation guidance.'
quality_gate: passed
documentation_review: passed
documentation_reviewed_on: '2026-08-10'
live_validation_required: true
live_validation_note: Technical-owner live validation and environment-specific sign-off remain required; no live-test evidence
  is fabricated by this documentation pass.
permalink: /procedures/migrate-an-authenticator-to-a-replacement-phone/
layout: article
risk_model: impact-v1
risk_basis: medium risk under the repository impact model; verification priority P2.
verification_priority: P2
verification_state: documentation_verified_pending_live_validation
---
## Purpose and scope

Enterprise runbook to migrate an authenticator to a replacement phone without skipping evidence, verification, rollback or escalation requirements.

Use this runbook for managed mobile-device operations with enrollment-type awareness, privacy controls and distinction between selective corporate-data removal and full-device wipe. It is a support procedure, not authority to bypass change management, security policy, privacy/records obligations or the owning team's operational controls.

## Safety, authorisation and stop conditions

**Approval requirement:** The data owner or authorized requester must approve the recovery scope, source/recovery point and any overwrite. Legal/security holds take precedence.

- Verify the exact user, device, service, tenant/site or resource before making changes; use immutable identifiers where available.
- Work within the assigned support tier and use named administrative accounts or approved privileged-access elevation.
- Capture the current state before any change so the action and rollback can be reconstructed.
- Do not request or record passwords, MFA codes, recovery secrets, private keys, access tokens or other credentials in the ticket.
- Do not overwrite the only remaining or newer copy of data without explicit owner authorization.
- Prefer recovery to an alternate location/version first and preserve the original when practical.
- Stop when legal hold, ransomware/malware, failing media or unclear data ownership changes the recovery risk.

## Evidence to capture before changes

- user and exact device identifiers
- ownership/enrollment type and supervision/work-profile state
- MDM compliance, last check-in and assigned policies
- backup/recovery-key state where applicable
- approval for any remote/destructive action
- backup/recovery assurance and legal/security hold status

## Diagnostic path

- Review registered authentication methods, sign-in logs, device time and policy requirements. Confirm a recovery method exists before deleting or replacing an authentication method.
- confirm device ownership and enrollment type before choosing an MDM action
- check service connectivity, compliance, certificate/profile and app assignment state
- distinguish user-data issues from management-policy issues
- do not remove enrollment or factory reset solely to test a hypothesis

### Read-only or low-risk diagnostic commands

Use the owning platform's read-only health, audit, log or inventory views first. Do not introduce a configuration change merely to gather a baseline.

## Procedure

1. **Validate recovery request.** Confirm owner/requester, exact data object, source, target, requested point/version and overwrite consequences.

   **Expected result:** Validate recovery request produces a recorded, observable result for **Migrate an authenticator to a replacement phone** that is consistent with the approved scope and can be compared with the before-state.

2. **Protect current state.** Preserve the existing target/newer version and record metadata/permissions. Check legal/security holds and malware/ransomware context.

   **Expected result:** Protect current state produces a recorded, observable result for **Migrate an authenticator to a replacement phone** that is consistent with the approved scope and can be compared with the before-state.

3. **Validate the recovery source.** Review registered authentication methods, sign-in logs, device time and policy requirements. Confirm a recovery method exists before deleting or replacing an authentication method.

   **Expected result:** The requested recovery point is present, readable, in scope and suitable for a non-destructive restore test.

4. **Recover non-destructively first.** Verify identity strongly before changing authentication methods. Remove/replace only the lost or obsolete factor, require secure re-registration, and review recent sign-ins if loss or compromise is possible. Check room/phone account, network, selected endpoints and service state before reboot/factory reset. Use a controlled test call/meeting and preserve emergency-calling configuration.

   **Expected result:** A recovered copy is produced in an alternate or otherwise non-destructive target and is available for integrity validation before any overwrite.

5. **Validate recovered data.** Open/test the recovered content, compare size/hash/metadata where appropriate and confirm required permissions/ownership.

   **Expected result:** Recovered content opens successfully and its expected content, metadata, ownership and permissions are confirmed.

6. **Merge or replace only with approval.** If the final action overwrites current data, obtain explicit approval after the recovered copy is proven usable.

   **Expected result:** Any overwrite or merge occurs only after the recovered copy is proven usable and the data owner has approved the final action.

7. **Verify the result.** Repeat the original business test using the normal user path and confirm: The user completes MFA with the approved method and the old method no longer works.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

8. **Monitor for recurrence.** Check the relevant logs, management/service health or monitoring after the change. If the fault returns, do not repeat increasingly destructive fixes; preserve the new evidence and escalate.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

9. **Document and close or hand off.** Record before/after state, exact actions, timestamps, approvals, commands/portal paths used, verification result, rollback state and any follow-up owner.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

## Approved remediation principles

- Verify identity strongly before changing authentication methods. Remove/replace only the lost or obsolete factor, require secure re-registration, and review recent sign-ins if loss or compromise is possible.
- Check room/phone account, network, selected endpoints and service state before reboot/factory reset. Use a controlled test call/meeting and preserve emergency-calling configuration.
- Use the approved proofing process, register the replacement method and revoke the lost method. Test primary and recovery authentication from a trusted device.
- use the least destructive supported MDM action first
- use Retire/selective corporate-data removal for appropriate BYOD scenarios and Wipe only when full erase is authorized
- record platform-specific action options before confirmation

## Rollback and recovery

- Because recovery is performed to an alternate location/version first where practical, rollback is normally removal of the unneeded recovered copy after owner approval.
- If current data was overwritten, restore the preserved pre-change copy and document both recovery points.

## Verification checklist

- [ ] Exact user/device/service/resource and scope were verified.
- [ ] Required authorization and support-tier boundaries were satisfied.
- [ ] Before-state evidence was captured.
- [ ] Diagnostics identified or narrowed the failing dependency before material changes.
- [ ] Only supported, least-disruptive actions were used.
- [ ] The user completes MFA with the approved method and the old method no longer works.
- [ ] device reports the expected management/compliance state
- [ ] corporate access works or is removed as intended
- [ ] personal data is not affected beyond the approved action
- [ ] Security, encryption, management, retention and access controls remain in the intended state.
- [ ] Rollback state and escalation evidence are documented.

## Escalation package

- Escalate to Mobility or Endpoint Engineering with the exact user or service impact, timestamps and timezone, affected assets, screenshots or error text, diagnostic results, logs, recent changes, remediation attempted, rollback status and a clear statement of what remains broken.
- Escalate to **Mobility or Endpoint Engineering** when the issue is outside the assigned tier, requires an unapproved privileged/destructive/production change, affects multiple users/sites/services, or remains unresolved after the targeted diagnostics.
- Include exact scope, timestamps/timezone, before/after evidence, relevant logs/error codes, commands or portal paths used, change/approval IDs, attempted remediation, rollback state and the failed verification criterion.

## Documentation assurance

This procedure has passed the ShiftStart documentation/technical-content quality gate. Production operational verification remains subject to live validation on the organization's actual platform, permissions, versions and change controls, plus technical-owner sign-off where required.
