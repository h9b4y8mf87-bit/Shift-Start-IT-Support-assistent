---
title: Review and remove stale VM snapshots safely
slug: review-and-remove-stale-vm-snapshots-safely
description: Enterprise runbook to review and remove stale vm snapshots safely without skipping evidence, verification, rollback
  or escalation requirements.
content_type: procedure
category: Cloud & Virtualisation
service: Cloud & Virtualisation
severity: medium
support_tier: L2-L3
owner_team: Cloud Platform or Virtualisation Operations
platforms:
- Azure
- AWS
- VMware
- Hyper-V
risk_level: medium
estimated_time: 15-45 minutes
tags:
- and
- cloud-and-virtualisation
- l2-l3
- remove
- review
- safely
- snapshots
- stale
- vm
error_codes: []
tldr: For review and remove stale vm snapshots safely, establish impact and change/incident ownership, capture before-state,
  prove the failing layer, use the lowest-blast-radius action with rollback ready, and verify dependencies plus a real business
  transaction.
related_symptoms:
- need-to-review-and-remove-stale-vm-snapshots-safely
- a-cloud-or-virtual-resource-is-degraded
symptom_weights:
  need-to-review-and-remove-stale-vm-snapshots-safely: 10
  a-cloud-or-virtual-resource-is-degraded: 3
related_causes: []
related_commands: []
next_steps: []
escalation: Escalate to Cloud Platform or Virtualisation Operations with scope, timestamps, evidence, actions, approvals,
  rollback state and failed verification criteria when the runbook reaches a stop condition or requires authority outside
  L2-L3.
last_reviewed: '2026-08-10'
review_cycle_days: 90
required_role: technician
approval_required: Follow the change/major-incident process for any production-impacting configuration, restart, failover,
  routing, firewall, VLAN, gateway or capacity action.
content_status: under_review
generated_baseline: false
reviewed_by: ''
last_tested: ''
tested_platforms: []
source_references:
- https://learn.microsoft.com/en-us/troubleshoot/azure/virtual-network/troubleshoot-vm-connectivity
- https://learn.microsoft.com/en-us/troubleshoot/azure/vpn-gateway/vpn-gateway-troubleshoot
- https://docs.aws.amazon.com/systems-manager/latest/userguide/session-manager-troubleshooting.html
change_record: 'Full-catalogue documentation remediation: replaced generic baseline flow with risk-aware, procedure-specific
  diagnostics, safety controls, remediation, rollback, verification and escalation guidance.'
quality_gate: passed
documentation_review: passed
documentation_reviewed_on: '2026-08-10'
live_validation_required: true
live_validation_note: Technical-owner live validation and environment-specific sign-off remain required; no live-test evidence
  is fabricated by this documentation pass.
permalink: /procedures/review-and-remove-stale-vm-snapshots-safely/
layout: article
risk_model: impact-v1
risk_basis: medium risk under the repository impact model; verification priority P2.
verification_priority: P2
verification_state: documentation_verified_pending_live_validation
---
## Purpose and scope

Enterprise runbook to review and remove stale vm snapshots safely without skipping evidence, verification, rollback or escalation requirements.

Use this runbook for cloud and virtualisation resources while preserving availability, auditability and least privilege. It is a support procedure, not authority to bypass change management, security policy, privacy/records obligations or the owning team's operational controls.

## Safety, authorisation and stop conditions

**Approval requirement:** Follow the change/major-incident process for any production-impacting configuration, restart, failover, routing, firewall, VLAN, gateway or capacity action.

- Verify the exact user, device, service, tenant/site or resource before making changes; use immutable identifiers where available.
- Work within the assigned support tier and use named administrative accounts or approved privileged-access elevation.
- Capture the current state before any change so the action and rollback can be reconstructed.
- Do not request or record passwords, MFA codes, recovery secrets, private keys, access tokens or other credentials in the ticket.
- Assess dependency, redundancy, active users/transactions and blast radius before production-impacting changes.
- Use the change or major-incident process for restart, failover, network/security-policy or capacity actions.
- Preserve diagnostics needed for root cause before resetting/restarting an infrastructure component.

## Evidence to capture before changes

- subscription/account/region and immutable resource ID
- resource health/status and recent activity/change log
- network, IAM and guest-OS state
- dependencies, redundancy/failover state and business impact
- monitoring metrics, platform diagnostics and exact timestamps

## Diagnostic path

- Review provider health, resource status, console diagnostics, network/security rules, identity, quota and recent changes. Confirm disks, snapshots and recovery options before restart or redeploy.
- check provider service/resource health before guest changes
- validate IAM, network security rules, routes, DNS and service listening state
- compare recent control-plane changes with symptom start time
- use provider diagnostic tooling and read-only console/agent paths before restart/reset

### Read-only or low-risk diagnostic commands

Use the owning platform's read-only health, audit, log or inventory views first. Do not introduce a configuration change merely to gather a baseline.

## Procedure

1. **Establish impact and change/incident owner.** Confirm affected service, users/sites, dependencies, redundancy/failover, business priority and the authorized change or major-incident record.

   **Expected result:** Requester, target asset/service, scope, authority and business impact are unambiguously identified and recorded before any material change.

2. **Capture stable before-state.** Record health, metrics, logs, recent changes, configuration snapshots/exports and current routing/service state as applicable.

   **Expected result:** A timestamped before-state is saved with the configuration, membership, health or data evidence needed to compare and, where possible, roll back.

3. **Diagnose the first failing layer.** Review provider health, resource status, console diagnostics, network/security rules, identity, quota and recent changes. Confirm disks, snapshots and recovery options before restart or redeploy.

   **Expected result:** Evidence narrows the fault to a specific layer, dependency, policy, component or control before remediation is attempted.

4. **Choose the lowest-blast-radius action.** Confirm each snapshot's owner, age, dependency and backup state. Remove only specifically approved stale snapshots and monitor consolidation/datastore impact.

   **Expected result:** Choose the lowest-blast-radius action produces a recorded, observable result for **Review and remove stale VM snapshots safely** that is consistent with the approved scope and can be compared with the before-state.

5. **Execute with rollback/failover ready.** Announce the action to the incident/change owner, make one controlled change, record the exact timestamp and stop if impact expands.

   **Expected result:** The smallest supported correction that addresses the proven cause is applied, with no unnecessary destructive or security-weakening side effect.

6. **Validate dependencies and service.** Check component health, replication/routes/listeners/metrics as applicable and run a real business transaction from the correct client/location.

   **Expected result:** Validate dependencies and service produces a recorded, observable result for **Review and remove stale VM snapshots safely** that is consistent with the approved scope and can be compared with the before-state.

7. **Verify the result.** Repeat the original business test using the normal user path and confirm: The resource is healthy, reachable and serving its intended workload.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

8. **Monitor for recurrence.** Check the relevant logs, management/service health or monitoring after the change. If the fault returns, do not repeat increasingly destructive fixes; preserve the new evidence and escalate.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

9. **Document and close or hand off.** Record before/after state, exact actions, timestamps, approvals, commands/portal paths used, verification result, rollback state and any follow-up owner.

   **Expected result:** The system or case is in the intended verified state and the result is recorded.

## Approved remediation principles

- Confirm each snapshot's owner, age, dependency and backup state. Remove only specifically approved stale snapshots and monitor consolidation/datastore impact.
- Apply the smallest supported platform action and preserve audit evidence. Use failover, recovery or provider support through incident/change control.
- prefer reversible control-plane or guest fixes with recorded before-state
- treat restart, redeploy, snapshot removal, gateway reset and access reset as change-controlled actions
- preserve logs/snapshots needed for root-cause analysis before disruptive actions

## Rollback and recovery

- Use the pre-defined configuration/failover rollback if service or blast radius worsens.
- If rollback risks wider outage or data inconsistency, stop and let the change/incident owner choose the recovery path.

## Verification checklist

- [ ] Exact user/device/service/resource and scope were verified.
- [ ] Required authorization and support-tier boundaries were satisfied.
- [ ] Before-state evidence was captured.
- [ ] Diagnostics identified or narrowed the failing dependency before material changes.
- [ ] Only supported, least-disruptive actions were used.
- [ ] The resource is healthy, reachable and serving its intended workload.
- [ ] resource health returns normal
- [ ] required application ports and business transactions succeed
- [ ] monitoring remains stable after the change
- [ ] Security, encryption, management, retention and access controls remain in the intended state.
- [ ] Rollback state and escalation evidence are documented.

## Escalation package

- Escalate to Cloud Platform or Virtualisation Operations with the exact user or service impact, timestamps and timezone, affected assets, screenshots or error text, diagnostic results, logs, recent changes, remediation attempted, rollback status and a clear statement of what remains broken.
- Escalate to **Cloud Platform or Virtualisation Operations** when the issue is outside the assigned tier, requires an unapproved privileged/destructive/production change, affects multiple users/sites/services, or remains unresolved after the targeted diagnostics.
- Include exact scope, timestamps/timezone, before/after evidence, relevant logs/error codes, commands or portal paths used, change/approval IDs, attempted remediation, rollback state and the failed verification criterion.

## Documentation assurance

This procedure has passed the ShiftStart documentation/technical-content quality gate. Production operational verification remains subject to live validation on the organization's actual platform, permissions, versions and change controls, plus technical-owner sign-off where required.
