# ShiftStart Source Library

**Documentation review date:** 2026-08-10  
**Snapshot commit:** `710e7731d63a7276d9f4e96cd2fb7c234208ac85`  
**Unique references used:** 50

This library records the authoritative/vendor/standards sources referenced by the remediated procedures. A source appearing here does not replace environment-specific version, licensing, role, policy or change-control validation during live operational testing.

## Organisation-local controls

- Local ITSM policy, SLA matrix, escalation matrix and change-management standard — referenced by 20 procedure(s)

## csrc.nist.gov

- https://csrc.nist.gov/pubs/sp/800/61/r3/final — referenced by 48 procedure(s)
- https://csrc.nist.gov/pubs/sp/800/86/final — referenced by 23 procedure(s)
- https://csrc.nist.gov/pubs/sp/800/88/r2/final — referenced by 34 procedure(s)

## docs.aws.amazon.com

- https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/TroubleshootingInstancesConnecting.html — referenced by 1 procedure(s)
- https://docs.aws.amazon.com/systems-manager/latest/userguide/session-manager-troubleshooting.html — referenced by 14 procedure(s)

## docs.citrix.com

- https://docs.citrix.com/en-us/citrix-workspace-app-for-windows/troubleshooting — referenced by 15 procedure(s)

## docs.docker.com

- https://docs.docker.com/desktop/troubleshoot-and-support/troubleshoot/ — referenced by 18 procedure(s)
- https://docs.docker.com/engine/daemon/troubleshoot/ — referenced by 2 procedure(s)

## documentation.ubuntu.com

- https://documentation.ubuntu.com/server/ — referenced by 18 procedure(s)

## git-scm.com

- https://git-scm.com/docs — referenced by 18 procedure(s)

## learn.microsoft.com

- https://learn.microsoft.com/en-us/defender-endpoint/respond-machine-alerts — referenced by 28 procedure(s)
- https://learn.microsoft.com/en-us/entra/identity/authentication/howto-mfa-userdevicesettings — referenced by 30 procedure(s)
- https://learn.microsoft.com/en-us/entra/identity/conditional-access/troubleshoot-conditional-access — referenced by 30 procedure(s)
- https://learn.microsoft.com/en-us/entra/identity/users/ — referenced by 30 procedure(s)
- https://learn.microsoft.com/en-us/graph/api/group-delete-members?view=graph-rest-1.0 — referenced by 1 procedure(s)
- https://learn.microsoft.com/en-us/graph/api/group-post-members?view=graph-rest-1.0 — referenced by 1 procedure(s)
- https://learn.microsoft.com/en-us/intune/device-management/ — referenced by 36 procedure(s)
- https://learn.microsoft.com/en-us/intune/device-management/actions/delete — referenced by 1 procedure(s)
- https://learn.microsoft.com/en-us/intune/device-management/actions/retire — referenced by 2 procedure(s)
- https://learn.microsoft.com/en-us/intune/remote-actions/device-wipe — referenced by 2 procedure(s)
- https://learn.microsoft.com/en-us/microsoftteams/rooms/rooms-operations — referenced by 16 procedure(s)
- https://learn.microsoft.com/en-us/powershell/module/activedirectory/add-adgroupmember?view=windowsserver2025-ps — referenced by 1 procedure(s)
- https://learn.microsoft.com/en-us/powershell/module/activedirectory/get-adgroupmember?view=windowsserver2025-ps — referenced by 1 procedure(s)
- https://learn.microsoft.com/en-us/powershell/module/activedirectory/remove-adgroupmember?view=windowsserver2025-ps — referenced by 1 procedure(s)
- https://learn.microsoft.com/en-us/troubleshoot/azure/virtual-desktop/welcome-virtual-desktop — referenced by 15 procedure(s)
- https://learn.microsoft.com/en-us/troubleshoot/azure/virtual-network/troubleshoot-vm-connectivity — referenced by 14 procedure(s)
- https://learn.microsoft.com/en-us/troubleshoot/azure/vpn-gateway/vpn-gateway-troubleshoot — referenced by 14 procedure(s)
- https://learn.microsoft.com/en-us/troubleshoot/microsoftteams/teams-rooms-and-devices/teams-rooms-known-issues-windows — referenced by 1 procedure(s)
- https://learn.microsoft.com/en-us/troubleshoot/sharepoint/ — referenced by 57 procedure(s)
- https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/networking-overview — referenced by 37 procedure(s)
- https://learn.microsoft.com/en-us/troubleshoot/windows-client/networking/tcp-ip-connectivity-issues-troubleshooting — referenced by 33 procedure(s)
- https://learn.microsoft.com/en-us/troubleshoot/windows-client/printing/printing-overview — referenced by 20 procedure(s)
- https://learn.microsoft.com/en-us/troubleshoot/windows-client/welcome-windows-client — referenced by 90 procedure(s)
- https://learn.microsoft.com/en-us/troubleshoot/windows-server/ — referenced by 25 procedure(s)
- https://learn.microsoft.com/en-us/troubleshoot/windows-server/networking/dns-server-troubleshooting — referenced by 25 procedure(s)
- https://learn.microsoft.com/en-us/windows/client-management/ — referenced by 48 procedure(s)
- https://learn.microsoft.com/en-us/windows/security/operating-system-security/data-protection/bitlocker/recovery-overview — referenced by 1 procedure(s)
- https://learn.microsoft.com/en-us/windows/security/operating-system-security/data-protection/bitlocker/recovery-process — referenced by 1 procedure(s)

## support.apple.com

- https://support.apple.com/guide/deployment/welcome/web — referenced by 36 procedure(s)

## support.google.com

- https://support.google.com/a/answer/10710447 — referenced by 1 procedure(s)
- https://support.google.com/a/answer/2618874 — referenced by 2 procedure(s)
- https://support.google.com/a/answer/6052340 — referenced by 1 procedure(s)
- https://support.google.com/chrome/answer/9281740 — referenced by 32 procedure(s)
- https://support.google.com/drive/answer/16482799 — referenced by 1 procedure(s)
- https://support.google.com/mail/answer/138350 — referenced by 1 procedure(s)
- https://support.google.com/meet/answer/10620583 — referenced by 10 procedure(s)

## support.zoom.com

- https://support.zoom.com/ — referenced by 16 procedure(s)

## www.cisa.gov

- https://www.cisa.gov/stopransomware/ransomware-guide — referenced by 1 procedure(s)

## www.rfc-editor.org

- https://www.rfc-editor.org/rfc/rfc9110.html — referenced by 22 procedure(s)
