# Integrated ShiftStart documentation + production-readiness package

This package combines the full 421-procedure documentation pass with the production-readiness governance already present on ShiftStart `main`.

## Why this integrated edition exists

The full documentation pass uses a richer runbook structure than the earlier `enterprise-v1` five-heading validator.

Without this compatibility layer:

- the documentation verifier would report 421/421 passing;
- but `npm run check` could fail because `scripts/validate-readiness.js` still expected only the older five exact headings;
- and running the old `readiness:apply` could overwrite the documentation pass's reviewed verification-state wording.

This edition reconciles those systems.

## Preserved results from the documentation pass

- Procedures: 421
- Documentation gate: 421/421
- Status: 410 under review / 11 verified
- Risk:
  - Critical: 17
  - High: 228
  - Medium: 175
  - Low: 1
- Priorities:
  - P0: 17
  - P1: 228
  - P2: 175
  - P3: 1

Documentation approval is **not** treated as production live validation.

## Apply

From the repository root, unzip this package, then run:

```bash
python3 \
  ShiftStart_All_Procedures_Documentation_Integrated_2026-08-10/tools/apply_integrated_documentation_pass.py \
  .
```

Because the package was audited from commit:

```text
710e7731d63a7276d9f4e96cd2fb7c234208ac85
```

the guarded installer will stop if HEAD has moved. If you knowingly made newer changes after that commit, review them first and then use:

```bash
python3 \
  ShiftStart_All_Procedures_Documentation_Integrated_2026-08-10/tools/apply_integrated_documentation_pass.py \
  . \
  --allow-head-mismatch
```

Then run:

```bash
npm install --no-audit --no-fund
npm run check
```

If the checks pass:

```bash
git add -A
git status
git commit -m "Apply full procedure documentation verification pass"
git push origin main
```

## Promotion to verified

Do not change a new procedure to `verified` merely because its documentation passes.

Record real evidence:

```yaml
verification_evidence:
  diagnostic_tested: true
  remediation_tested: true
  rollback_confirmed: true
  escalation_confirmed: true
  time_validated: true
  owner_signoff: "Named technical owner / change record"
last_tested: 2026-08-10
tested_platforms:
  - "Actual tested platform/version/build"
```

Then:

```bash
npm run readiness:promote
npm run check
```

The promotion tool now additionally requires the procedure's documentation gate to have passed.
