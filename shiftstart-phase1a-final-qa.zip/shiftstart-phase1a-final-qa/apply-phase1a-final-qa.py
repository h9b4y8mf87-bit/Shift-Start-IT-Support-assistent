#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime, timezone
import csv, json, shutil, sys

ROOT = Path.cwd()
PKG = Path(__file__).resolve().parent
PAYLOAD = PKG / 'payload'
EXPECTED_PROCEDURES = 421
EXPECTED_SYMPTOMS = 446
EXPECTED_DETERMINISTIC = 192
VALID_TYPES = {'observable_symptom','service_request','known_condition','context','incident_event'}
CORRECTIONS = {
    'a-default-gateway-failure': ('observable_symptom','known_condition',
        'Final QA: the record names the default gateway as the identified failing network condition rather than only reporting loss of connectivity.'),
    'memory-hardware-errors': ('observable_symptom','known_condition',
        'Final QA: memory hardware errors indicate an identified hardware condition; downstream symptoms such as crashes or boot failures remain observable symptoms.'),
    'reported-an-expiring-tls-certificate': ('incident_event','known_condition',
        'Final QA: an expiring TLS certificate is a known lifecycle/configuration condition requiring planned remediation, not an incident merely because it was reported.'),
    'vpn-certificate-failure': ('observable_symptom','known_condition',
        "Final QA: the record already identifies certificate failure as the VPN authentication condition; 'VPN fails to connect' remains the observable symptom."),
}

def fail(msg):
    print(f'ERROR: {msg}', file=sys.stderr); sys.exit(1)

def md_count(name):
    return len(list((ROOT/name).glob('*.md')))

def backup(path, dest):
    if path.exists():
        out = dest / path.relative_to(ROOT); out.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(path, out)

if not (ROOT/'package.json').exists() or not (ROOT/'_symptoms').is_dir(): fail('run from the ShiftStart repository root')
if md_count('_procedures') != EXPECTED_PROCEDURES: fail(f'expected {EXPECTED_PROCEDURES} procedures, found {md_count("_procedures")}')
if md_count('_symptoms') != EXPECTED_SYMPTOMS: fail(f'expected {EXPECTED_SYMPTOMS} symptoms, found {md_count("_symptoms")}')

csv_path = ROOT/'reports/symptom-taxonomy-v2.csv'
report_path = ROOT/'reports/symptom-taxonomy-v2.json'
overrides_path = ROOT/'_data/symptom-taxonomy-v2-overrides.json'
builder_path = ROOT/'scripts/build-symptom-taxonomy-v2.js'
package_path = ROOT/'package.json'
taxonomy_doc = ROOT/'docs/knowledge-model/PHASE-1A-TAXONOMY-V2.md'
pass1_doc = ROOT/'docs/knowledge-model/PHASE-1A-REVIEW-PASS-1.md'
validator_path = ROOT/'scripts/validate-symptom-taxonomy-v2-final-qa.js'
final_doc = ROOT/'docs/knowledge-model/PHASE-1A-FINAL-QA.md'
for p in (csv_path,report_path,overrides_path,builder_path,package_path,taxonomy_doc,pass1_doc):
    if not p.exists(): fail(f'required file missing: {p}')

with csv_path.open(newline='', encoding='utf-8') as fh:
    rows = list(csv.DictReader(fh))
if len(rows) != EXPECTED_SYMPTOMS: fail(f'expected 446 taxonomy rows, found {len(rows)}')
if any(str(r.get('review_required','')).lower() == 'true' for r in rows): fail('review_required must already be false for all 446 records')
deterministic = [r for r in rows if r.get('classification_origin') == 'deterministic_v2']
if len(deterministic) not in (0, EXPECTED_DETERMINISTIC): fail(f'expected 192 deterministic records before QA or 0 after rebuild; found {len(deterministic)}')
by_slug = {r['slug']: r for r in rows}
for slug,(old,new,_) in CORRECTIONS.items():
    r = by_slug.get(slug)
    if not r: fail(f'missing correction slug {slug}')
    if deterministic:
        if r.get('classification_origin') != 'deterministic_v2' or r.get('object_type') != old: fail(f'{slug}: baseline no longer matches expected {old}')
    elif r.get('object_type') != new: fail(f'{slug}: expected final type {new}, found {r.get("object_type")}')

overrides = json.loads(overrides_path.read_text(encoding='utf-8'))
records = overrides.setdefault('records', {})
overrides['description'] = 'Explicitly reviewed Phase 1A taxonomy overrides. Do not use this file for incident priority or execution risk.'
added = existing = 0
for r in deterministic:
    slug = r['slug']; current = r['object_type']
    final = CORRECTIONS.get(slug, (None,current,None))[1]
    if final not in VALID_TYPES: fail(f'{slug}: invalid final type {final}')
    prior = records.get(slug)
    if prior:
        if prior.get('object_type') != final or prior.get('reviewed') is not True: fail(f'{slug}: conflicting existing override')
        existing += 1; continue
    reason = CORRECTIONS[slug][2] if slug in CORRECTIONS else f'Phase 1A Final QA: reviewed deterministic classification and confirmed {final}.'
    records[slug] = {'object_type':final,'reviewed':True,'confidence':'high','reason':reason,'review_source':'Phase 1A Final QA'}
    added += 1
if len(records) != EXPECTED_SYMPTOMS: fail(f'final override ledger should contain 446 records, found {len(records)}')

builder = builder_path.read_text(encoding='utf-8')
anchor = 'const KNOWN_CONDITION_PATTERNS = [\n'
new_patterns = '  /\\bdefault gateway failure\\b/,\n  /\\bexpiring tls certificate\\b/,\n  /\\bmemory hardware errors?\\b/,\n  /\\bvpn certificate failure\\b/,\n'
if '/\\bdefault gateway failure\\b/' not in builder:
    if anchor not in builder: fail('taxonomy known-condition pattern anchor changed')
    builder = builder.replace(anchor, anchor+new_patterns, 1)

known_block = '  if (KNOWN_CONDITION_PATTERNS.some((pattern) => pattern.test(title))) {\n    return classification("known_condition", "high", "Title states a technical condition/diagnosis rather than an initial observation.");\n  }\n\n'
incident = '  if (\n    title.startsWith("reported ") ||\n    INCIDENT_EVENT_PATTERNS.some((pattern) => pattern.test(title))\n  ) {\n    return classification("incident_event", "high", "Explicit incident/security/outage event language.");\n  }\n\n'
if 'Known technical conditions outrank generic reported/event wording.' not in builder:
    if incident not in builder: fail('taxonomy incident classifier anchor changed')
    builder = builder.replace(incident, '  // Known technical conditions outrank generic reported/event wording.\n'+known_block+incident, 1)
    first = builder.find(known_block); second = builder.find(known_block, first+len(known_block))
    if second < 0: fail('could not remove later duplicate known-condition block')
    builder = builder[:second] + builder[second+len(known_block):]

old_counts = 'const counts = {};\nlet reviewRequired = 0;\nfor (const record of Object.values(records)) {\n  counts[record.objectType] = (counts[record.objectType] || 0) + 1;\n  if (record.reviewRequired) reviewRequired += 1;\n}\n'
new_counts = 'const counts = {};\nlet reviewRequired = 0;\nlet explicitReviewed = 0;\nfor (const record of Object.values(records)) {\n  counts[record.objectType] = (counts[record.objectType] || 0) + 1;\n  if (record.reviewRequired) reviewRequired += 1;\n  if (record.classificationOrigin === "review_override") explicitReviewed += 1;\n}\n'
if 'let explicitReviewed = 0;' not in builder:
    if old_counts not in builder: fail('taxonomy review-count anchor changed')
    builder = builder.replace(old_counts,new_counts,1)
old_review = '  review: {\n    reviewed: symptoms.length - reviewRequired,\n    reviewRequired,\n    completionPercent: symptoms.length ? Math.round(((symptoms.length - reviewRequired) / symptoms.length) * 1000) / 10 : 0\n  },\n'
new_review = '  review: {\n    reviewed: symptoms.length - reviewRequired,\n    reviewRequired,\n    completionPercent: symptoms.length ? Math.round(((symptoms.length - reviewRequired) / symptoms.length) * 1000) / 10 : 0,\n    explicitReviewed,\n    explicitReviewRequired: symptoms.length - explicitReviewed,\n    explicitCompletionPercent: symptoms.length ? Math.round((explicitReviewed / symptoms.length) * 1000) / 10 : 0\n  },\n'
if 'explicitReviewRequired:' not in builder:
    if old_review not in builder: fail('taxonomy review payload anchor changed')
    builder = builder.replace(old_review,new_review,1)
log = 'console.log(`Reviewed/accepted: ${payload.review.reviewed}; review required: ${reviewRequired}.`);'
if 'Explicit review overrides:' not in builder:
    if log not in builder: fail('taxonomy console anchor changed')
    builder = builder.replace(log, log+'\nconsole.log(`Explicit review overrides: ${payload.review.explicitReviewed}; deterministic-only: ${payload.review.explicitReviewRequired}.`);',1)

pkg = json.loads(package_path.read_text(encoding='utf-8'))
scripts = pkg.setdefault('scripts',{})
scripts['taxonomy:v2:qa:check'] = 'node scripts/validate-symptom-taxonomy-v2-final-qa.js'
needle = 'npm run taxonomy:v2:build && npm run taxonomy:v2:check'
if 'npm run taxonomy:v2:qa:check' not in scripts.get('check',''):
    if needle not in scripts.get('check',''): fail('package check taxonomy anchor changed')
    scripts['check'] = scripts['check'].replace(needle, needle+' && npm run taxonomy:v2:qa:check',1)

p1 = pass1_doc.read_text(encoding='utf-8')
old = 'The 197 records previously accepted by deterministic high-confidence rules are not silently treated as independently human-audited by this document. They should receive a separate QA pass before the taxonomy is frozen as the final Knowledge Model v2 baseline.'
new = 'The 197 records already accepted before this pass comprised 192 deterministic high-confidence classifications plus 5 pre-existing explicit review overrides. The remaining 192 deterministic-only records require a separate final QA pass before the taxonomy is frozen as the Knowledge Model v2 baseline.'
if old in p1: p1 = p1.replace(old,new,1)
elif new not in p1: fail('Review Pass 1 bookkeeping paragraph changed unexpectedly')

tdoc = taxonomy_doc.read_text(encoding='utf-8')
section = '''\n## Final QA\n\nClearing `review_required` is necessary but is not, by itself, evidence that every accepted deterministic classification received an explicit QA decision.\n\nAfter Review Pass 1, run the Phase 1A Final QA over the remaining deterministic-only records. The final authoritative baseline requires:\n\n- all 446 records to have `classificationOrigin: review_override`;\n- all 446 records to have a non-empty review source;\n- `explicitReviewed: 446`;\n- `explicitReviewRequired: 0`;\n- `npm run taxonomy:v2:qa:check` to pass.\n\n'''
if '## Final QA' not in tdoc:
    if '## Completion gate\n' not in tdoc: fail('taxonomy completion heading changed')
    tdoc = tdoc.replace('## Completion gate\n',section+'## Completion gate\n',1)
if 'the final QA validator reports 446 explicit reviews' not in tdoc:
    bullet='- every record has been reviewed/accepted;\n'
    if bullet not in tdoc: fail('taxonomy completion review bullet changed')
    tdoc=tdoc.replace(bullet,bullet+'- every record has an explicit reviewed override and review source;\n- the final QA validator reports 446 explicit reviews and 0 deterministic-only records;\n',1)

stamp=datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S'); bdir=ROOT/'.shiftstart-backups'/f'phase1a-final-qa-{stamp}'; bdir.mkdir(parents=True,exist_ok=True)
for p in (overrides_path,builder_path,package_path,taxonomy_doc,pass1_doc,validator_path,final_doc): backup(p,bdir)

overrides['records']=dict(sorted(records.items())); overrides_path.write_text(json.dumps(overrides,indent=2)+'\n',encoding='utf-8')
builder_path.write_text(builder,encoding='utf-8'); package_path.write_text(json.dumps(pkg,indent=2)+'\n',encoding='utf-8')
taxonomy_doc.write_text(tdoc,encoding='utf-8'); pass1_doc.write_text(p1,encoding='utf-8')
validator_path.write_text((PAYLOAD/'scripts/validate-symptom-taxonomy-v2-final-qa.js').read_text(encoding='utf-8'),encoding='utf-8')
final_doc.write_text((PAYLOAD/'docs/knowledge-model/PHASE-1A-FINAL-QA.md').read_text(encoding='utf-8'),encoding='utf-8')

if md_count('_procedures') != EXPECTED_PROCEDURES or md_count('_symptoms') != EXPECTED_SYMPTOMS: fail('source record count changed unexpectedly')
print('ShiftStart Phase 1A Final QA applied.')
print(f'Deterministic-only records in pre-QA report: {len(deterministic)}')
print(f'New final-QA override entries added: {added}')
print(f'Final-QA overrides already present: {existing}')
print('Confirmed unchanged classifications: 188')
print('Corrected classifications: 4')
for slug,(old,new,_) in CORRECTIONS.items(): print(f' - {slug}: {old} -> {new}')
print('Procedure source files modified: 0')
print('Symptom source files modified: 0')
print('Expected final counts: observable_symptom=204, service_request=119, known_condition=60, context=40, incident_event=23')
print('Expected explicit review: 446/446; deterministic-only: 0')
print(f'Backup: {bdir}')
print('\nNEXT:\n  nvm use 22\n  npm ci --no-audit --no-fund   # only if dependencies are missing\n  npm run taxonomy:v2:build\n  npm run taxonomy:v2:check\n  npm run taxonomy:v2:qa:check\n  npm run check\n  npm run build\n  python3 scripts/clean-pages-artifact.py --check\n  git status --short')
