# ShiftStart Phase 1A — Final QA

This patch completes the catalogue QA step that follows Review Pass 1.

## Baseline correction

The earlier `197 accepted` figure included **192 deterministic high-confidence records plus 5 pre-existing explicit review overrides**. This package QA-reviews the remaining 192 deterministic-only records.

## Result encoded by this patch

- 188 deterministic classifications confirmed unchanged.
- 4 classifications corrected.
- 446 explicit reviewed overrides after apply/rebuild.
- 0 deterministic-only records after apply/rebuild.
- 421 procedures preserved.
- 446 legacy symptom records and URLs preserved.
- No `_procedures/*.md` or `_symptoms/*.md` files are modified.
- Verification v2 promotion metadata is untouched.

## Apply

From the repository root:

```bash
unzip -q -o shiftstart-phase1a-final-qa.zip
python3 shiftstart-phase1a-final-qa/apply-phase1a-final-qa.py
```

Then:

```bash
nvm use 22
npm ci --no-audit --no-fund   # only if dependencies are missing

npm run taxonomy:v2:build
npm run taxonomy:v2:check
npm run taxonomy:v2:qa:check
npm run check
npm run build
python3 scripts/clean-pages-artifact.py --check
git status --short
```

Expected final taxonomy:

```text
observable_symptom  204
service_request     119
known_condition      60
context              40
incident_event       23
total                446

reviewed                 446
review required            0
explicit reviewed        446
deterministic-only         0
```

Do not commit until the QA validator, full check and production build all pass.
