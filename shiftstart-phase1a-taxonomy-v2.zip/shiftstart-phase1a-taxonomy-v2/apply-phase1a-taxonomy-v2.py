#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime, timezone
import json
import shutil
import sys

ROOT = Path.cwd()
PACKAGE = Path(__file__).resolve().parent
PAYLOAD = PACKAGE / "payload"

EXPECTED_PROCEDURES = 421
EXPECTED_SYMPTOMS = 446

def fail(message):
    print(f"ERROR: {message}", file=sys.stderr)
    sys.exit(1)

if not (ROOT / "package.json").exists() or not (ROOT / "_symptoms").is_dir():
    fail("run this installer from the ShiftStart repository root")

procedure_count = len(list((ROOT / "_procedures").glob("*.md")))
symptom_count = len(list((ROOT / "_symptoms").glob("*.md")))
if procedure_count != EXPECTED_PROCEDURES:
    fail(f"expected {EXPECTED_PROCEDURES} procedures; found {procedure_count}")
if symptom_count != EXPECTED_SYMPTOMS:
    fail(f"expected {EXPECTED_SYMPTOMS} symptom records; found {symptom_count}")

pkg_path = ROOT / "package.json"
wizard_path = ROOT / "scripts" / "generate-wizard.js"
if not wizard_path.exists():
    fail("scripts/generate-wizard.js is missing")

pkg = json.loads(pkg_path.read_text(encoding="utf-8"))
scripts = pkg.get("scripts", {})

expected_generate = "node scripts/generate-wizard.js && node scripts/generate-search-data.js"
already_generate = "npm run taxonomy:v2:build && node scripts/generate-wizard.js && node scripts/generate-search-data.js"
current_generate = scripts.get("generate", "")
if current_generate not in {expected_generate, already_generate}:
    fail(f"package.json generate script has changed unexpectedly: {current_generate}")

if "taxonomy:v2:build" not in scripts:
    scripts["taxonomy:v2:build"] = "node scripts/build-symptom-taxonomy-v2.js"
if "taxonomy:v2:check" not in scripts:
    scripts["taxonomy:v2:check"] = "node scripts/validate-symptom-taxonomy-v2.js"
scripts["generate"] = already_generate

check = scripts.get("check", "")
taxonomy_prefix = "npm run taxonomy:v2:build && npm run taxonomy:v2:check && "
if "npm run taxonomy:v2:check" not in check:
    scripts["check"] = taxonomy_prefix + check
pkg["scripts"] = scripts

wizard = wizard_path.read_text(encoding="utf-8")

if 'const taxonomyPath = path.join("reports", "symptom-taxonomy-v2.json");' not in wizard:
    anchor = 'const symptoms = readCollection("_symptoms");\nconst procedures = readCollection("_procedures");\n'
    if anchor not in wizard:
        fail("generate-wizard.js collection anchor not found; no changes made")
    replacement = anchor + r'''
const taxonomyPath = path.join("reports", "symptom-taxonomy-v2.json");
if (!fs.existsSync(taxonomyPath)) {
  throw new Error("Phase 1A taxonomy report missing. Run npm run taxonomy:v2:build first.");
}
const taxonomy = JSON.parse(fs.readFileSync(taxonomyPath, "utf8"));
const taxonomyRecords = taxonomy.records || {};
for (const symptom of symptoms) {
  if (!taxonomyRecords[symptom.slug]) {
    throw new Error(`Missing Phase 1A taxonomy record for ${symptom.slug}`);
  }
}
'''
    wizard = wizard.replace(anchor, replacement, 1)

if "const objectTypeCounts = symptoms.reduce" not in wizard:
    anchor = '''const statusCounts = procedures.reduce((acc, procedure) => {
  const status = effectiveProcedureStatus(procedure.data);
  acc[status] = (acc[status] || 0) + 1;
  return acc;
}, {});
'''
    if anchor not in wizard:
        fail("generate-wizard.js status-count anchor not found")
    replacement = anchor + r'''
const objectTypeCounts = symptoms.reduce((acc, symptom) => {
  const type = taxonomyRecords[symptom.slug].objectType;
  acc[type] = (acc[type] || 0) + 1;
  return acc;
}, {});
'''
    wizard = wizard.replace(anchor, replacement, 1)

wizard = wizard.replace("schemaVersion: 4,", "schemaVersion: 5,", 1)
wizard = wizard.replace(
    "counts: { symptoms: symptoms.length, procedures: procedures.length, statuses: statusCounts },",
    "counts: { symptoms: symptoms.length, procedures: procedures.length, statuses: statusCounts, objectTypes: objectTypeCounts },",
    1
)

if "objectTypes: taxonomy.objectTypes || []" not in wizard:
    wizard = wizard.replace(
        'categories: [...new Set(symptoms.map((symptom) => symptom.data.category || "Other"))].sort(),',
        'objectTypes: taxonomy.objectTypes || [],\n  categories: [...new Set(symptoms.map((symptom) => symptom.data.category || "Other"))].sort(),',
        1
    )

if "objectType: taxonomyRecords[symptom.slug].objectType" not in wizard:
    anchor = '''    severity: symptom.data.severity || "medium",
    tags: symptom.data.tags || [],
'''
    if anchor not in wizard:
        fail("generate-wizard.js symptom-field anchor not found")
    replacement = '''    severity: symptom.data.severity || "medium",
    legacySeverity: symptom.data.severity || "medium",
    objectType: taxonomyRecords[symptom.slug].objectType,
    taxonomyConfidence: taxonomyRecords[symptom.slug].confidence,
    taxonomyReviewRequired: taxonomyRecords[symptom.slug].reviewRequired,
    tags: symptom.data.tags || [],
'''
    wizard = wizard.replace(anchor, replacement, 1)

stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
backup = ROOT / ".shiftstart-backups" / f"phase1a-taxonomy-v2-{stamp}"
backup.mkdir(parents=True, exist_ok=True)
for rel in ["package.json", "scripts/generate-wizard.js"]:
    target = ROOT / rel
    b = backup / rel
    b.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(target, b)

for rel in [
    "scripts/build-symptom-taxonomy-v2.js",
    "scripts/validate-symptom-taxonomy-v2.js",
    "_data/symptom-taxonomy-v2-overrides.json",
    "docs/knowledge-model/PHASE-1A-TAXONOMY-V2.md",
]:
    src = PAYLOAD / rel
    dst = ROOT / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        existing = dst.read_bytes()
        incoming = src.read_bytes()
        if existing != incoming:
            fail(f"{rel} already exists with different content; re-audit before overwriting")
    else:
        shutil.copy2(src, dst)

pkg_path.write_text(json.dumps(pkg, indent=2) + "\n", encoding="utf-8")
wizard_path.write_text(wizard, encoding="utf-8")

if len(list((ROOT / "_procedures").glob("*.md"))) != EXPECTED_PROCEDURES:
    fail("procedure count changed unexpectedly")
if len(list((ROOT / "_symptoms").glob("*.md"))) != EXPECTED_SYMPTOMS:
    fail("symptom source count changed unexpectedly")

print("ShiftStart Phase 1A taxonomy foundation applied.")
print("Procedure source files modified: 0")
print("Symptom source files modified: 0")
print(f"Procedures preserved: {EXPECTED_PROCEDURES}")
print(f"Legacy symptom records/URLs preserved: {EXPECTED_SYMPTOMS}")
print(f"Backup: {backup}")
print()
print("NEXT:")
print("  nvm use 22")
print("  npm ci --no-audit --no-fund   # only if node_modules is missing")
print("  npm run taxonomy:v2:build")
print("  npm run taxonomy:v2:check")
print("  npm run check")
print("  npm run build")
print("  git status --short")
