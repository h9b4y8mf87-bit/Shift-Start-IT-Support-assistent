# ShiftStart Phase 1A — Taxonomy v2

This patch starts Knowledge Model v2 without deleting or renaming any existing symptom record.

It introduces five object types:

- Observable symptom
- Service request
- Known condition / diagnosis
- Context
- Incident / event

## Safety

The patch preserves:

- 421 `_procedures/*.md` files
- 446 `_symptoms/*.md` files
- all existing `/symptoms/.../` URLs
- current verification-v2 governance
- current procedure ranking logic

It does **not** yet change incident priority or execution risk.

## Apply

From the repository root:

```bash
unzip -q -o shiftstart-phase1a-taxonomy-v2.zip
python3 shiftstart-phase1a-taxonomy-v2/apply-phase1a-taxonomy-v2.py
```

Then:

```bash
nvm use 22
npm ci --no-audit --no-fund   # only if dependencies are not already installed
npm run taxonomy:v2:build
npm run taxonomy:v2:check
npm run check
npm run build
git status --short
```

## What to send back

After `taxonomy:v2:build`, send the lines beginning:

- `Object types:`
- `Reviewed/accepted:`

That gives the first complete 446-record taxonomy distribution and tells us how large the manual-review queue is.

Do not commit until the full checks pass.
