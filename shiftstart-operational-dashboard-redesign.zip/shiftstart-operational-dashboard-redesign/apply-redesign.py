#!/usr/bin/env python3
from pathlib import Path
import shutil, sys

repo = Path.cwd()
patch = Path(__file__).resolve().parent
payload = patch / 'payload'

required = [repo/'_layouts'/'default.html', repo/'_layouts'/'article.html', repo/'_layouts'/'list.html', repo/'_includes'/'header.html', repo/'index.html']
missing = [str(p) for p in required if not p.exists()]
if missing:
    print('ERROR: Run this script from the ShiftStart repository root.', file=sys.stderr)
    for item in missing:
        print('-', item, file=sys.stderr)
    raise SystemExit(1)

protected = ['_procedures','_symptoms','_causes','_commands']
before = {name: len(list((repo/name).glob('*.md'))) if (repo/name).exists() else 0 for name in protected}

for source in payload.rglob('*'):
    if not source.is_file():
        continue
    relative = source.relative_to(payload)
    target = repo / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    print('Updated:', relative)

after = {name: len(list((repo/name).glob('*.md'))) if (repo/name).exists() else 0 for name in protected}
if before != after:
    print('ERROR: Protected knowledge collections changed.', file=sys.stderr)
    print('Before:', before, file=sys.stderr)
    print('After:', after, file=sys.stderr)
    raise SystemExit(1)

checks = {
    'index.html': ['Search by symptom','Launch symptom wizard','rd-domain-grid','Critical &amp; high-risk procedures'],
    '_includes/header.html': ['/wizard/','/about/','rd-global-search','Home','Procedures'],
    '_layouts/list.html': ['data-catalog-risk','data-catalog-status','data-catalog-tier','data-catalog-sort'],
    '_layouts/article.html': ['rd-article-layout','data-article-toc','Escalation path','Create pre-filled ITSM ticket'],
    'wizard.html': ['wizard-root','/assets/data/wizard-data.json'],
    'search.html': ['data-search-page','data-search-page-results'],
    'about.html': ['About ShiftStart','Operating principles'],
    'style-guide.html': ['ShiftStart style guide','Risk badges'],
    'assets/js/redesign.js': ['initCatalogue','initArticle','initSearchPage','initOnboarding'],
    'assets/js/search.js': ['View all results','supportTier','contentStatus'],
    'scripts/generate-search-data.js': ['supportTier','ownerTeam','estimatedTime'],
}
for rel, tokens in checks.items():
    path = repo / rel
    if not path.exists():
        print(f'ERROR: Missing {rel}', file=sys.stderr)
        raise SystemExit(1)
    text = path.read_text(encoding='utf-8')
    absent = [token for token in tokens if token not in text]
    if absent:
        print(f'ERROR: {rel} missing expected markers: {absent}', file=sys.stderr)
        raise SystemExit(1)

print()
print('Operational dashboard redesign applied successfully.')
print('Protected knowledge collections:', before)
print('Added dedicated Home, Procedures, Wizard, Search, About and Style Guide experiences.')
print('Preserved symptom relationships, content governance and all Markdown knowledge.')
