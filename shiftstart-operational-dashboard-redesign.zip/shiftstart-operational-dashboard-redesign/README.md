# ShiftStart operational dashboard redesign

This patch implements the supplied redesign brief as a functional Jekyll redesign rather than a static mockup.

## What changes

- Dashboard-style homepage instead of an all-features information dump.
- Sticky operational header with a large global search.
- Dedicated Symptom Wizard page.
- Dedicated Search Results page.
- Dedicated About page.
- Internal Style Guide page.
- Priority critical/high-risk procedure section.
- Domain tiles generated from the live repository.
- Procedure catalogue filtering by domain, risk, review status and tier.
- Procedure sorting by name, risk and verified status.
- Breadcrumbs and back-to-results navigation.
- Procedure pages with strong risk/trust hierarchy and sticky section navigation.
- First-use onboarding.
- Search results enriched with risk, review status, support tier and owner metadata.
- Mobile, keyboard, reduced-motion, forced-colour and print support.

## What is preserved

The patch does not touch any Markdown file in `_procedures`, `_symptoms`, `_causes` or `_commands`.
The current base site, claymorphism and controlled-support fusion styles remain loaded; `redesign.css` is the final hierarchy and information-architecture layer.

## Apply in Codespaces

```bash
git fetch origin
git pull --rebase origin main

unzip -q shiftstart-operational-dashboard-redesign.zip

python3 \
  shiftstart-operational-dashboard-redesign/apply-redesign.py

npm install --no-audit --no-fund
npm run check

rm -f shiftstart-operational-dashboard-redesign.zip
rm -rf shiftstart-operational-dashboard-redesign

git add -A
git status
git commit -m "Redesign ShiftStart as operational support dashboard"
git push origin main
```
