---
title: A room mailbox
slug: a-room-mailbox
description: 'Observable report: A room mailbox. Select it with any other symptoms to receive ranked procedures.'
content_type: symptom
category: Microsoft 365 & Collaboration
severity: medium
tags:
- microsoft-365-and-collaboration
- troubleshoot-a-room-mailbox
related_procedures:
- troubleshoot-a-room-mailbox
permalink: /symptoms/a-room-mailbox/
layout: article
last_reviewed: '2026-08-02'
---

## What to capture
Record the exact wording, affected users and devices, timestamps, error messages, screenshots, recent changes and business impact. Select this symptom together with every other observed symptom in the wizard; the matcher ranks procedures by combined evidence rather than forcing a single yes/no path.

## Immediate safety check
Escalate immediately when the report involves personal safety, smoke, heat, swelling batteries, suspected compromise, data exposure, ransomware, widespread outage or a critical business deadline.

## Linked procedures
The related-procedure cards below are generated from front matter. Start with the highest-ranked wizard result and verify each expected outcome before moving to a more invasive action.
