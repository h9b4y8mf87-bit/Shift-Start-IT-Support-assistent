#!/usr/bin/env python3
from pathlib import Path
import shutil, sys

repo = Path.cwd()
patch = Path(__file__).resolve().parent

required = [
    repo / "index.html",
    repo / "assets" / "css" / "operational-hardening.css",
    repo / "assets" / "js" / "operational-hardening.js",
]
missing = [str(p) for p in required if not p.exists()]
if missing:
    print("ERROR: Run this from the ShiftStart repository root.", file=sys.stderr)
    for item in missing:
        print("-", item, file=sys.stderr)
    raise SystemExit(1)

protected = ["_procedures", "_symptoms", "_causes", "_commands"]
before = {
    name: len(list((repo / name).glob("*.md"))) if (repo / name).exists() else 0
    for name in protected
}

# Replace only the homepage template.
shutil.copy2(patch / "files" / "index.html", repo / "index.html")
print("Updated: index.html")

def replace_marker(target, source, start_marker, end_marker):
    text = target.read_text(encoding="utf-8")
    addition = source.read_text(encoding="utf-8").strip()
    if start_marker in text and end_marker in text:
        start = text.index(start_marker)
        end = text.index(end_marker, start) + len(end_marker)
        text = text[:start] + addition + text[end:]
    else:
        text = text.rstrip() + "\n\n" + addition + "\n"
    target.write_text(text, encoding="utf-8")

replace_marker(
    repo / "assets" / "css" / "operational-hardening.css",
    patch / "files" / "homepage-polish.css",
    "/* === ShiftStart homepage + mobile polish === */",
    "/* === End ShiftStart homepage + mobile polish === */",
)
print("Updated: assets/css/operational-hardening.css")

replace_marker(
    repo / "assets" / "js" / "operational-hardening.js",
    patch / "files" / "homepage-polish.js",
    "/* === ShiftStart homepage + mobile polish === */",
    "/* === End ShiftStart homepage + mobile polish === */",
)
print("Updated: assets/js/operational-hardening.js")

after = {
    name: len(list((repo / name).glob("*.md"))) if (repo / name).exists() else 0
    for name in protected
}
if before != after:
    raise SystemExit(f"ERROR: Protected knowledge counts changed. Before={before} After={after}")

checks = {
    "index.html": [
        "rd-hero-trust-cue",
        "rd-home-priority-card",
        "data-priority-domains",
        "data-domain-toggle",
        "Search by symptom",
        "Launch symptom wizard",
    ],
    "assets/css/operational-hardening.css": [
        "ShiftStart homepage + mobile polish",
        ".rd-global-search",
        ".rd-primary-cta",
        ".rd-secondary-cta",
    ],
    "assets/js/operational-hardening.js": [
        "ShiftStart homepage + mobile polish",
        "initPriorityDomains",
        "collapsedCount",
    ],
}
for rel, tokens in checks.items():
    text = (repo / rel).read_text(encoding="utf-8")
    absent = [token for token in tokens if token not in text]
    if absent:
        raise SystemExit(f"ERROR: {rel} missing required markers: {absent}")

print("")
print("Homepage and mobile refinement applied successfully.")
print("Preserved knowledge collections:", before)
print("Applied: dominant Search/Wizard CTAs, simplified priority cards, top-five domain view, hero trust cue and always-visible mobile search.")
