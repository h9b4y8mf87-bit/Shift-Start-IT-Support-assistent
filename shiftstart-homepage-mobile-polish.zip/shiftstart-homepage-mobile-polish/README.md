# ShiftStart homepage + mobile refinement

This applies the five final usability recommendations without removing the current redesign.

Changes:
- Search and Wizard are the two dominant homepage actions.
- Browse All is a smaller text link.
- Homepage priority cards now show only risk, review status, title and the open action.
- Tier, Time and Owner remain on procedure detail pages.
- No dash placeholders are shown on homepage priority cards.
- Domains are sorted by live procedure count and only the top five are shown initially.
- A See All Domains button reveals the rest.
- A Verified vs Under Review trust cue appears beside the hero content.
- Mobile search is forced to remain visible as the second row of the sticky header.

No knowledge Markdown is changed.

Apply:

```bash
git status
git fetch origin
git pull --rebase origin main

unzip -q shiftstart-homepage-mobile-polish.zip
python3 shiftstart-homepage-mobile-polish/apply-homepage-mobile-polish.py

npm install --no-audit --no-fund
npm run check

rm -f shiftstart-homepage-mobile-polish.zip
rm -rf shiftstart-homepage-mobile-polish

git add -A
git status
git commit -m "Polish homepage hierarchy and mobile search"
git push origin main
```
