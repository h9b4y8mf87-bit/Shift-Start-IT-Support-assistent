#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import json, re, shutil, subprocess

repo = Path.cwd()
patch = Path(__file__).resolve().parent
manifest = json.loads((patch / "payload" / "_batch-b2-manifest.json").read_text(encoding="utf-8"))

if not (repo / "package.json").exists() or not (repo / "_procedures").exists():
    raise SystemExit("ERROR: run from the ShiftStart repository root")

required = list(manifest["classifications"]) + ["triage-a-dns-service-issue"]
missing = [slug for slug in required if not (repo / "_procedures" / f"{slug}.md").exists()]
if missing:
    raise SystemExit("ERROR: missing procedures: " + ", ".join(missing))

before_count = len(list((repo / "_procedures").glob("*.md")))
if before_count != 421:
    raise SystemExit(f"ERROR: expected 421 procedures; found {before_count}")

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = repo / ".shiftstart-backups" / f"batch-b2-{stamp}"
targets = [repo / "package.json"] + [repo / "_procedures" / f"{slug}.md" for slug in required]
for src in targets:
    dst = backup / src.relative_to(repo)
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

def yaml_quote(value):
    return "'" + str(value).replace("'", "''") + "'"

def set_field(text, key, value):
    pattern = re.compile(rf"(?m)^({re.escape(key)}:\s*).*$")
    if pattern.search(text):
        return pattern.sub(rf"\g<1>{value}", text, count=1)
    parts = text.split("---", 2)
    if len(parts) < 3:
        raise ValueError(f"front matter missing while setting {key}")
    return "---" + parts[1].rstrip() + f"\n{key}: {value}\n---" + parts[2]

def control_block(control):
    lines = [
        "## Mandatory Batch B-2 controls",
        "These audit-derived controls are mandatory before more invasive remediation.",
        "",
        "### Pre-checks",
    ]
    lines += [f"{i+1}. {item}" for i, item in enumerate(control["prechecks"])]
    lines += ["", "### Rollback / undo", f"- {control['rollback']}", ""]
    return "\n".join(lines)

def add_or_replace_controls(text, control):
    block = control_block(control)
    pattern = re.compile(r"(?ms)^## Mandatory Batch B-2 controls\n.*?(?=^## )")
    if pattern.search(text):
        return pattern.sub(block, text, count=1)
    for anchor in ["\n## Preconditions and authorisation", "\n## Diagnostic Steps"]:
        idx = text.find(anchor)
        if idx != -1:
            return text[:idx] + "\n" + block + text[idx+1:]
    parts = text.split("---", 2)
    if len(parts) < 3:
        raise ValueError("Unable to insert controls")
    return "---" + parts[1] + "---\n" + block + parts[2].lstrip("\n")

for slug, expected in manifest["classifications"].items():
    path = repo / "_procedures" / f"{slug}.md"
    text = path.read_text(encoding="utf-8")
    text = set_field(text, "severity", expected["severity"])
    text = set_field(text, "verification_priority", expected["priority"])
    text = set_field(text, "classification_audit", "batch-b2-2026-08-13")
    text = set_field(text, "risk_basis", yaml_quote(f"Batch B-2 audit classification: {expected['priority']} / {expected['severity']}."))
    if slug != "troubleshoot-dns-name-resolution":
        text = add_or_replace_controls(text, manifest["controls"][slug])
    path.write_text(text, encoding="utf-8")
    print(f"{slug}: {expected['priority']}/{expected['severity']}")

# Merge DNS duplicate into the existing canonical P1 DNS service runbook.
canonical_path = repo / "_procedures" / "triage-a-dns-service-issue.md"
canonical = canonical_path.read_text(encoding="utf-8")
canonical = set_field(canonical, "canonical_role", "definitive-dns-service-runbook")
canonical = set_field(canonical, "classification_audit", "batch-b2-2026-08-13")

merged_dns_lines = [
    "## Merged DNS decision path",
    "This is the definitive DNS service and name-resolution runbook.",
    "",
    "1. **Determine scope first.** Compare more than one client/subnet. A single endpoint points to client resolver configuration; multiple endpoints or zones point to DNS service/infrastructure.",
    "2. **Test primary and secondary DNS explicitly.** Query the configured primary and secondary DNS servers and compare an external/forwarder lookup only where policy permits.",
    "3. **Check client configuration.** Confirm the client points to the approved internal resolver and has the expected suffix/search configuration.",
    "4. **Check service infrastructure.** Review DNS service state, authoritative zones, replication, zone/forwarder settings, root hints, resource health and recent changes.",
    "5. **Protect configuration before change.** Export or otherwise capture the affected zone/forwarder/server configuration before editing it.",
    "6. **Verify after remediation.** Confirm authoritative and recursive resolution from multiple clients and verify dependent business services.",
    "",
]
merged_dns = "\n".join(merged_dns_lines)
if "## Merged DNS decision path" not in canonical:
    idx = canonical.find("\n## Preconditions and authorisation")
    if idx == -1:
        idx = canonical.find("\n## Procedure")
    if idx == -1:
        raise SystemExit("ERROR: cannot insert merged DNS decision path")
    canonical = canonical[:idx] + "\n" + merged_dns + canonical[idx+1:]
canonical_path.write_text(canonical, encoding="utf-8")

dup_path = repo / "_procedures" / "troubleshoot-dns-name-resolution.md"
dup = dup_path.read_text(encoding="utf-8")
parts = dup.split("---", 2)
if len(parts) != 3:
    raise SystemExit("ERROR: DNS duplicate front matter invalid")
front = "---" + parts[1] + "---\n"
front = set_field(front, "severity", "high")
front = set_field(front, "verification_priority", "P1")
front = set_field(front, "content_status", "deprecated")
front = set_field(front, "verification_governance_state", "deprecated")
front = set_field(front, "canonical_procedure", "triage-a-dns-service-issue")
front = set_field(front, "deprecation_reason", yaml_quote("Merged into the definitive DNS service runbook during Batch B-2 audit."))
dup_body = "\n".join([
    "## Deprecated — use the definitive DNS service runbook",
    "This procedure has been merged into **Triage a DNS service issue**.",
    "",
    "Use `/procedures/triage-a-dns-service-issue/`.",
    "",
    "The canonical runbook now covers client resolver checks, primary/secondary DNS testing, service/zone/forwarder health, rollback and end-to-end verification. This page remains only to preserve historical links.",
    "",
])
dup_path.write_text(front + dup_body, encoding="utf-8")

# Outlook routing without collapsing distinct failure modes.
outlook_path = repo / "_procedures" / "troubleshoot-outlook-that-will-not-open.md"
outlook = outlook_path.read_text(encoding="utf-8")
routing = "\n".join([
    "## Outlook client decision path",
    "Use the failure mode to select the narrowest Outlook procedure:",
    "",
    "- Outlook does not launch: continue with this procedure.",
    "- Outlook opens but cannot send/receive: `troubleshoot-outlook-send-and-receive`.",
    "- Outlook repeatedly prompts for credentials: `troubleshoot-recurring-outlook-credential-prompts`.",
    "- Outlook launches only in Safe Mode / add-in suspected: `troubleshoot-outlook-add-ins`.",
    "- Outlook works but search is incomplete: `troubleshoot-outlook-search`.",
    "",
    "Do not recreate the Outlook profile merely because a related child symptom exists; follow the child procedure's pre-checks first.",
    "",
])
if "## Outlook client decision path" not in outlook:
    idx = outlook.find("\n## Procedure")
    if idx == -1:
        idx = outlook.find("\n## Diagnostic Steps")
    if idx == -1:
        raise SystemExit("ERROR: cannot insert Outlook decision path")
    outlook = outlook[:idx] + "\n" + routing + outlook[idx+1:]
outlook_path.write_text(outlook, encoding="utf-8")

# Security evidence: chain of custody before collection and no reproduction.
evidence_path = repo / "_procedures" / "collect-security-incident-evidence.md"
evidence = evidence_path.read_text(encoding="utf-8")
if "0. **Establish chain of custody before collection.**" not in evidence:
    anchor = "## Procedure\n"
    step0 = (
        "0. **Establish chain of custody before collection.** Record the incident/ticket ID, asset, collector, "
        "date/time/timezone, evidence source, storage destination and every custody transfer before collecting or moving evidence.\n\n"
    )
    if anchor not in evidence:
        raise SystemExit("ERROR: security evidence Procedure heading missing")
    evidence = evidence.replace(anchor, anchor + step0, 1)
evidence = evidence.replace(
    "1. **Confirm the report and reproduce safely.** Ask the user to demonstrate the original task or reproduce it with non-sensitive test data. Do not repeatedly trigger lockouts, failed jobs, duplicate transactions or destructive actions.",
    "1. **Confirm the incident evidence request without reproducing suspicious activity.** Identify what evidence is required, the authorised collection scope and the relevant time window. Do not execute suspected malware or recreate the incident merely to generate evidence."
)
evidence_path.write_text(evidence, encoding="utf-8")

# Print queue: add safe sequence that checks disk/scope first.
print_path = repo / "_procedures" / "clear-a-stuck-windows-print-queue.md"
print_text = print_path.read_text(encoding="utf-8")
if "## Batch B-2 print-queue safety sequence" not in print_text:
    safety = "\n".join([
        "## Batch B-2 print-queue safety sequence",
        "1. Confirm whether the queue is local or shared and identify affected users/jobs.",
        "2. Record queue state and check disk free space before stopping the Print Spooler.",
        "3. Where policy permits, move/copy affected spool files to an approved temporary backup/evidence location rather than deleting them immediately.",
        "4. Clear only the affected queue, restart the Print Spooler and verify a controlled test job.",
        "5. If the queue immediately re-stalls, stop repeated deletion and escalate with preserved queue/driver/event-log evidence.",
        "",
    ])
    idx = print_text.find("\n## Procedure")
    if idx == -1:
        idx = print_text.find("\n## Diagnostic Steps")
    if idx != -1:
        print_text = print_text[:idx] + "\n" + safety + print_text[idx+1:]
    else:
        parts = print_text.split("---", 2)
        print_text = "---" + parts[1] + "---\n" + safety + parts[2].lstrip("\n")
print_path.write_text(print_text, encoding="utf-8")

# Install validator/docs/audit record.
for src in (patch / "payload").rglob("*"):
    if not src.is_file() or src.name == "_batch-b2-manifest.json":
        continue
    rel = src.relative_to(patch / "payload")
    dst = repo / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)

audit_dst = repo / "_data" / "batch-b2-audit-remediation.json"
audit_dst.parent.mkdir(parents=True, exist_ok=True)
shutil.copy2(patch / "payload" / "_batch-b2-manifest.json", audit_dst)

pkg_path = repo / "package.json"
pkg = json.loads(pkg_path.read_text(encoding="utf-8"))
scripts = pkg.setdefault("scripts", {})
scripts["batch:b2:check"] = "python3 scripts/validate-batch-b2-remediation.py"
check = scripts.get("check", "")
if "npm run batch:b2:check" not in check:
    scripts["check"] = (check + " && " if check else "") + "npm run batch:b2:check"
pkg_path.write_text(json.dumps(pkg, indent=2) + "\n", encoding="utf-8")

# Installer validation is pure Python; no Node packages needed.
result = subprocess.run(["python3", "scripts/validate-batch-b2-remediation.py"], cwd=repo)
if result.returncode != 0:
    raise SystemExit("ERROR: Batch B-2 validator failed")

after_count = len(list((repo / "_procedures").glob("*.md")))
if after_count != before_count:
    raise SystemExit(f"ERROR: procedure count changed {before_count}->{after_count}")

print("")
print("Batch B-2 remediation applied.")
print("No procedure was promoted to Verified.")
print("Backup:", backup.relative_to(repo))
print("")
print("Next:")
print("  npm install --no-audit --no-fund")
print("  npm run verification:v2:apply")
print("  npm run verification:queue")
print("  npm run verification:batches")
print("  npm run batch:b2:check")
print("  npm run check")
print("  npm run build")
