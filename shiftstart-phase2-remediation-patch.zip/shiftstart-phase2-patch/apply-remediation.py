#!/usr/bin/env python3
from pathlib import Path
import json, re, shutil, sys

repo = Path.cwd().resolve()
patch = Path(__file__).resolve().parent
payload = patch / "payload"

required = [repo / "_procedures", repo / "_symptoms", repo / "_layouts", repo / "package.json"]
if not all(path.exists() for path in required):
    print("ERROR: Run this script from the root of the ShiftStart repository.", file=sys.stderr)
    sys.exit(1)

# Overwrite authoritative corrected files.
for source in payload.rglob("*"):
    if source.is_dir():
        continue
    relative = source.relative_to(payload)
    target = repo / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    print(f"Updated {relative}")

canonical = {
    "Desktop": "Windows Endpoints",
    "Identity": "Identity & Access Management",
    "Network": "Network & Connectivity",
    "Microsoft 365": "Microsoft 365 & Collaboration",
    "Printing": "Printing & Scanning",
    "Windows Recovery": "Windows Endpoints",
    "Collaboration": "Microsoft 365 & Collaboration",
}

# Canonicalise taxonomy across the complete source catalogue without changing URLs or article bodies.
category_changes = 0
for directory in [repo / "_procedures", repo / "_symptoms"]:
    for path in directory.glob("*.md"):
        text = path.read_text(encoding="utf-8")
        match = re.search(r"^category:\s*(.+)$", text, re.M)
        if match and match.group(1).strip() in canonical:
            old = match.group(1).strip()
            text = re.sub(r"^category:\s*.+$", f"category: {canonical[old]}", text, count=1, flags=re.M)
            path.write_text(text, encoding="utf-8")
            category_changes += 1

# Ensure every procedure exposes an assurance state. Existing reviewed metadata is preserved.
verified = set(json.loads((repo / "_data/content-governance.json").read_text(encoding="utf-8"))["verifiedProcedures"])
status_changes = 0
for path in (repo / "_procedures").glob("*.md"):
    text = path.read_text(encoding="utf-8")
    slug_match = re.search(r"^slug:\s*(.+)$", text, re.M)
    slug = slug_match.group(1).strip() if slug_match else path.stem
    if not re.search(r"^content_status:", text, re.M):
        status = "verified" if slug in verified else "under_review"
        text = text.replace("\n---\n", f"\ncontent_status: {status}\nquality_gate: {'passed' if status == 'verified' else 'pending'}\n---\n", 1)
        path.write_text(text, encoding="utf-8")
        status_changes += 1

# Exact deployment assertions. They are intentionally strict so an old source tree cannot silently deploy.
procedures = list((repo / "_procedures").glob("*.md"))
symptoms = list((repo / "_symptoms").glob("*.md"))
errors = []
if len(procedures) != 421: errors.append(f"Expected 421 procedures; found {len(procedures)}")
if len(symptoms) != 446: errors.append(f"Expected 446 symptoms; found {len(symptoms)}")

forbidden = "Get-ADUser -Identity username -Properties Enabled,LockedOut,PasswordExpired,LastLogonDate | Select SamAccountName,Enabled,LockedOut,PasswordExpired,LastLogonDate"
remaining = [path.name for path in procedures if forbidden in path.read_text(encoding="utf-8")]
if remaining: errors.append("Generic IAM command remains in: " + ", ".join(remaining))

bad_titles = {
    "Need to a desk move", "Need to a device health check", "Need to an approved remote wipe",
    "Request to a hardware request", "Request to a standard service request",
    "And rebuild the Teams cache", "A paper jam safely", "Hardware request requested",
    "Software installation request requested", "Standard service request requested"
}
for path in symptoms:
    text = path.read_text(encoding="utf-8")
    match = re.search(r"^title:\s*(.+)$", text, re.M)
    if match and match.group(1).strip() in bad_titles:
        errors.append(f"Malformed symptom title remains in {path.name}: {match.group(1).strip()}")

legacy = set(canonical)
for directory in [repo / "_procedures", repo / "_symptoms"]:
    for path in directory.glob("*.md"):
        match = re.search(r"^category:\s*(.+)$", path.read_text(encoding="utf-8"), re.M)
        if match and match.group(1).strip() in legacy:
            errors.append(f"Legacy category remains in {path}: {match.group(1).strip()}")

article = (repo / "_layouts/article.html").read_text(encoding="utf-8")
header = (repo / "_includes/header.html").read_text(encoding="utf-8")
if "assurance-banner" not in article: errors.append("Assurance banner is missing from procedure layout")
if "/reports/content-audit.json" not in article: errors.append("Procedure page does not link to the content audit")
if "/content-quality/" not in header: errors.append("Quality navigation is not global")

group = (repo / "_procedures/add-or-remove-security-group-membership.md").read_text(encoding="utf-8")
for command in ["Get-ADGroupMember", "Add-ADGroupMember", "Remove-ADGroupMember", "Get-MgGroupMember", "New-MgGroupMemberByRef", "Remove-MgGroupMemberByRef"]:
    if command not in group: errors.append(f"Group-membership procedure missing {command}")

if errors:
    print("\nREMEDIATION FAILED:\n- " + "\n- ".join(errors), file=sys.stderr)
    sys.exit(1)

print(f"\nRemediation applied successfully. Canonicalised {category_changes} category entries and added {status_changes} missing assurance states.")
print("Verified source assertions: 421 procedures, 446 symptoms, corrected IAM command blocks, corrected titles, canonical taxonomy, global Quality navigation and in-page assurance status.")
