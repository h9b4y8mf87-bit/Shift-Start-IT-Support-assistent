# ShiftStart phase-two remediation patch

Run from the repository root:

```bash
python3 shiftstart-phase2-patch/apply-remediation.py
npm install --no-audit --no-fund
npm run check
git add -A
git commit -m "Apply phase-two content remediation"
git push
```

The patch overwrites the corrected group-membership procedure, 27 IAM procedure diagnostic blocks, page-level assurance UI, global Quality navigation, audit validation, wizard governance fields and the exact malformed symptom files. It also canonicalises duplicate category names across all procedure and symptom front matter and fails if the old defects remain.
