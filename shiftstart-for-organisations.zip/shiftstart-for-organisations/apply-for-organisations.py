#!/usr/bin/env python3
from pathlib import Path
import shutil
import sys

repo = Path.cwd()
patch = Path(__file__).resolve().parent
payload = patch / "payload"

required = [
    repo / "index.html",
    repo / "_layouts" / "default.html",
    repo / "_includes" / "header.html",
    repo / "_data" / "kb.yml",
]
missing = [str(p) for p in required if not p.exists()]
if missing:
    print("ERROR: Run this from the ShiftStart repository root.", file=sys.stderr)
    for item in missing:
        print("-", item, file=sys.stderr)
    raise SystemExit(1)

protected = ["_procedures", "_symptoms", "_causes", "_commands"]
before = {
    name: len(list((repo / name).glob("*.md"))) if (repo / name).exists() else 0
    for name in protected
}

# Copy additive files.
for source in payload.rglob("*"):
    if not source.is_file():
        continue
    rel = source.relative_to(payload)
    target = repo / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    print("Added:", rel)

# Load commercial stylesheet and script in the global layout.
default_path = repo / "_layouts" / "default.html"
default = default_path.read_text(encoding="utf-8")

css_tag = """  <link rel="stylesheet" href="{{ '/assets/css/commercial.css' | relative_url }}">"""
if "/assets/css/commercial.css" not in default:
    if "</head>" not in default:
        raise SystemExit("ERROR: Could not find </head> in default layout.")
    default = default.replace("</head>", css_tag + "\n</head>", 1)

js_tag = """  <script defer src="{{ '/assets/js/commercial.js' | relative_url }}"></script>"""
if "/assets/js/commercial.js" not in default:
    if "</body>" not in default:
        raise SystemExit("ERROR: Could not find </body> in default layout.")
    default = default.replace("</body>", js_tag + "\n</body>", 1)

default_path.write_text(default, encoding="utf-8")
print("Updated: _layouts/default.html")

# Add For Organisations to desktop + mobile navigation.
header_path = repo / "_includes" / "header.html"
header = header_path.read_text(encoding="utf-8")

desktop_link = """        <a class="rd-commercial-nav" href="{{ '/organisations/' | relative_url }}"{% if page.url == '/organisations/' %} aria-current="page"{% endif %}>For Organisations</a>"""
if "/organisations/" not in header:
    anchor = """        <a href="{{ '/about/' | relative_url }}"{% if page.url == '/about/' %} aria-current="page"{% endif %}>About</a>"""
    if anchor not in header:
        raise SystemExit("ERROR: Could not find desktop navigation insertion point.")
    header = header.replace(anchor, desktop_link + "\n" + anchor, 1)

mobile_link = """        <a href="{{ '/organisations/' | relative_url }}">For Organisations</a>"""
if header.count("/organisations/") < 2:
    anchor = """        <a href="{{ '/about/' | relative_url }}">About</a>"""
    if anchor not in header:
        raise SystemExit("ERROR: Could not find mobile navigation insertion point.")
    header = header.replace(anchor, mobile_link + "\n" + anchor, 1)

header_path.write_text(header, encoding="utf-8")
print("Updated: _includes/header.html")

# Add the small homepage section before readiness/trust content.
index_path = repo / "index.html"
index = index_path.read_text(encoding="utf-8")
include_line = "{% include organisations-section.html %}"
if include_line not in index:
    anchor = "{% include readiness-dashboard.html %}"
    if anchor in index:
        index = index.replace(anchor, include_line + "\n\n" + anchor, 1)
    else:
        trust_anchor = '<section class="shell rd-dashboard-section rd-trust-section">'
        if trust_anchor not in index:
            raise SystemExit("ERROR: Could not locate homepage commercial insertion point.")
        index = index.replace(trust_anchor, include_line + "\n\n" + trust_anchor, 1)
    index_path.write_text(index, encoding="utf-8")
    print("Updated: index.html")

# Add commercial configuration without exposing an unconfirmed email address.
kb_path = repo / "_data" / "kb.yml"
kb = kb_path.read_text(encoding="utf-8")
if "\ncommercial:\n" not in "\n" + kb:
    block = """
commercial:
  enabled: true
  enquiryEmail: ''
  responseWindow: 'Scoped after enquiry'
"""
    kb = kb.rstrip() + "\n" + block
    kb_path.write_text(kb, encoding="utf-8")
    print("Updated: _data/kb.yml")

after = {
    name: len(list((repo / name).glob("*.md"))) if (repo / name).exists() else 0
    for name in protected
}
if before != after:
    raise SystemExit(f"ERROR: Protected knowledge counts changed. Before={before} After={after}")

checks = {
    "organisations.html": ["Custom Procedures", "Knowledge Base Audit", "Private ShiftStart", "data-org-enquiry-form"],
    "_includes/organisations-section.html": ["For organisations", "Custom Procedures", "Knowledge Base Audit", "Private ShiftStart"],
    "_includes/header.html": ["For Organisations", "/organisations/"],
    "_layouts/default.html": ["commercial.css", "commercial.js"],
    "_data/kb.yml": ["commercial:", "enquiryEmail:"],
    "assets/css/commercial.css": [".org-home-grid", ".org-service-grid", ".org-enquiry-form"],
    "assets/js/commercial.js": ["data-org-enquiry-form", "enquiryEmail", "buildBrief"],
}
for rel, tokens in checks.items():
    text = (repo / rel).read_text(encoding="utf-8")
    absent = [token for token in tokens if token not in text]
    if absent:
        raise SystemExit(f"ERROR: {rel} missing expected markers: {absent}")

print("")
print("For Organisations commercial layer applied successfully.")
print("Knowledge collections preserved:", before)
print("Added: homepage commercial section, dedicated organisations page, three offers, navigation and enquiry workflow.")
print("")
print("Optional: set a public ShiftStart business email in _data/kb.yml:")
print("  commercial:")
print("    enquiryEmail: 'your-business-email@example.com'")
