# ShiftStart — For Organisations

This patch adds a small commercial layer without placing a paywall around the public knowledge base.

## What is added

### Homepage section

A compact **For Organisations** section with three offers:

- Custom Procedures
- Knowledge Base Audit
- Private ShiftStart

The section links to a dedicated commercial page rather than a checkout.

### `/organisations/`

A responsive landing page with:

- commercial value proposition;
- public-KB proof points;
- detailed service cards;
- four-step engagement process;
- enquiry form.

### Enquiry workflow

The site remains static and does not store form submissions.

If `_data/kb.yml` contains:

```yaml
commercial:
  enabled: true
  enquiryEmail: 'business@example.com'
```

the form prepares a structured email and opens the user's mail application.

If no email is configured, the same form copies a structured enquiry brief instead. This avoids exposing an unconfirmed personal email address.

## Apply

From the ShiftStart repository root:

```bash
git status
git fetch origin
git pull --rebase origin main

unzip -q shiftstart-for-organisations.zip

python3 \
  shiftstart-for-organisations/apply-for-organisations.py

npm install --no-audit --no-fund
npm run check
```

If validation passes:

```bash
rm -f shiftstart-for-organisations.zip
rm -rf shiftstart-for-organisations

git add -A
git status
git commit -m "Add For Organisations commercial services"
git push origin main
```

## Recommended final configuration

Before publishing the commercial section widely, set a dedicated public ShiftStart business enquiry address:

```yaml
commercial:
  enabled: true
  enquiryEmail: 'your-public-business-email@example.com'
  responseWindow: 'Scoped after enquiry'
```

No checkout, payment processor or customer account system is added in this phase.
