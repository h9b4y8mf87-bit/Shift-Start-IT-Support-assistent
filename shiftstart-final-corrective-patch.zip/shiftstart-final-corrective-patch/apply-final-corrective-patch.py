#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import shutil
import subprocess
import sys

PACKAGE_ROOT = Path(__file__).resolve().parent
PAYLOAD = PACKAGE_ROOT / "payload"
REPO = Path.cwd()

EXPECTED = {
    "content-quality.html": "5e6342db6b5dda8ffe5f3d7c2365cb6fce10be89",
    "_includes/readiness-dashboard.html": "dec6f7edb8c9e778cfd5860d812be592c04a4d0f",
    "enterprise-catalog.json": "85105d2be5fd80ef213e7dceac41799fd72bf492",
    "package.json": "ffa5d850a71db39ddd12261b102c5d56f364ef7c",
    ".github/workflows/deploy.yml": "2ebed3c8153d1176dd2826ebacb2e963062de448",
    ".gitignore": "42d557cb4326a6392689bc8570273a393114e2fe",
}
NEW_FILES = [
    "scripts/clean-pages-artifact.py",
    "scripts/validate-final-governance-consistency.py",
]

def git_blob_sha(path: Path) -> str:
    data = path.read_bytes()
    return hashlib.sha1(f"blob {len(data)}\0".encode("ascii") + data).hexdigest()

def payload_sha(rel: str) -> str:
    return git_blob_sha(PAYLOAD / rel)

def fail(message):
    print(f"ERROR: {message}", file=sys.stderr)
    sys.exit(1)

if not (REPO / "package.json").exists() or not (REPO / "_procedures").is_dir():
    fail("run this installer from the ShiftStart repository root")

count_before = len(list((REPO / "_procedures").glob("*.md")))
if count_before != 421:
    fail(f"expected exactly 421 procedures before patching; found {count_before}")

# Full preflight before any writes.
mismatches = []
already = []
for rel, expected in EXPECTED.items():
    target = REPO / rel
    if not target.exists():
        mismatches.append(f"{rel}: missing")
        continue
    current = git_blob_sha(target)
    patched = payload_sha(rel)
    if current == patched:
        already.append(rel)
    elif current != expected:
        mismatches.append(f"{rel}: local blob {current}, audited-main blob {expected}")

for rel in NEW_FILES:
    target = REPO / rel
    if target.exists() and git_blob_sha(target) != payload_sha(rel):
        mismatches.append(f"{rel}: already exists with different content")

if mismatches:
    print("Patch preflight stopped BEFORE making changes.", file=sys.stderr)
    print("One or more targeted files no longer match the audited main branch:", file=sys.stderr)
    for item in mismatches:
        print(f" - {item}", file=sys.stderr)
    print("Do not force the patch. Re-audit those files first.", file=sys.stderr)
    sys.exit(2)

stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
backup = REPO / ".shiftstart-backups" / f"final-corrective-{stamp}"
backup.mkdir(parents=True, exist_ok=True)

changed = []
for rel in list(EXPECTED) + NEW_FILES:
    source = PAYLOAD / rel
    target = REPO / rel
    if target.exists() and git_blob_sha(target) == payload_sha(rel):
        continue
    if target.exists():
        backup_target = backup / rel
        backup_target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(target, backup_target)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    changed.append(rel)

count_after = len(list((REPO / "_procedures").glob("*.md")))
if count_after != 421:
    fail(f"procedure count changed unexpectedly after patch: {count_after}")

# Source-only validation: no npm install/build required yet.
for cmd in [
    [sys.executable, "scripts/validate-supportvault-product-polish.py"],
    [sys.executable, "scripts/validate-final-governance-consistency.py"],
]:
    result = subprocess.run(cmd, cwd=REPO)
    if result.returncode != 0:
        fail(f"validation failed after patch: {' '.join(cmd)}")

print()
print("Final corrective patch applied successfully.")
print(f"Targeted files changed: {len(changed)}")
for rel in changed:
    print(f" - {rel}")
if already:
    print(f"Already at patched version: {len(already)}")
print(f"Procedure files touched: 0")
print(f"Procedure count preserved: {count_after}")
print(f"Backup: {backup}")
print()
print("NEXT:")
print("  npm run check")
print("  npm run build")
print("  git status --short")
