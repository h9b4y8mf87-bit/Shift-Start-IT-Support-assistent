# ShiftStart final corrective patch

This package is intentionally narrow. It does **not** modify any `_procedures/*.md` file and it does not promote anything to Verified.

## What it fixes

1. `content-quality.html` now counts the authoritative effective Verification-v2 state.
2. `_includes/readiness-dashboard.html` now shows Verified, Revalidation Required, Under Review and Deprecated from the same effective state.
3. `enterprise-catalog.json` now exposes effective `contentStatus` and `governanceStatus`, while retaining `legacyContentStatus` and `recordedGovernanceStatus` for traceability.
4. `npm run check` now enforces both the SupportVault-style product-polish validator and a final governance-consistency validator.
5. The GitHub Pages build removes known development patch ZIPs/installers from `_site` before upload and verifies the artifact is clean.
6. `.gitignore` prevents future local patch/back-up working material from being accidentally added.

## Safety

The installer checks each targeted existing file against the exact Git blob SHA from the audited `main` branch. If a targeted file has changed since the audit, it stops **before writing anything**.

It also checks that `_procedures` contains exactly 421 Markdown files before and after the patch.

## Apply

From the ShiftStart repository root:

```bash
unzip -q -o shiftstart-final-corrective-patch.zip
python3 shiftstart-final-corrective-patch/apply-final-corrective-patch.py
```

If the installer succeeds:

```bash
npm run check
npm run build
git status --short
```

Do not use `git reset --hard`, `git restore`, or a blind `git pull` to apply this patch.

## Expected governance state

This patch does not manufacture verification. Based on the audited repository state, the effective public status remains:

- Under Review: 398
- Revalidation Required: 11
- Deprecated: 12
- Evidence-complete Verified: 0

Those counts may change later only through the Verification-v2 evidence/promotion workflow.
