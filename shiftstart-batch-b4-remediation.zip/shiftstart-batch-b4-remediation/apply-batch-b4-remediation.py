#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import json,re,shutil,subprocess

repo=Path.cwd(); patch=Path(__file__).resolve().parent
m=json.loads((patch/"payload/_batch-b4-manifest.json").read_text(encoding="utf-8"))
if not (repo/"package.json").exists() or not (repo/"_procedures").exists():
    raise SystemExit("ERROR: run from ShiftStart repository root")
# Enforce audit order so B4 does not silently bypass unfinished B3.
if not (repo/"_data/batch-b3-audit-remediation.json").exists():
    raise SystemExit("ERROR: Batch B-3 audit record is missing. Finish/apply Batch B-3 before Batch B-4.")

required=list(m["procedures"])+["troubleshoot-teams-camera","grant-shared-mailbox-access"]
missing=[s for s in required if not (repo/"_procedures"/f"{s}.md").exists()]
if missing: raise SystemExit("ERROR: missing procedures: "+", ".join(missing))
before=len(list((repo/"_procedures").glob("*.md")))
if before!=421: raise SystemExit(f"ERROR: expected 421 procedures, found {before}")

backup=repo/".shiftstart-backups"/("batch-b4-"+datetime.now().strftime("%Y%m%d-%H%M%S"))
for src in [repo/"package.json"]+[repo/"_procedures"/f"{s}.md" for s in required]:
    dst=backup/src.relative_to(repo); dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)

def q(v):return "'"+str(v).replace("'","''")+"'"
def set_field(t,k,v):
    p=re.compile(rf"(?m)^({re.escape(k)}:\s*).*$")
    if p.search(t): return p.sub(rf"\g<1>{v}",t,count=1)
    a=t.split("---",2)
    if len(a)<3: raise ValueError(f"front matter missing {k}")
    return "---"+a[1].rstrip()+f"\n{k}: {v}\n---"+a[2]
def block(r):
    xs=["## Mandatory Batch B-4 controls","These audit-derived controls are mandatory before more invasive remediation.","","### Pre-checks"]
    xs += [f"{i+1}. {x}" for i,x in enumerate(r["prechecks"])]
    xs += ["","### Rollback / undo",f"- {r['rollback']}",""]
    return "\n".join(xs)
def add_controls(t,r):
    b=block(r)
    p=re.compile(r"(?ms)^## Mandatory Batch B-4 controls\n.*?(?=^## )")
    if p.search(t): return p.sub(b,t,count=1)
    for anchor in ["\n## Preconditions and authorisation","\n## Procedure"]:
        i=t.find(anchor)
        if i!=-1:return t[:i]+"\n"+b+t[i+1:]
    a=t.split("---",2); return "---"+a[1]+"---\n"+b+a[2].lstrip("\n")

for slug,r in m["procedures"].items():
    p=repo/"_procedures"/f"{slug}.md"; t=p.read_text(encoding="utf-8")
    t=set_field(t,"severity",r["severity"]); t=set_field(t,"verification_priority",r["priority"])
    # Preserve earlier print-server audit lineage while adding B4 re-audit marker separately.
    if slug=="troubleshoot-a-print-server-outage":
        t=set_field(t,"reaudit_batch","batch-b4-2026-08-13")
    else:
        t=set_field(t,"classification_audit","batch-b4-2026-08-13")
    t=set_field(t,"risk_basis",q(f"Batch B-4 audit classification: {r['priority']} / {r['severity']}."))
    if slug not in m["merge_policy"]: t=add_controls(t,r)
    p.write_text(t,encoding="utf-8")

# Print server: same file from earlier audit, add B4 Step 0 and explicit export rollback.
p=repo/"_procedures/troubleshoot-a-print-server-outage.md"; t=p.read_text(encoding="utf-8")
marker="0. **Check print-server disk capacity before queue/service changes.**"
if marker not in t:
    anchor="## Procedure\n"
    step=marker+" Confirm free space on system/spool volumes, capture PrintService/System evidence and preserve queued-job state before restarting the Spooler or clearing jobs.\n\n"
    if anchor not in t: raise SystemExit("ERROR: print server Procedure heading missing")
    t=t.replace(anchor,anchor+step,1)
if "Printbrm" not in t:
    rb="## Batch B-4 print-server rollback detail\nBefore driver, queue or port changes, export/capture the current printer configuration with approved tooling such as `Printbrm -B -f backup.printerexport` where supported. Restore the previous approved configuration if service worsens.\n\n"
    i=t.find("\n## Rollback and stop conditions")
    t=t[:i]+"\n"+rb+t[i+1:] if i!=-1 else t+"\n"+rb
p.write_text(t,encoding="utf-8")

# SAML provider health literal Step 0.
p=repo/"_procedures/troubleshoot-a-saml-application-error.md"; t=p.read_text(encoding="utf-8")
marker="0. **Check identity-provider health before federation changes.**"
if marker not in t:
    a="## Procedure\n"; step=marker+" Confirm the IdP and application-provider service health, then capture sign-in/SAML error evidence before editing metadata, certificates, ACS URLs or entity IDs.\n\n"
    if a not in t: raise SystemExit("ERROR: SAML Procedure heading missing")
    t=t.replace(a,a+step,1)
p.write_text(t,encoding="utf-8")

# Cloud health Step 0s.
cloud_steps={
"troubleshoot-an-aws-ec2-instance-that-is-unreachable":
"0. **Check AWS service/account health before instance changes.** Check AWS Health/service events for the affected account and region, then capture instance state/status checks and network policy before remediation.\n\n",
"troubleshoot-an-azure-virtual-machine-that-is-unreachable":
"0. **Check Azure service/resource health before VM changes.** Check Azure Service Health and Resource Health for the affected subscription/region, then capture VM state, Boot Diagnostics and network policy before remediation.\n\n",
}
for slug,step in cloud_steps.items():
    p=repo/"_procedures"/f"{slug}.md"; t=p.read_text(encoding="utf-8")
    marker=step.split("\n",1)[0]
    if marker not in t:
        a="## Procedure\n"
        if a not in t: raise SystemExit(f"ERROR: Procedure heading missing {slug}")
        t=t.replace(a,a+step,1)
    p.write_text(t,encoding="utf-8")

# HTTP 403 dedicated decision path.
p=repo/"_procedures/troubleshoot-an-http-403-error.md"; t=p.read_text(encoding="utf-8")
if "## HTTP 403 decision path" not in t:
    b="""## HTTP 403 decision path
1. Capture exact URL, identity, timestamp, response headers and available 403 substatus/error detail.
2. Compare another authorised user/browser/client to determine identity-specific versus application-wide scope.
3. Identify which layer returned 403: reverse proxy/WAF, web server, application authorization, filesystem/NTFS or upstream identity policy.
4. Review the relevant logs before changing permissions.
5. Change access only under least privilege and with the existing ACL/configuration captured for rollback.

"""
    i=t.find("\n## Procedure")
    if i==-1: raise SystemExit("ERROR: HTTP403 Procedure heading missing")
    t=t[:i]+"\n"+b+t[i+1:]
p.write_text(t,encoding="utf-8")

# External monitor canonical cross-platform runbook; preserve compatibility URLs.
canon=repo/"_procedures/troubleshoot-an-external-monitor.md"; t=canon.read_text(encoding="utf-8")
t=set_field(t,"canonical_role","definitive-cross-platform-external-monitor-runbook")
t=set_field(t,"cross_platform_scope","true")
decision="""## Cross-platform external monitor decision path
Start with monitor power/input, cable/adapter/dock and a known-good connection before changing software.

### Windows branch
- Check Settings > System > Display, display detection, graphics/display adapter state and approved driver history.
- Test another cable/port/dock/monitor to isolate the failing component.
- Restore the previous approved display/graphics driver if a confirmed driver change caused regression.

### macOS branch
- Check Displays settings/system information, cable/adapter/dock compatibility and supported refresh/resolution.
- Test another cable/port/dock/monitor to isolate the failing component.
- Use vendor/Apple-supported updates or configuration recovery; do not assume an OS downgrade is an available rollback.

### No-signal branch
- Verify monitor input source and whether POST/firmware output appears.
- If no signal persists with known-good hardware, isolate endpoint GPU/port versus monitor/cable failure and route hardware repair appropriately.

"""
if "## Cross-platform external monitor decision path" not in t:
    i=t.find("\n## Procedure")
    if i==-1: raise SystemExit("ERROR: external monitor Procedure heading missing")
    t=t[:i]+"\n"+decision+t[i+1:]
canon.write_text(t,encoding="utf-8")

for slug in ["troubleshoot-an-external-display-on-macos","troubleshoot-an-external-monitor-with-no-signal"]:
    p=repo/"_procedures"/f"{slug}.md"; old=p.read_text(encoding="utf-8"); a=old.split("---",2)
    front="---"+a[1]+"---\n"
    front=set_field(front,"severity","medium"); front=set_field(front,"verification_priority","P2")
    front=set_field(front,"content_status","deprecated"); front=set_field(front,"verification_governance_state","deprecated")
    front=set_field(front,"canonical_procedure","troubleshoot-an-external-monitor")
    front=set_field(front,"deprecation_reason",q("Merged into the definitive cross-platform external-monitor runbook during Batch B-4 audit."))
    body="""## Deprecated — use the definitive external-monitor procedure
This procedure has been merged into **Troubleshoot an external monitor**.

Use `/procedures/troubleshoot-an-external-monitor/`.

The canonical procedure now contains Windows, macOS and no-signal branches. This page remains only to preserve historical links.
"""
    p.write_text(front+body,encoding="utf-8")

# Webcam relationship: generic P3 hardware/OS diagnostics, Teams remains app-specific P2.
p=repo/"_procedures/troubleshoot-a-webcam-on-windows.md"; t=p.read_text(encoding="utf-8")
rel="""## Camera troubleshooting relationship
Use this procedure for Windows/driver/privacy/hardware camera diagnostics. If the camera works in the Windows Camera app but fails only in Microsoft Teams, continue with `troubleshoot-teams-camera`.

"""
if "## Camera troubleshooting relationship" not in t:
    i=t.find("\n## Procedure")
    if i==-1: raise SystemExit("ERROR: webcam Procedure heading missing")
    t=t[:i]+"\n"+rel+t[i+1:]
p.write_text(t,encoding="utf-8")

p=repo/"_procedures/troubleshoot-teams-camera.md"; t=p.read_text(encoding="utf-8")
if "troubleshoot-a-webcam-on-windows" not in t:
    rel2="""## Camera troubleshooting relationship
If the camera also fails in the Windows Camera app or Device Manager/privacy diagnostics indicate an OS/hardware problem, use `troubleshoot-a-webcam-on-windows`. Keep this Teams procedure for Teams-specific permissions, device selection, client state and policy.

"""
    i=t.find("\n## Procedure")
    if i==-1: raise SystemExit("ERROR: Teams camera Procedure heading missing")
    t=t[:i]+"\n"+rel2+t[i+1:]
p.write_text(t,encoding="utf-8")

# Shared mailbox access request vs troubleshooting relationship.
p=repo/"_procedures/troubleshoot-a-shared-mailbox.md"; t=p.read_text(encoding="utf-8")
if "grant-shared-mailbox-access" not in t:
    x="""## Shared mailbox relationship
Use `grant-shared-mailbox-access` for an approved request to add Full Access, Send As or Send on Behalf permissions. Use this procedure when previously expected shared-mailbox functionality is failing.

"""
    i=t.find("\n## Procedure")
    if i==-1: raise SystemExit("ERROR: shared mailbox Procedure heading missing")
    t=t[:i]+"\n"+x+t[i+1:]
p.write_text(t,encoding="utf-8")

# Install package records + validator.
for src in (patch/"payload").rglob("*"):
    if not src.is_file() or src.name=="_batch-b4-manifest.json": continue
    rel=src.relative_to(patch/"payload"); dst=repo/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
dst=repo/"_data/batch-b4-audit-remediation.json"; dst.parent.mkdir(parents=True,exist_ok=True)
shutil.copy2(patch/"payload/_batch-b4-manifest.json",dst)

pkgp=repo/"package.json"; pkg=json.loads(pkgp.read_text(encoding="utf-8")); scripts=pkg.setdefault("scripts",{})
scripts["batch:b4:check"]="python3 scripts/validate-batch-b4-remediation.py"
check=scripts.get("check","")
if "npm run batch:b4:check" not in check: scripts["check"]=(check+" && " if check else "")+"npm run batch:b4:check"
pkgp.write_text(json.dumps(pkg,indent=2)+"\n",encoding="utf-8")

r=subprocess.run(["python3","scripts/validate-batch-b4-remediation.py"],cwd=repo)
if r.returncode: raise SystemExit("ERROR: Batch B-4 validator failed")
after=len(list((repo/"_procedures").glob("*.md")))
if after!=before: raise SystemExit(f"ERROR: procedure count changed {before}->{after}")
print("")
print("Batch B-4 remediation applied.")
print("No procedure was promoted to Verified.")
print("Backup:",backup.relative_to(repo))
