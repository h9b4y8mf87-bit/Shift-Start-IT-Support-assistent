#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import shutil, json, sys

repo = Path.cwd()
patch = Path(__file__).resolve().parent
payload = patch / "payload"

required = [
    repo / "package.json",
    repo / "_data/verification-policy.yml",
    repo / "_data/verification-priority-policy.yml",
    repo / "_data/verification-demand.yml",
    repo / "scripts/verification-v2.js",
    repo / "scripts/build-verification-priority-queue.js",
]
missing = [str(p) for p in required if not p.exists()]
if missing:
    print("ERROR: Day 1-3 prerequisites are not installed.", file=sys.stderr)
    for item in missing: print("-", item, file=sys.stderr)
    raise SystemExit(1)

protected = ["_procedures","_symptoms","_causes","_commands"]
before = {n: len(list((repo/n).glob("*.md"))) if (repo/n).exists() else 0 for n in protected}

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = repo / ".shiftstart-backups" / f"m1-day4-5-{stamp}"
for rel in ["package.json","scripts/build-verification-priority-queue.js","scripts/validate-verification-priority-queue.js"]:
    src = repo / rel
    if src.exists():
        dst = backup / rel
        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(src,dst)

for src in payload.rglob("*"):
    if not src.is_file(): continue
    rel = src.relative_to(payload)
    dst = repo / rel
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dst)
    print("Installed:",rel)

package_path = repo / "package.json"
pkg = json.loads(package_path.read_text(encoding="utf-8"))
scripts = pkg.setdefault("scripts", {})
scripts["verification:queue"] = "node scripts/build-verification-priority-queue.js"
scripts["verification:queue:check"] = "node scripts/validate-verification-priority-queue.js"
scripts["verification:batches"] = "node scripts/build-verification-batches.js"
scripts["verification:batches:check"] = "node scripts/validate-verification-batches.js"
scripts["verification:evidence:create"] = "node scripts/create-verification-evidence-work-items.js"
scripts["verification:evidence:check"] = "node scripts/validate-verification-evidence-work-items.js"
scripts["verification:evidence:apply"] = "node scripts/apply-verification-evidence.js"

current = scripts.get("check","")
for addition in ["npm run verification:batches", "npm run verification:batches:check", "npm run verification:evidence:check"]:
    if addition not in current:
        current += " && " + addition
scripts["check"] = current
package_path.write_text(json.dumps(pkg,indent=2)+"\n",encoding="utf-8")
print("Updated: package.json")

after = {n: len(list((repo/n).glob("*.md"))) if (repo/n).exists() else 0 for n in protected}
if before != after:
    raise SystemExit(f"ERROR: Knowledge collection counts changed. Before={before} After={after}")

checks = {
    "scripts/build-verification-priority-queue.js": ["metadata-proxy-and-risk-floor-v2","metadata only","applyPriorityFloor"],
    "scripts/build-verification-batches.js": ["Batch","verification-batches.json"],
    "scripts/create-verification-evidence-work-items.js": ["actual_test_performed","evidence_is_not_fabricated"],
    "scripts/apply-verification-evidence.js": ["Dry run only","Promotion has NOT been performed"],
    "_data/verification-batch-policy.yml": ["Critical P0 verification","Historical verification revalidation"],
}
for rel,tokens in checks.items():
    text=(repo/rel).read_text(encoding="utf-8")
    missing_tokens=[t for t in tokens if t not in text]
    if missing_tokens:
        raise SystemExit(f"ERROR: {rel} missing expected markers {missing_tokens}")

print("")
print("M1 Day 4-5 evidence workflow installed.")
print("Knowledge collection counts preserved:", before)
print("Backup:", backup.relative_to(repo))
print("")
print("Next:")
print("  npm run verification:v2:apply")
print("  npm run verification:queue")
print("  npm run verification:queue:check")
print("  npm run verification:batches")
print("  npm run verification:batches:check")
print("  npm run verification:evidence:create -- --batch A")
print("  npm run verification:evidence:check")
print("  npm run check")
