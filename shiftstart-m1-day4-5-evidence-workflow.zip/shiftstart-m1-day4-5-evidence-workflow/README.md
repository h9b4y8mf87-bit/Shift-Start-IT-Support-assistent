# ShiftStart M1 Day 4–5 — Verification Batches & Evidence Workflow

This package requires M1 Day 1–3.

## Apply

```bash
git status
git fetch origin
git pull --rebase origin main

unzip -q shiftstart-m1-day4-5-evidence-workflow.zip

python3 \
  shiftstart-m1-day4-5-evidence-workflow/apply-m1-day4-5.py
```

Then:

```bash
npm install --no-audit --no-fund

npm run verification:v2:apply
npm run verification:queue
npm run verification:queue:check

npm run verification:batches
npm run verification:batches:check
```

Generate Batch A evidence forms:

```bash
npm run verification:evidence:create -- --batch A
npm run verification:evidence:check
```

Inspect the corrected ranking and batches:

```bash
node -e "const q=require('./reports/verification-priority-queue.json'); console.table(q.top50.slice(0,20).map(x=>({rank:x.rank,p:x.priority,score:x.priority_score,slug:x.slug,demand:x.temporary_proxy_match||'-',source:x.search_demand_source_field||'-'})))"
```

```bash
node -e "const b=require('./reports/verification-batches.json'); for(const [id,x] of Object.entries(b.batches)){console.log('\\nBATCH',id,x.name,'COUNT',x.count); console.table(x.procedures.map(p=>({order:p.batchOrder,p:p.priority,rank:p.rank,slug:p.slug,score:p.priorityScore})));}"
```

Run full checks:

```bash
npm run check
npm run build
```

If everything passes:

```bash
rm -f shiftstart-m1-day4-5-evidence-workflow.zip
rm -rf shiftstart-m1-day4-5-evidence-workflow
rm -rf .shiftstart-backups

git restore reports/content-audit.json 2>/dev/null || true

git add -A
git status
git commit -m "Add verification batches and evidence workflow"
git push origin main
```

## Capturing real evidence

Open a generated file under:

`verification/evidence/pending/<procedure-slug>.yml`

Fill only what was actually tested.

When complete:

```yaml
status: completed
declaration:
  actual_test_performed: true
  evidence_is_not_fabricated: true
```

Then:

```bash
npm run verification:evidence:check
```

Preview import:

```bash
npm run verification:evidence:apply -- --slug <procedure-slug>
```

Apply:

```bash
npm run verification:evidence:apply -- --slug <procedure-slug> --apply
npm run verification:v2:apply
npm run readiness:promote
npm run check
```

No promotion happens during evidence import.
