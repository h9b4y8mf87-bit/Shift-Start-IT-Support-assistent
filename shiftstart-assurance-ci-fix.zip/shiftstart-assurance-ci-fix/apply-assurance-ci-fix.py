#!/usr/bin/env python3
from pathlib import Path
import sys

repo = Path.cwd()
article = repo / "_layouts" / "article.html"

if not article.exists():
    print("ERROR: _layouts/article.html was not found. Run this from the repository root.", file=sys.stderr)
    raise SystemExit(1)

text = article.read_text(encoding="utf-8")

old_class = 'class="rd-assurance-callout status-{{ assurance_status }}"'
new_class = 'class="assurance-banner rd-assurance-callout status-{{ assurance_status }}"'

if old_class in text:
    text = text.replace(old_class, new_class, 1)
elif "assurance-banner" not in text:
    print("ERROR: Could not locate the redesigned assurance callout.", file=sys.stderr)
    raise SystemExit(1)

audit_link = "<span>Governance: <a href=\"{{ '/reports/content-audit.json' | relative_url }}\">Open machine-readable audit report</a></span>"
review_span = "<span>Reviewed by: {{ page.reviewed_by | default: 'Not recorded' }} · Last tested: {{ page.last_tested | default: 'Not recorded' }}</span>"

if "/reports/content-audit.json" not in text:
    if review_span not in text:
        print("ERROR: Could not locate the assurance review metadata.", file=sys.stderr)
        raise SystemExit(1)
    text = text.replace(review_span, review_span + audit_link, 1)

article.write_text(text, encoding="utf-8")

errors = []
if "assurance-banner" not in text:
    errors.append("assurance-banner class is missing")
if "/reports/content-audit.json" not in text:
    errors.append("audit report link is missing")
if "rd-assurance-callout" not in text:
    errors.append("redesigned assurance styling was lost")

if errors:
    print("ERROR:", "; ".join(errors), file=sys.stderr)
    raise SystemExit(1)

print("Assurance CI compatibility fix applied successfully.")
print("Preserved: redesigned rd-assurance-callout styling.")
print("Restored: assurance-banner validator marker.")
print("Added: machine-readable content audit link.")
print("Changed file: _layouts/article.html")
