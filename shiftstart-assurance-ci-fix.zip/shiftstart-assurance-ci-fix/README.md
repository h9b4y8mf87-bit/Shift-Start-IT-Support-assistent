# ShiftStart assurance CI fix

The redesign retained an assurance UI but renamed its CSS class to
`rd-assurance-callout`. The existing governance test still requires the
legacy-compatible `assurance-banner` class and a direct link to
`/reports/content-audit.json`.

This patch:

- keeps the redesigned assurance callout;
- adds `assurance-banner` as a second class;
- adds the machine-readable audit link;
- does not modify any procedures, symptoms, commands or causes;
- does not weaken or alter the validator.

## Apply

From the repository root:

```bash
git fetch origin
git pull --rebase origin main

unzip -q shiftstart-assurance-ci-fix.zip

python3 shiftstart-assurance-ci-fix/apply-assurance-ci-fix.py

npm install --no-audit --no-fund
npm run check

rm -f shiftstart-assurance-ci-fix.zip
rm -rf shiftstart-assurance-ci-fix

git add _layouts/article.html
git commit -m "Restore assurance checks in redesigned procedure layout"
git push origin main
```

The generic-command reuse lines printed by `validate-content.js` are warnings
for under-review procedures. The failing assertions were the two assurance
layout checks in `scripts/post-remediation-check.js`.
