#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime
import json,re,shutil,subprocess

repo=Path.cwd()
patch=Path(__file__).resolve().parent
manifest=json.loads((patch/'payload/_batch-b1-manifest.json').read_text(encoding='utf-8'))
if not (repo/'package.json').exists() or not (repo/'_procedures').exists():
    raise SystemExit('ERROR: run from ShiftStart repository root')
for slug in manifest['classifications']:
    if not (repo/'_procedures'/f'{slug}.md').exists():
        raise SystemExit(f'ERROR: missing procedure {slug}')
if not (repo/'_symptoms/a-duplicate-ip-address.md').exists():
    raise SystemExit('ERROR: duplicate-IP symptom missing')
before=len(list((repo/'_procedures').glob('*.md')))
if before!=421: raise SystemExit(f'ERROR: expected 421 procedures; found {before}')

backup=repo/'.shiftstart-backups'/('batch-b1-'+datetime.now().strftime('%Y%m%d-%H%M%S'))
for slug in manifest['classifications']:
    src=repo/'_procedures'/f'{slug}.md'; dst=backup/src.relative_to(repo); dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
for src in [repo/'package.json',repo/'_symptoms/a-duplicate-ip-address.md']:
    dst=backup/src.relative_to(repo); dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)

def field(text,key,value):
    pat=re.compile(rf'(?m)^({re.escape(key)}:\s*).*$')
    if pat.search(text): return pat.sub(rf'\g<1>{value}',text,count=1)
    a=text.split('---',2)
    if len(a)<3: raise ValueError('front matter missing')
    return '---'+a[1].rstrip()+f'\n{key}: {value}\n---'+a[2]

def q(s): return "'" + str(s).replace("'","''") + "'"

def controls_block(slug,c):
    pre='\n'.join(f'{i+1}. {x}' for i,x in enumerate(c['prechecks']))
    return f"## Mandatory Batch B-1 controls\nThese audit-derived controls are mandatory before more invasive remediation.\n\n### Pre-checks\n{pre}\n\n### Rollback / undo\n- {c['rollback']}\n\n"

def add_controls(text,slug,c):
    block=controls_block(slug,c)
    pat=re.compile(r'(?ms)^## Mandatory Batch B-1 controls\n.*?(?=^## )')
    if pat.search(text): return pat.sub(block,text,count=1)
    for anchor in ['\n## Preconditions and authorisation','\n## Diagnostic Steps']:
        idx=text.find(anchor)
        if idx!=-1: return text[:idx]+'\n'+block+text[idx+1:]
    a=text.split('---',2)
    return '---'+a[1]+'---\n'+block+a[2].lstrip('\n')

for slug,c in manifest['classifications'].items():
    f=repo/'_procedures'/f'{slug}.md'; t=f.read_text(encoding='utf-8')
    t=field(t,'severity',c['severity']); t=field(t,'verification_priority',c['priority'])
    t=field(t,'classification_audit','batch-b1-2026-08-13')
    t=field(t,'risk_basis',q(f"Batch B-1 audit classification: {c['priority']} / {c['severity']}."))
    if slug!='troubleshoot-a-mapped-drive-reconnect-failure':
        t=add_controls(t,slug,manifest['controls'][slug])
    f.write_text(t,encoding='utf-8')

# Compromised-account contradiction cleanup, preserving the supported Exchange commands already present.
f=repo/'_procedures/respond-to-a-suspected-compromised-account.md'; t=f.read_text(encoding='utf-8')
t=t.replace('1. **Confirm the report and reproduce safely.** Ask the user to demonstrate the original task or reproduce it with non-sensitive test data. Do not repeatedly trigger lockouts, failed jobs, duplicate transactions or destructive actions.','1. **Confirm the incident without reproducing suspicious activity.** Validate the report from sign-in, identity, application and mailbox evidence. Do not ask the user to reproduce suspicious actions.')
t=t.replace('4. **Collect sign-in and authentication evidence before containment.**','4. **Collect sign-in and authentication evidence after immediate containment.**')
f.write_text(t,encoding='utf-8')

# Malware Step 0 and no reproduction.
f=repo/'_procedures/respond-to-a-suspected-malware-infection.md'; t=f.read_text(encoding='utf-8')
if '0. **Isolate the endpoint immediately.**' not in t:
    anchor='## Procedure\n'
    step="0. **Isolate the endpoint immediately.** When active malware compromise is credible, isolate the affected endpoint through approved EDR/network controls before ordinary investigation. Preserve EDR/AV, process, network and identity evidence and notify Security Operations.\n\n"
    if anchor not in t: raise SystemExit('ERROR: malware Procedure heading missing')
    t=t.replace(anchor,anchor+step,1)
t=t.replace('1. **Confirm the report and reproduce safely.** Ask the user to demonstrate the original task or reproduce it with non-sensitive test data. Do not repeatedly trigger lockouts, failed jobs, duplicate transactions or destructive actions.','1. **Confirm the malware report without re-executing suspicious content.** Validate the alert, process/file indicators, timestamps and observed user impact from preserved evidence. Do not ask the user to reopen or execute the suspected content.')
f.write_text(t,encoding='utf-8')

# VPN generic procedure becomes parent triage.
f=repo/'_procedures/vpn-not-connecting.md'; t=f.read_text(encoding='utf-8'); a=t.split('---',2)
if len(a)!=3: raise SystemExit('ERROR: VPN front matter invalid')
front='---'+a[1]+'---\n'
body=controls_block('vpn-not-connecting',manifest['controls']['vpn-not-connecting'])+'''## Parent triage decision path
Use this procedure to identify the failing VPN layer. Do not use it as a catch-all remediation runbook.

1. **Determine scope.**
   - One Linux endpoint → `troubleshoot-linux-vpn`
   - One macOS endpoint → `troubleshoot-macos-vpn`
   - One mobile endpoint → `troubleshoot-mobile-vpn`
   - Certificate-specific failure → `troubleshoot-vpn-certificate-failure`
   - Repeated disconnects → `troubleshoot-vpn-disconnections`
   - Slow performance → `troubleshoot-slow-vpn-performance`
   - Multiple users / cloud gateway issue → `troubleshoot-a-cloud-vpn-gateway`

2. **Check service/gateway health before client changes.**
3. **Check basic endpoint prerequisites:** public internet, time, DNS, gateway reachability, approved client version and exact error.
4. **Check identity/policy blocks:** Conditional Access, NAC, disabled account or expired certificate.
5. **Route to the child runbook.** Do not delete certificates, managed profiles or authentication material here.

## Verification Steps
1. The correct child/gateway runbook is selected from observed evidence.
2. Scope is documented as single endpoint, platform-specific, multi-user or gateway-wide.
3. The child runbook owns remediation, rollback and live verification.

## Escalation Path
Escalate to Network Operations when multiple users/networks are affected, the gateway is unhealthy/unreachable, or evidence points to a gateway/provider issue.
'''
f.write_text(front+body,encoding='utf-8')

# Canonical mapped-drive procedure.
f=repo/'_procedures/mapped-drive-missing.md'; t=f.read_text(encoding='utf-8')
t=field(t,'canonical_role','definitive-mapped-drive-runbook')
t=t.replace('3. List current mappings and test the file server.','3. Capture current mappings with `net use`, then test the file server and the approved UNC path before deleting any mapping.')
f.write_text(t,encoding='utf-8')

# Deprecate duplicate while preserving URL and procedure count.
f=repo/'_procedures/troubleshoot-a-mapped-drive-reconnect-failure.md'; t=f.read_text(encoding='utf-8'); a=t.split('---',2)
if len(a)!=3: raise SystemExit('ERROR: mapped-drive duplicate front matter invalid')
fm='---'+a[1]+'---\n'
fm=field(fm,'severity','medium'); fm=field(fm,'verification_priority','P2')
fm=field(fm,'content_status','deprecated'); fm=field(fm,'verification_governance_state','deprecated')
fm=field(fm,'canonical_procedure','mapped-drive-missing')
fm=field(fm,'deprecation_reason',q('Merged into the definitive mapped-drive runbook during Batch B-1 audit.'))
deprecated='''## Deprecated — use the definitive mapped-drive procedure
This procedure has been merged into **Resolve a missing or disconnected mapped drive**.

Use `/procedures/mapped-drive-missing/`.

This page remains only to preserve historical links.
'''
f.write_text(fm+deprecated,encoding='utf-8')

# Current repo already has duplicate-IP symptom at medium; do not apply the audit's conditional Critical fix.
st=(repo/'_symptoms/a-duplicate-ip-address.md').read_text(encoding='utf-8')
if not re.search(r'(?m)^severity:\s*medium\s*$',st):
    raise SystemExit('ERROR: duplicate-IP symptom is not medium; inspect manually before continuing')

# Install validator and audit manifest.
for src in (patch/'payload').rglob('*'):
    if not src.is_file() or src.name=='_batch-b1-manifest.json': continue
    rel=src.relative_to(patch/'payload'); dst=repo/rel; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dst)
dst=repo/'_data/batch-b1-audit-remediation.json'; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(patch/'payload/_batch-b1-manifest.json',dst)

pkgp=repo/'package.json'; pkg=json.loads(pkgp.read_text(encoding='utf-8')); scripts=pkg.setdefault('scripts',{})
scripts['batch:b1:check']='node scripts/validate-batch-b1-remediation.js'
check=scripts.get('check','')
if 'npm run batch:b1:check' not in check: scripts['check']=(check+' && ' if check else '')+'npm run batch:b1:check'
pkgp.write_text(json.dumps(pkg,indent=2)+'\n',encoding='utf-8')

# Never promote. Recalculate v2 only if dependencies are available.
if (repo/'node_modules').exists() and 'verification:v2:apply' in scripts:
    if subprocess.run(['npm','run','verification:v2:apply'],cwd=repo).returncode:
        raise SystemExit('ERROR: verification:v2:apply failed')
if subprocess.run(['node','scripts/validate-batch-b1-remediation.js'],cwd=repo).returncode:
    raise SystemExit('ERROR: Batch B-1 validator failed')
after=len(list((repo/'_procedures').glob('*.md')))
if after!=before: raise SystemExit(f'ERROR: procedure count changed {before}->{after}')
print('Batch B-1 remediation applied. No procedure was promoted to Verified.')
print('Backup:',backup.relative_to(repo))
